/*
  Warnings:

  - The primary key for the channel_recordings table will be changed. If it partially fails, the table could be left without primary key constraint.
  - The primary key for the screen_recordings table will be changed. If it partially fails, the table could be left without primary key constraint.

*/
-- AlterTable
ALTER TABLE "jupiter"."channel_recordings" DROP CONSTRAINT "channel_recordings_pkey",
ADD CONSTRAINT "channel_recordings_pkey" PRIMARY KEY ("id", "recording_start_time");

-- AlterTable
ALTER TABLE "jupiter"."screen_recordings" DROP CONSTRAINT "screen_recordings_pkey",
ADD CONSTRAINT "screen_recordings_pkey" PRIMARY KEY ("id", "recording_start_time");


SELECT create_hypertable('jupiter.channel_recordings', 'recording_start_time', chunk_time_interval => INTERVAL '1 hours', migrate_data => true);
SELECT create_hypertable('jupiter.screen_recordings', 'recording_start_time', chunk_time_interval => INTERVAL '1 hours', migrate_data => true);
