-- AlterTable
ALTER TABLE "archive"."tasks" ALTER COLUMN "description" DROP NOT NULL;
