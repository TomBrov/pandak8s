-- Migration: update_channel_enum.sql

-- 1. Update existing rows in the channels table
UPDATE "jupiter"."channels"
SET "type" = CASE "type"
                 WHEN 'DAY' THEN 'PRIMARY'
                 WHEN 'NIGHT' THEN 'SECONDARY'
                 ELSE "type"
    END
WHERE "type" IN ('DAY', 'NIGHT');

-- 2. Rename the existing enum type so we can recreate it without the old values
ALTER TYPE "jupiter"."ChannelTypeEnum" RENAME TO "ChannelTypeEnum_old";

-- 3. Create a new enum type with only the desired values
CREATE TYPE "jupiter"."ChannelTypeEnum" AS ENUM ('PRIMARY', 'SECONDARY');

-- 4. Alter the channels table to use the new enum type
ALTER TABLE "jupiter"."channels"
ALTER COLUMN "type" TYPE "jupiter"."ChannelTypeEnum"
USING "type"::text::"jupiter"."ChannelTypeEnum";

-- 5. Drop the old enum type
DROP TYPE "jupiter"."ChannelTypeEnum_old";
