-- CreateEnum
CREATE TYPE "archive"."OpLogSourceEnum" AS ENUM ('MANUAL', 'SYSTEM');
