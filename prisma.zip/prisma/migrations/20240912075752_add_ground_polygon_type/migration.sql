-- CreateEnum
CREATE TYPE "jupiter"."GroundOrgPolygonType" AS ENUM ('PRIORITY', 'IGNORE');

-- AlterTable
ALTER TABLE
    "jupiter"."ground_org_polygon"
ADD
    COLUMN "polygon_type" "jupiter"."GroundOrgPolygonType" NOT NULL DEFAULT 'PRIORITY';