-- AlterTable
ALTER TABLE "jupiter"."ground_org_polygon" ADD COLUMN     "is_in_resp_area" BOOLEAN NOT NULL DEFAULT true;

-- AlterTable
ALTER TABLE "jupiter"."segments" ADD COLUMN     "is_in_resp_area" BOOLEAN NOT NULL DEFAULT true;

WITH resp_area_union AS (
  SELECT ST_Union(position) AS geom
  FROM jupiter.camera_responsibility_polygons
  WHERE ST_IsValid(position)
)
UPDATE jupiter.ground_org_polygon gop
SET is_in_resp_area = EXISTS (
  SELECT 1
  FROM resp_area_union rau
  WHERE ST_Contains(rau.geom, gop.position)
);


WITH resp_area_union AS (
  SELECT ST_Union(position) AS geom
  FROM jupiter.camera_responsibility_polygons
  WHERE ST_IsValid(position)
)
UPDATE jupiter.segments sg
SET is_in_resp_area = EXISTS (
  SELECT 1
  FROM resp_area_union rau
  WHERE ST_Contains(rau.geom, ST_StartPoint(sg.positions))
);
