-- AlterTable
ALTER TABLE "archive"."radar_indications" ADD COLUMN "is_recently_active" BOOLEAN NOT NULL DEFAULT true;

-- AlterTable
ALTER TABLE "archive"."tasks" ADD COLUMN "is_recently_active" BOOLEAN NOT NULL DEFAULT true;
