/*
  Warnings:

  - You are about to drop the column `is_free` on the `cameras` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "jupiter"."cameras" DROP COLUMN "is_free";
