-- CreateTable
CREATE TABLE "jupiter"."screen_recordings" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "hls_video_path" TEXT NOT NULL,
    "recording_start_time" TIMESTAMP(3) NOT NULL,
    "file_name" TEXT NOT NULL,
    "duration" DOUBLE PRECISION DEFAULT 60,
    "station_id" TEXT NOT NULL,

    CONSTRAINT "screen_recordings_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "jupiter"."screen_recordings" ADD CONSTRAINT "screen_recordings_station_id_fkey" FOREIGN KEY ("station_id") REFERENCES "jupiter"."stations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
