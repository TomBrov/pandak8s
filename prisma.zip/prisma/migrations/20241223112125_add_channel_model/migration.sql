/*
  Warnings:

  - You are about to drop the column `is_recording` on the `cameras` table. All the data in the column will be lost.
  - You are about to drop the column `streaming_path` on the `cameras` table. All the data in the column will be lost.
  - You are about to drop the column `streaming_port` on the `cameras` table. All the data in the column will be lost.
  - You are about to drop the `camera_recordings` table. If the table is not empty, all the data it contains will be lost.

*/
-- CreateEnum
CREATE TYPE "jupiter"."ChannelTypeEnum" AS ENUM ('DAY', 'NIGHT');

-- CreateTable
CREATE TABLE "jupiter"."channels" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "type" "jupiter"."ChannelTypeEnum" NOT NULL,
    "ip" TEXT NOT NULL,
    "port" INTEGER NOT NULL,
    "is_recording" BOOLEAN NOT NULL DEFAULT false,
    "camera_id" TEXT NOT NULL,

    CONSTRAINT "channels_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."channel_recordings" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "hls_video_path" TEXT NOT NULL,
    "recording_start_time" TIMESTAMP(3) NOT NULL,
    "file_name" TEXT NOT NULL,
    "duration" DOUBLE PRECISION DEFAULT 60,
    "channel_id" TEXT NOT NULL,

    CONSTRAINT "channel_recordings_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "channels_camera_id_idx" ON "jupiter"."channels"("camera_id");

-- CreateIndex
CREATE INDEX "channel_recordings_channel_id_recording_start_time_idx" ON "jupiter"."channel_recordings"("channel_id", "recording_start_time");

-- AddForeignKey
ALTER TABLE "jupiter"."channels" ADD CONSTRAINT "channels_camera_id_fkey" FOREIGN KEY ("camera_id") REFERENCES "jupiter"."cameras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."channel_recordings" ADD CONSTRAINT "channel_recordings_channel_id_fkey" FOREIGN KEY ("channel_id") REFERENCES "jupiter"."channels"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Insert 2 Channels For Each Camera
INSERT INTO "jupiter"."channels" ("id", "name", "type", "ip", "port", "is_recording", "camera_id")
SELECT
  gen_random_uuid(), -- Generate a unique ID for the first channel
  CONCAT(c."name", '_channel_1'), -- Create a name for the first channel
  'DAY'::"jupiter"."ChannelTypeEnum", -- Set the type for the first channel
  c."ip", -- Use the IP from the cameras table
  c."streaming_port", -- -- Use the streaming port from the cameras table
  c."is_recording", -- Use the is_recording from the cameras table
  c."id" -- Use the camera_id from the cameras table
FROM "jupiter"."cameras" c
UNION ALL
SELECT
  gen_random_uuid(), -- Generate a unique ID for the second channel
  CONCAT(c."name", '_channel_2'), -- Create a name for the second channel
  'NIGHT'::"jupiter"."ChannelTypeEnum", -- Set the type for the second channel
  c."ip", -- Use the IP from the cameras table
  c."streaming_port", -- Use the streaming port from the cameras table
  c."is_recording", -- Use the is_recording from the cameras table
  c."id" -- Use the camera_id from the cameras table
FROM "jupiter"."cameras" c;

-- Insert Channel Recordings For Each Camera Recording
INSERT INTO "jupiter"."channel_recordings" ("id", "created_at", "updated_at", "hls_video_path", "recording_start_time", "file_name", "duration", "channel_id")
SELECT DISTINCT ON (ch."camera_id", cr."id")
  gen_random_uuid(), -- Generate a unique ID for the channel recording
  cr."created_at", -- Use the created_at from the camera recordings table
  cr."updated_at", -- Use the updated_at from the camera recordings table
  cr."hls_video_path", -- Use the hls_video_path from the camera recordings table
  cr."recording_start_time", -- Use the recording_start_time from the camera recordings table
  cr."file_name", -- Use the file_name from the camera recordings table
  cr."duration", -- Use the duration from the camera recordings table
  ch."id" -- Use the channel_id from the channel table
FROM "jupiter"."camera_recordings" cr
JOIN "jupiter"."channels" ch ON cr."camera_id" = ch."camera_id"
ORDER BY ch."camera_id", cr."id", ch."id";

-- DropForeignKey
ALTER TABLE "jupiter"."camera_recordings" DROP CONSTRAINT "camera_recordings_camera_id_fkey";

-- AlterTable
ALTER TABLE "jupiter"."cameras" DROP COLUMN "is_recording",
DROP COLUMN "streaming_path",
DROP COLUMN "streaming_port";

-- DropTable
DROP TABLE "jupiter"."camera_recordings";
