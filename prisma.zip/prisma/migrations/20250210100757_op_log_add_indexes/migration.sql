-- CreateIndex
CREATE INDEX "op_logs_time_idx" ON "archive"."op_logs"("time");

-- CreateIndex
CREATE INDEX "radar_indications_time_idx" ON "archive"."radar_indications"("time");

-- CreateIndex
CREATE INDEX "tasks_time_idx" ON "archive"."tasks"("time");
