-- AlterTable
-- First add new columns without NOT NULL constraint
ALTER TABLE "jupiter"."cameras"
    ADD COLUMN "position" geometry(Point, 4326);

ALTER TABLE "jupiter"."commonLang"
    ADD COLUMN "position" geometry(Point, 4326);

ALTER TABLE "jupiter"."radars"
    ADD COLUMN "position" geometry(Point, 4326);

-- Convert existing data
UPDATE "jupiter"."cameras"
SET "position" = ST_SetSRID(ST_MakePoint("long", "lat"), 4326)
WHERE "long" IS NOT NULL AND "lat" IS NOT NULL;

UPDATE "jupiter"."commonLang"
SET "position" = ST_SetSRID(ST_MakePoint("lng", "lat"), 4326)
WHERE "lng" IS NOT NULL AND "lat" IS NOT NULL;

UPDATE "jupiter"."radars"
SET "position" = ST_SetSRID(ST_MakePoint("long", "lat"), 4326)
WHERE "long" IS NOT NULL AND "lat" IS NOT NULL;

-- Add NOT NULL constraint
ALTER TABLE "jupiter"."cameras"
    ALTER COLUMN "position" SET NOT NULL;

ALTER TABLE "jupiter"."commonLang"
    ALTER COLUMN "position" SET NOT NULL;

ALTER TABLE "jupiter"."radars"
    ALTER COLUMN "position" SET NOT NULL;

-- Finally drop old columns
ALTER TABLE "jupiter"."cameras" DROP COLUMN "long",
DROP COLUMN "lat";

ALTER TABLE "jupiter"."commonLang" DROP COLUMN "lat",
DROP COLUMN "lng";

ALTER TABLE "jupiter"."radars" DROP COLUMN "lat",
DROP COLUMN "long";