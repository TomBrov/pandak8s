/*
  Warnings:

  - You are about to drop the column `animal_grade` on the `ground_org_polygon` table. All the data in the column will be lost.
  - You are about to drop the column `human_grade` on the `ground_org_polygon` table. All the data in the column will be lost.
  - You are about to drop the column `moving_undefiend_grade` on the `ground_org_polygon` table. All the data in the column will be lost.
  - You are about to drop the column `undefiend_grade` on the `ground_org_polygon` table. All the data in the column will be lost.
  - You are about to drop the column `vehicle_grade` on the `ground_org_polygon` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "jupiter"."ground_org_polygon" DROP COLUMN "animal_grade",
DROP COLUMN "human_grade",
DROP COLUMN "moving_undefiend_grade",
DROP COLUMN "undefiend_grade",
DROP COLUMN "vehicle_grade",
ADD COLUMN     "metadata" JSONB NOT NULL DEFAULT '{}';
