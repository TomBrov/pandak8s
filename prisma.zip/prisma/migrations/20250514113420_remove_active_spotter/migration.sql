/*
  Warnings:

  - You are about to drop the column `active_spotter_id` on the `cameras_connections` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "jupiter"."cameras_connections" DROP CONSTRAINT "cameras_connections_active_spotter_id_fkey";

-- DropIndex
DROP INDEX "jupiter"."cameras_connections_active_spotter_id_key";

-- AlterTable
ALTER TABLE "jupiter"."cameras_connections" DROP COLUMN "active_spotter_id";
