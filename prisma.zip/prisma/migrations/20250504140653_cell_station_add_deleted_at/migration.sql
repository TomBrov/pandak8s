/*
  Warnings:

  - You are about to drop the column `is_deleted` on the `cells` table. All the data in the column will be lost.
  - You are about to drop the column `is_deleted` on the `stations` table. All the data in the column will be lost.

*/
-- DropIndex
DROP INDEX "jupiter"."channel_recordings_recording_start_time_idx";

-- DropIndex
DROP INDEX "jupiter"."screen_recordings_recording_start_time_idx";

-- AlterTable
ALTER TABLE "jupiter"."cells" DROP COLUMN "is_deleted",
ADD COLUMN     "deleted_at" TIMESTAMP(3);

-- AlterTable
ALTER TABLE "jupiter"."stations" DROP COLUMN "is_deleted",
ADD COLUMN     "deleted_at" TIMESTAMP(3);
