/*
  Warnings:

  - Made the column `is_deleted` on table `cells` required. This step will fail if there are existing NULL values in that column.
  - Made the column `is_deleted` on table `stations` required. This step will fail if there are existing NULL values in that column.

*/

-- AlterTable
ALTER TABLE "archive"."tasks" ADD COLUMN     "cell_dispname" TEXT,
ADD COLUMN     "station_type" "jupiter"."StationType";

-- AlterTable
ALTER TABLE "jupiter"."cells" ALTER COLUMN "is_deleted" SET NOT NULL;

-- AlterTable
ALTER TABLE "jupiter"."stations" ALTER COLUMN "is_deleted" SET NOT NULL;
