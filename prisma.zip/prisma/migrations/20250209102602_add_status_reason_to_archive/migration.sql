/*
  Warnings:

  - Made the column `status` on table `tasks` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "archive"."tasks" ADD COLUMN     "statusReason" "jupiter"."TaskStatusReasonEnum" NOT NULL DEFAULT 'NEW',
ALTER COLUMN "status" SET NOT NULL,
ALTER COLUMN "status" SET DEFAULT 'NEW';
