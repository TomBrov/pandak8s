-- Step 1: Add the new columns without dropping `time`
ALTER TABLE "jupiter"."op_logs"
    ADD COLUMN "created_at" TIMESTAMP(3),
    ADD COLUMN "updated_at" TIMESTAMP(3);

-- Step 2: Copy existing `time` values into both new columns
UPDATE "jupiter"."op_logs"
SET created_at = time,
    updated_at = time;

-- Step 3: Make `created_at` and `updated_at` non-nullable
ALTER TABLE "jupiter"."op_logs"
    ALTER COLUMN "created_at" SET NOT NULL,
    ALTER COLUMN "updated_at" SET NOT NULL;

-- Step 4: Drop the old `time` column
ALTER TABLE "jupiter"."op_logs" DROP COLUMN "time";
