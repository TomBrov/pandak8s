-- CreateEnum
CREATE TYPE "jupiter"."EventClassificationEnum" AS ENUM ('HOT_HAMMER', 'TOMAHAWK', 'HURRICANE', 'TURKISH_HORSEMAN', 'HORSEMAN_TURKISH', 'MEANING', 'TZAMBAR', 'BAKTAVIM', 'HAFSAD', 'AVALAG');

-- AlterTable
ALTER TABLE "jupiter"."tasks" ADD COLUMN     "event_classification" "jupiter"."EventClassificationEnum";
