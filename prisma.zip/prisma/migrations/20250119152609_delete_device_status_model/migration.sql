/*
  Warnings:

  - You are about to drop the `device_statuses` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropTable
DROP TABLE "jupiter"."device_statuses";
