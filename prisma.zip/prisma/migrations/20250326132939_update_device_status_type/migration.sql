
CREATE TYPE "jupiter"."DeviceStatusEnum_new" AS ENUM ('ACTIVE', 'SEMI_ACTIVE', 'INACTIVE');
ALTER TABLE "jupiter"."cameras" ADD COLUMN IF NOT EXISTS "status_new" "jupiter"."DeviceStatusEnum_new" NOT NULL DEFAULT 'ACTIVE';
ALTER TABLE "jupiter"."radars" ADD COLUMN IF NOT EXISTS "status_new" "jupiter"."DeviceStatusEnum_new" NOT NULL DEFAULT 'ACTIVE';

ALTER TABLE "jupiter"."cameras" RENAME COLUMN "status" TO "status_old";
ALTER TABLE "jupiter"."radars" RENAME COLUMN "status"  TO "status_old";
ALTER TYPE "jupiter"."DeviceStatusEnum" RENAME TO "DeviceStatusEnum_old";

ALTER TABLE "jupiter"."cameras" RENAME COLUMN "status_new" TO "status";
ALTER TABLE "jupiter"."radars" RENAME COLUMN "status_new" TO "status";
ALTER TYPE "jupiter"."DeviceStatusEnum_new" RENAME TO "DeviceStatusEnum";


ALTER TABLE "jupiter"."cameras" DROP COLUMN "status_old";
ALTER TABLE "jupiter"."radars" DROP COLUMN "status_old";
DROP TYPE "jupiter"."DeviceStatusEnum_old";