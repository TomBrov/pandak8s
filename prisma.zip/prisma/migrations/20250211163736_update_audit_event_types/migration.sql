/*
  Warnings:

  - The values [התחברות,התנתקות,יצירת משתמש,מחיקת משתמש,שינוי בפוליגון,החלפת מרשם פעיל ל...,כיול,הצפנה,כשירות,יצירה,מחיקה,עריכה,סיום טיפול,התחברות למצלמה,התנתקות ממצלמה] on the enum `ActionTypeEnum` will be removed. If these variants are still used in the database, this will fail.
  - Made the column `cellId` on table `op_logs` required. This step will fail if there are existing NULL values in that column.
  - Made the column `cellDispName` on table `op_logs` required. This step will fail if there are existing NULL values in that column.
  - Made the column `stationId` on table `op_logs` required. This step will fail if there are existing NULL values in that column.
  - Made the column `stationDispName` on table `op_logs` required. This step will fail if there are existing NULL values in that column.
  - Made the column `userId` on table `op_logs` required. This step will fail if there are existing NULL values in that column.
  - Made the column `username` on table `op_logs` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "archive"."ActionTypeEnum_new" AS ENUM ('LOGIN', 'LOGOUT', 'CONNECT_TO_CAMERA', 'DISCONNECT_FROM_CAMERA', 'CREATE_USER', 'DELETE_USER', 'POLYGON_CHANGE', 'SWITCH_ACTIVE_RECORD', 'CALIBRATION', 'ENCRYPTION', 'QUALIFICATION', 'CREATION', 'DELETION', 'EDITING', 'TREATMENT_END');
ALTER TABLE "archive"."op_logs" ALTER COLUMN "actionType" TYPE "archive"."ActionTypeEnum_new" USING ("actionType"::text::"archive"."ActionTypeEnum_new");
ALTER TYPE "archive"."ActionTypeEnum" RENAME TO "ActionTypeEnum_old";
ALTER TYPE "archive"."ActionTypeEnum_new" RENAME TO "ActionTypeEnum";
DROP TYPE "archive"."ActionTypeEnum_old";
COMMIT;

-- AlterTable
ALTER TABLE "archive"."op_logs" ALTER COLUMN "cellId" SET NOT NULL,
ALTER COLUMN "cellDispName" SET NOT NULL,
ALTER COLUMN "stationId" SET NOT NULL,
ALTER COLUMN "stationDispName" SET NOT NULL,
ALTER COLUMN "userId" SET NOT NULL,
ALTER COLUMN "username" SET NOT NULL;
