/*
  Warnings:

  - Added the required column `radar_type` to the `radars` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "jupiter"."RadarTypeEnum" AS ENUM ('REAL', 'SIMULATOR');

-- AlterTable
ALTER TABLE "jupiter"."radars" ADD COLUMN     "radar_type" "jupiter"."RadarTypeEnum";
UPDATE "jupiter"."radars" SET "radar_type" = 'SIMULATOR'::"jupiter"."RadarTypeEnum";
ALTER TABLE "jupiter"."radars" ALTER COLUMN "radar_type" SET NOT NULL;
