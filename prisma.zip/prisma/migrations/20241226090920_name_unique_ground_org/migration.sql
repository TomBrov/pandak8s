/*
  Warnings:

  - A unique constraint covering the columns `[name]` on the table `ground_org` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "ground_org_name_key" ON "jupiter"."ground_org"("name");
