-- CreateIndex
CREATE INDEX "tasks_indication_id_idx" ON "jupiter"."tasks"("indication_id");
