/*
  Warnings:

  - You are about to drop the column `recording_datetime` on the `camera_recordings` table. All the data in the column will be lost.
  - You are about to drop the column `url` on the `camera_recordings` table. All the data in the column will be lost.
  - Added the required column `hls_video_path` to the `camera_recordings` table without a default value. This is not possible if the table is not empty.
  - Added the required column `recording_start_time` to the `camera_recordings` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "jupiter"."camera_recordings" DROP COLUMN "recording_datetime",
DROP COLUMN "url",
ADD COLUMN     "hls_video_path" TEXT NOT NULL,
ADD COLUMN     "recording_start_time" TIMESTAMP(3) NOT NULL,
ALTER COLUMN "duration" DROP NOT NULL,
ALTER COLUMN "duration" SET DEFAULT 60;
