/*
  Warnings:

  - You are about to drop the column `cellDispName` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `cellId` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `stationDispName` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `stationId` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `userId` on the `op_logs` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "jupiter"."op_logs" DROP COLUMN "cellDispName",
DROP COLUMN "cellId",
DROP COLUMN "stationDispName",
DROP COLUMN "stationId",
DROP COLUMN "userId",
ADD COLUMN     "source" "archive"."OpLogSourceEnum" NOT NULL DEFAULT 'SYSTEM';
