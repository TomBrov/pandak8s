-- CreateTable
CREATE TABLE "jupiter"."last_indication_fetched" (
    "id" INTEGER NOT NULL,
    "last_fetched_time" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "last_indication_fetched_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "radar_indications_creation_time_idx" ON "jupiter"."radar_indications"("creation_time");
