-- Revert: Drop the 'is_in_resp_area' column from 'ground_org_polygon' table
ALTER TABLE "jupiter"."ground_org_polygon" DROP COLUMN "is_in_resp_area";

-- Revert: Drop the 'is_in_resp_area' column from 'segments' table
ALTER TABLE "jupiter"."segments" DROP COLUMN "is_in_resp_area";
