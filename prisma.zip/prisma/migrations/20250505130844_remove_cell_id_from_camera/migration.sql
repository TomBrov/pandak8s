/*
  Warnings:

  - You are about to drop the column `cellId` on the `cameras` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "jupiter"."cameras" DROP CONSTRAINT "cameras_cellId_fkey";

-- AlterTable
ALTER TABLE "jupiter"."cameras" DROP COLUMN "cellId";
