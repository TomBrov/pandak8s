-- AlterEnum
ALTER TYPE "jupiter"."jupiter_vendor" ADD VALUE 'MPEG_TS';
