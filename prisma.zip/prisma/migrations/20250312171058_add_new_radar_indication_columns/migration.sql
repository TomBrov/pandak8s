-- AlterTable
ALTER TABLE "jupiter"."radar_indications" ADD COLUMN     "direction" DOUBLE PRECISION,
ADD COLUMN     "radar_cross_section" DOUBLE PRECISION;
