/*
  Warnings:

  - You are about to drop the `task_statuses` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropTable
DROP TABLE "jupiter"."task_statuses";
