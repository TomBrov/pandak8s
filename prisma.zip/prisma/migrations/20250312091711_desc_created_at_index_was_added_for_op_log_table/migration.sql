-- AlterTable
ALTER TABLE "jupiter"."op_logs" ALTER COLUMN "created_at" SET DEFAULT CURRENT_TIMESTAMP,
ALTER COLUMN "updated_at" SET DEFAULT CURRENT_TIMESTAMP;

-- CreateIndex
CREATE INDEX "op_logs_created_at_idx_desc" ON "jupiter"."op_logs"("created_at" DESC);

-- RenameIndex
ALTER INDEX "jupiter"."radar_indications_creation_time_idx_desc" RENAME TO "radar_indications_creation_time_idx";
