/*
  Warnings:

  - The values [OTHER,FILE,MPEG_TS] on the enum `jupiter_vendor` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterEnum
BEGIN;

-- Manually added, convert existing MPEG_TS value to AVIV
ALTER TYPE "jupiter"."jupiter_vendor" RENAME VALUE 'MPEG_TS' TO 'AVIV';

CREATE TYPE "jupiter"."jupiter_vendor_new" AS ENUM ('FAKE', 'AVIV', 'BARKAN', 'NETZ');
ALTER TABLE "jupiter"."cameras" ALTER COLUMN "vendor" DROP DEFAULT;
ALTER TABLE "jupiter"."cameras" ALTER COLUMN "vendor" TYPE "jupiter"."jupiter_vendor_new" USING ("vendor"::text::"jupiter"."jupiter_vendor_new");
ALTER TYPE "jupiter"."jupiter_vendor" RENAME TO "jupiter_vendor_old";
ALTER TYPE "jupiter"."jupiter_vendor_new" RENAME TO "jupiter_vendor";
DROP TYPE "jupiter"."jupiter_vendor_old";
ALTER TABLE "jupiter"."cameras" ALTER COLUMN "vendor" SET DEFAULT 'FAKE';
COMMIT;
