/*
  Warnings:

  - You are about to drop the column `video_server_id` on the `cameras` table. All the data in the column will be lost.
  - You are about to drop the `jupiter_video_server` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "jupiter"."cameras" DROP CONSTRAINT "cameras_video_server_id_fkey";

-- AlterTable
ALTER TABLE "jupiter"."cameras" DROP COLUMN "video_server_id";

-- DropTable
DROP TABLE "jupiter"."jupiter_video_server";
