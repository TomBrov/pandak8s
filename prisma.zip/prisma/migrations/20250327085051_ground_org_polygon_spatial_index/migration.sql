-- CreateIndex PostGIS index
CREATE INDEX "ground_org_polygon_position_idx" ON "jupiter"."ground_org_polygon" USING gist("position" gist_geometry_ops_nd);

