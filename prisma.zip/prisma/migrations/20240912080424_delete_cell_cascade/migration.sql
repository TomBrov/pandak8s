-- DropForeignKey
ALTER TABLE "jupiter"."cells" DROP CONSTRAINT "cells_hamalId_fkey";

-- AddForeignKey
ALTER TABLE "jupiter"."cells" ADD CONSTRAINT "cells_hamalId_fkey" FOREIGN KEY ("hamalId") REFERENCES "jupiter"."hamals"("id") ON DELETE CASCADE ON UPDATE CASCADE;
