/*
  Warnings:

  - You are about to drop the column `fusedDetectionId` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the `camera_detections` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `detected_objects` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `fused_classifications` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `fused_detection` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `radar_detections` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "jupiter"."camera_detections" DROP CONSTRAINT "camera_detections_fusedDetectionId_fkey";

-- DropForeignKey
ALTER TABLE "jupiter"."detected_objects" DROP CONSTRAINT "detected_objects_fusedDetectionId_fkey";

-- DropForeignKey
ALTER TABLE "jupiter"."detected_objects" DROP CONSTRAINT "detected_objects_hamalId_fkey";

-- DropForeignKey
ALTER TABLE "jupiter"."radar_detections" DROP CONSTRAINT "radar_detections_fusedDetectionId_fkey";

-- DropForeignKey
ALTER TABLE "jupiter"."tasks" DROP CONSTRAINT "tasks_fusedDetectionId_fkey";

-- DropIndex
DROP INDEX "jupiter"."tasks_fusedDetectionId_key";

-- AlterTable
ALTER TABLE "jupiter"."tasks" DROP COLUMN "fusedDetectionId";

-- DropTable
DROP TABLE "jupiter"."camera_detections";

-- DropTable
DROP TABLE "jupiter"."detected_objects";

-- DropTable
DROP TABLE "jupiter"."fused_classifications";

-- DropTable
DROP TABLE "jupiter"."fused_detection";

-- DropTable
DROP TABLE "jupiter"."radar_detections";
