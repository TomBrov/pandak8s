ALTER TYPE jupiter."DeviceStatusEnum" ADD VALUE 'IN_MAINTENANCE';
