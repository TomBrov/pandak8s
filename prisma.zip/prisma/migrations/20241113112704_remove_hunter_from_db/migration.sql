/*
  Warnings:

  - You are about to drop the `hunter_detections` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "jupiter"."hunter_detections" DROP CONSTRAINT "hunter_detections_fusedDetectionId_fkey";

-- DropTable
DROP TABLE "jupiter"."hunter_detections";
