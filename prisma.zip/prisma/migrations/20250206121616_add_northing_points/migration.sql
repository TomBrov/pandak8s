-- CreateTable
CREATE TABLE "jupiter"."northing_points" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "position" geometry(Point, 4326) NOT NULL,
    "camera_id" TEXT NOT NULL,

    CONSTRAINT "northing_points_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "northing_points_camera_id_idx" ON "jupiter"."northing_points"("camera_id");

-- AddForeignKey
ALTER TABLE "jupiter"."northing_points" ADD CONSTRAINT "northing_points_camera_id_fkey" FOREIGN KEY ("camera_id") REFERENCES "jupiter"."cameras"("id") ON DELETE CASCADE ON UPDATE CASCADE;
