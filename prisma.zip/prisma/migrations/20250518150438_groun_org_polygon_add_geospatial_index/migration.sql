-- CreateIndex
CREATE INDEX "ground_org_polygon_position_idx" ON "jupiter"."ground_org_polygon" USING GIST ("position");
