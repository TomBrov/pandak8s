/*
  Warnings:

  - You are about to drop the column `hamalId` on the `cameras` table. All the data in the column will be lost.
  - You are about to drop the column `stationId` on the `cameras` table. All the data in the column will be lost.
  - You are about to drop the `OverlapPriority` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `_CameraToStation` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "jupiter"."OverlapPriority" DROP CONSTRAINT "OverlapPriority_overlappedPolygonId_fkey";

-- DropForeignKey
ALTER TABLE "jupiter"."OverlapPriority" DROP CONSTRAINT "OverlapPriority_polygonId_fkey";

-- DropForeignKey
ALTER TABLE "jupiter"."_CameraToStation" DROP CONSTRAINT "_CameraToStation_A_fkey";

-- DropForeignKey
ALTER TABLE "jupiter"."_CameraToStation" DROP CONSTRAINT "_CameraToStation_B_fkey";

-- DropForeignKey
ALTER TABLE "jupiter"."cameras" DROP CONSTRAINT "cameras_hamalId_fkey";

-- AlterTable
ALTER TABLE "jupiter"."cameras" DROP COLUMN "hamalId",
DROP COLUMN "stationId",
ADD COLUMN     "cellId" TEXT;

-- DropTable
DROP TABLE "jupiter"."OverlapPriority";

-- DropTable
DROP TABLE "jupiter"."_CameraToStation";

-- CreateTable
CREATE TABLE "jupiter"."overlap_priority" (
    "polygonId" TEXT NOT NULL,
    "overlappedPolygonId" TEXT NOT NULL,
    "ranking" INTEGER NOT NULL,

    CONSTRAINT "overlap_priority_pkey" PRIMARY KEY ("polygonId","overlappedPolygonId")
);

-- AddForeignKey
ALTER TABLE "jupiter"."overlap_priority" ADD CONSTRAINT "overlap_priority_polygonId_fkey" FOREIGN KEY ("polygonId") REFERENCES "jupiter"."camera_responsibility_polygons"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."overlap_priority" ADD CONSTRAINT "overlap_priority_overlappedPolygonId_fkey" FOREIGN KEY ("overlappedPolygonId") REFERENCES "jupiter"."camera_responsibility_polygons"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."cameras" ADD CONSTRAINT "cameras_cellId_fkey" FOREIGN KEY ("cellId") REFERENCES "jupiter"."cells"("id") ON DELETE CASCADE ON UPDATE CASCADE;
