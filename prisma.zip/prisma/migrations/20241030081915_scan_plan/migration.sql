-- CreateEnum
CREATE TYPE "jupiter"."segment_pattern" AS ENUM ('STRIP', 'PERIPHERAL');

-- CreateEnum
CREATE TYPE "jupiter"."segment_speed" AS ENUM ('X0_5', 'X1', 'X2');

-- CreateEnum
CREATE TYPE "jupiter"."segment_field" AS ENUM ('WIDE', 'NARROW', 'VERY_NARROW');

-- CreateTable
CREATE TABLE "jupiter"."scan_plans" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "camera_id" TEXT NOT NULL,

    CONSTRAINT "scan_plans_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."segments" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "pattern" "jupiter"."segment_pattern" NOT NULL,
    "speed" "jupiter"."segment_speed" NOT NULL,
    "field" "jupiter"."segment_field" NOT NULL,
    "positions" geometry(LineString, 4326) NOT NULL,
    "planId" TEXT NOT NULL,

    CONSTRAINT "segments_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "jupiter"."scan_plans" ADD CONSTRAINT "scan_plans_camera_id_fkey" FOREIGN KEY ("camera_id") REFERENCES "jupiter"."cameras"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."segments" ADD CONSTRAINT "segments_planId_fkey" FOREIGN KEY ("planId") REFERENCES "jupiter"."scan_plans"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
