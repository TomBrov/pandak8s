-- Insert initial last_indication_fetched with last_fetched_time as NOW()
INSERT INTO jupiter.last_indication_fetched ("id", "last_fetched_time")
VALUES (1,NOW())
ON CONFLICT ("id") DO NOTHING;