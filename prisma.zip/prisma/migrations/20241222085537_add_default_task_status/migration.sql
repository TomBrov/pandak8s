-- AlterTable
ALTER TABLE "jupiter"."tasks" ALTER COLUMN "status" SET DEFAULT 'OPEN';
