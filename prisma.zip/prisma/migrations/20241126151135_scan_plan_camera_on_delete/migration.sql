-- DropForeignKey
ALTER TABLE "jupiter"."scan_plans" DROP CONSTRAINT "scan_plans_camera_id_fkey";

-- AddForeignKey
ALTER TABLE "jupiter"."scan_plans" ADD CONSTRAINT "scan_plans_camera_id_fkey" FOREIGN KEY ("camera_id") REFERENCES "jupiter"."cameras"("id") ON DELETE CASCADE ON UPDATE CASCADE;
