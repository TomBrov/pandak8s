/*
  Warnings:

  - You are about to drop the column `camera_id` on the `scan_plans` table. All the data in the column will be lost.
  - Added the required column `hamal_id` to the `scan_plans` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "jupiter"."scan_plans" DROP CONSTRAINT "scan_plans_camera_id_fkey";

-- AlterTable
ALTER TABLE "jupiter"."scan_plans"
ADD COLUMN     "hamal_id" TEXT,
ADD COLUMN     "interval" INTEGER,
ADD COLUMN     "is_active" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "last_completion_time" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "score" INTEGER;

-- calcaulate hamal_id by camera_id
UPDATE jupiter.scan_plans
SET hamal_id = s.hamal_id
FROM (
	SELECT ha.id hamal_id, sp.id plan_id
	FROM jupiter.hamals ha
	INNER JOIN jupiter.cells ce ON ha.id = ce."hamalId"
	INNER JOIN jupiter.cameras ca ON ce.id = ca."cellId"
	INNER JOIN jupiter.scan_plans sp ON ca.id = sp.camera_id
) s 
WHERE id = s.plan_id;

-- delete scan_plans with hamal_id still null (means we couldn't link scan_plan->camera->cell->hamal)
DELETE FROM "jupiter"."scan_plans"
WHERE "hamal_id" IS NULL;

-- remove camera_id and make hamal_id not null
ALTER TABLE "jupiter"."scan_plans"
DROP COLUMN "camera_id",
ALTER COLUMN "hamal_id" SET NOT NULL;

-- AddForeignKey
ALTER TABLE "jupiter"."scan_plans" ADD CONSTRAINT "scan_plans_hamal_id_fkey" FOREIGN KEY ("hamal_id") REFERENCES "jupiter"."hamals"("id") ON DELETE CASCADE ON UPDATE CASCADE;