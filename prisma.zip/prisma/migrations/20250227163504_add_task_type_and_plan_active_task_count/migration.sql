-- CreateEnum
CREATE TYPE "jupiter"."TaskTypeEnum" AS ENUM ('RADAR', 'SCAN_SEGMENT');

-- AlterTable
ALTER TABLE "archive"."tasks" ADD COLUMN     "type" "jupiter"."TaskTypeEnum" NOT NULL DEFAULT 'RADAR',
ALTER COLUMN "detection_type" DROP NOT NULL;

-- AlterTable
ALTER TABLE "jupiter"."scan_plans" ADD COLUMN     "active_tasks_count" INTEGER NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "jupiter"."tasks" ADD COLUMN     "type" "jupiter"."TaskTypeEnum" NOT NULL DEFAULT 'RADAR',
ALTER COLUMN "detection_type" DROP NOT NULL;
