/*
  Warnings:

  - The values [ERROR,INITIALIZATION] on the enum `DeviceStatusEnum` will be removed. If these variants are still used in the database, this will fail.

*/
-- CreateEnum
CREATE TYPE "jupiter"."DeviceStatusReasonEnum" AS ENUM ('NOT_RECEIEVED_STATUS_REPORT', 'NOT_RECEIEVED_INDICATION_REPORT', 'NO_CONNECTION');

-- AlterEnum
BEGIN;
CREATE TYPE "jupiter"."DeviceStatusEnum_new" AS ENUM ('ACTIVE', 'SEMI_ACTIVE', 'INACTIVE');
ALTER TABLE "jupiter"."cameras" ALTER COLUMN "status" TYPE "jupiter"."DeviceStatusEnum_new" USING ("status"::text::"jupiter"."DeviceStatusEnum_new");
ALTER TABLE "jupiter"."radars" ALTER COLUMN "status" TYPE "jupiter"."DeviceStatusEnum_new" USING ("status"::text::"jupiter"."DeviceStatusEnum_new");
ALTER TYPE "jupiter"."DeviceStatusEnum" RENAME TO "DeviceStatusEnum_old";
ALTER TYPE "jupiter"."DeviceStatusEnum_new" RENAME TO "DeviceStatusEnum";
DROP TYPE "jupiter"."DeviceStatusEnum_old";
COMMIT;

-- AlterTable
ALTER TABLE "jupiter"."cameras" ADD COLUMN     "status_reason" "jupiter"."DeviceStatusReasonEnum"[];

-- AlterTable
ALTER TABLE "jupiter"."radars" ADD COLUMN     "status_reason" "jupiter"."DeviceStatusReasonEnum"[];
