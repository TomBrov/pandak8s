-- DropForeignKey
ALTER TABLE "jupiter"."segments" DROP CONSTRAINT "segments_planId_fkey";

-- AddForeignKey
ALTER TABLE "jupiter"."segments" ADD CONSTRAINT "segments_planId_fkey" FOREIGN KEY ("planId") REFERENCES "jupiter"."scan_plans"("id") ON DELETE CASCADE ON UPDATE CASCADE;
