-- change the type of the positions column from geometry(LineString, 4326) to geometry(LineStringZ, 4326)
BEGIN;

-- Add temporary LineStringZ column
ALTER TABLE "jupiter"."segments"
ADD COLUMN positions_temp geometry(LineStringZ, 4326);

-- Migrate data converting to LineStringZ
UPDATE "jupiter"."segments"
SET positions_temp = ST_Force3D(positions);

-- Drop old column
ALTER TABLE "jupiter"."segments"
DROP COLUMN positions;

-- Rename temp column back to positions
ALTER TABLE "jupiter"."segments"
RENAME COLUMN positions_temp TO positions;

COMMIT;