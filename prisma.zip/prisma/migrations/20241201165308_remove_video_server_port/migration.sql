/*
  Warnings:

  - You are about to drop the column `port` on the `jupiter_video_server` table. All the data in the column will be lost.

*/
-- DropIndex
DROP INDEX "jupiter"."jupiter_video_server_port_key";

-- AlterTable
ALTER TABLE "jupiter"."jupiter_video_server" DROP COLUMN "port";
