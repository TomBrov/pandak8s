/*
  Warnings:

  - You are about to drop the column `is_recording` on the `channels` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "jupiter"."channels" DROP COLUMN "is_recording";
