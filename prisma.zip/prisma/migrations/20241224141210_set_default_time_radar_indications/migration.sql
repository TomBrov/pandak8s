-- AlterTable
ALTER TABLE "jupiter"."radar_indications" ALTER COLUMN "creation_time" SET DEFAULT CURRENT_TIMESTAMP;
