/* Migrate commonLang.position to PointZ */
ALTER TABLE "jupiter"."commonLang" 
ALTER COLUMN "position" TYPE geometry(PointZ, 4326) 
USING ST_Force3D("position");


/* Migrate northing_points.position to PointZ */
ALTER TABLE "jupiter"."northing_points" 
ALTER COLUMN "position" TYPE geometry(PointZ, 4326) 
USING ST_Force3D("position");
