-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "jupiter";

-- CreateExtension
CREATE EXTENSION IF NOT EXISTS "postgis";

-- CreateExtension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- CreateEnum
CREATE TYPE "jupiter"."TaskClassificationEnum" AS ENUM ('OUR_FORCES', 'FALSE_ALARM', 'DETECTION_OF_ROUTINE', 'EXCEPTION_DETECTION', 'EVENT', 'SUSPICIOUS');

-- CreateEnum
CREATE TYPE "jupiter"."SpotterClassificationEnum" AS ENUM ('PERSON', 'VEHICLE', 'ANIMAL', 'WILED_ANIMAL', 'ARMED_MAN', 'GROUP_OF_PEOPLE', 'HERD_WITH_A_SHEPHERD', 'HERD_WITHOUT_A_SHEPHERD', 'HOME_VISIT', 'FENCE_ALERT');

-- CreateEnum
CREATE TYPE "jupiter"."FusedClassificationEnum" AS ENUM ('VEHICLE', 'HUMAN', 'ANIMAL', 'UNIDENTIFIED', 'MOVING_UNIDENTIFIED');

-- CreateEnum
CREATE TYPE "jupiter"."TaskStatusEnum" AS ENUM ('IN_PROGRESS', 'OPEN', 'DONE');

-- CreateEnum
CREATE TYPE "jupiter"."DeviceStatusEnum" AS ENUM ('ACTIVE', 'INACTIVE', 'ERROR', 'INITIALIZATION');

-- CreateEnum
CREATE TYPE "jupiter"."StationType" AS ENUM ('MONITOR', 'INVESTIGATOR');

-- CreateEnum
CREATE TYPE "jupiter"."UserRolesEnum" AS ENUM ('SUPER_ADMIN', 'COMMANDER', 'SPOTTER');

-- CreateEnum
CREATE TYPE "jupiter"."jupiter_vendor" AS ENUM ('FAKE', 'OTHER', 'FILE');

-- CreateTable
CREATE TABLE "jupiter"."camera_responsibility_polygons" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "position" geometry(Polygon, 4326) NOT NULL,
    "camera_id" TEXT NOT NULL,
    "cell_id" TEXT NOT NULL,
    "cell_row_date" SERIAL NOT NULL,

    CONSTRAINT "camera_responsibility_polygons_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."OverlapPriority" (
    "polygonId" TEXT NOT NULL,
    "overlappedPolygonId" TEXT NOT NULL,
    "ranking" INTEGER NOT NULL,

    CONSTRAINT "OverlapPriority_pkey" PRIMARY KEY ("polygonId","overlappedPolygonId")
);

-- CreateTable
CREATE TABLE "jupiter"."cells" (
    "id" TEXT NOT NULL,
    "display_name" TEXT NOT NULL,
    "hamalId" TEXT NOT NULL,

    CONSTRAINT "cells_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."ground_org" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "is_turn_on" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ground_org_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."ground_org_polygon" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "position" geometry(Polygon, 4326) NOT NULL,
    "vehicle_grade" INTEGER NOT NULL,
    "human_grade" INTEGER NOT NULL,
    "animal_grade" INTEGER NOT NULL,
    "undefiend_grade" INTEGER NOT NULL,
    "moving_undefiend_grade" INTEGER NOT NULL,
    "ground_org_id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ground_org_polygon_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."jupiter_video_server" (
    "task_id" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "port" INTEGER,

    CONSTRAINT "jupiter_video_server_pkey" PRIMARY KEY ("task_id")
);

-- CreateTable
CREATE TABLE "jupiter"."users" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "ssn" TEXT NOT NULL,
    "military_id" TEXT,
    "email" TEXT NOT NULL,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "phoneNumber" TEXT NOT NULL,
    "hashedPassword" TEXT NOT NULL,
    "hashedRt" TEXT,
    "hamalId" TEXT NOT NULL,
    "role" "jupiter"."UserRolesEnum" NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."hamals" (
    "id" TEXT NOT NULL,
    "display_name" TEXT NOT NULL,

    CONSTRAINT "hamals_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."commonLang" (
    "id" TEXT NOT NULL,
    "lat" DOUBLE PRECISION NOT NULL,
    "lng" DOUBLE PRECISION NOT NULL,
    "description" TEXT NOT NULL,
    "hamalId" TEXT NOT NULL,

    CONSTRAINT "commonLang_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."device_statuses" (
    "id" TEXT NOT NULL,
    "name" "jupiter"."DeviceStatusEnum" NOT NULL,
    "displayName" TEXT NOT NULL,

    CONSTRAINT "device_statuses_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."cameras" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "color" TEXT NOT NULL,
    "lat" DOUBLE PRECISION NOT NULL,
    "ip" TEXT NOT NULL DEFAULT '0.0.0.0',
    "port" INTEGER DEFAULT 80,
    "streaming_port" INTEGER,
    "streaming_path" TEXT,
    "long" DOUBLE PRECISION NOT NULL,
    "status" "jupiter"."DeviceStatusEnum" NOT NULL,
    "is_free" BOOLEAN NOT NULL DEFAULT true,
    "is_recording" BOOLEAN NOT NULL DEFAULT false,
    "vendor" "jupiter"."jupiter_vendor" NOT NULL DEFAULT 'FAKE',
    "hamalId" TEXT NOT NULL,
    "stationId" TEXT,
    "video_server_id" TEXT,

    CONSTRAINT "cameras_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."camera_recordings" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "camera_id" TEXT NOT NULL,
    "recording_datetime" TIMESTAMP(3) NOT NULL,
    "duration" DOUBLE PRECISION NOT NULL,
    "file_name" TEXT NOT NULL,
    "url" TEXT NOT NULL,

    CONSTRAINT "camera_recordings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."radars" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "color" TEXT NOT NULL,
    "lat" DOUBLE PRECISION NOT NULL,
    "long" DOUBLE PRECISION NOT NULL,
    "status" "jupiter"."DeviceStatusEnum" NOT NULL,
    "hamalId" TEXT NOT NULL,

    CONSTRAINT "radars_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."stations" (
    "id" TEXT NOT NULL,
    "display_name" TEXT NOT NULL,
    "type" "jupiter"."StationType" NOT NULL,
    "cell_row_date" SERIAL NOT NULL,
    "active_spotter_id" TEXT,
    "cell_id" TEXT NOT NULL,

    CONSTRAINT "stations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."tasks" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "taskClassification" "jupiter"."TaskClassificationEnum",
    "spotterClassification" "jupiter"."SpotterClassificationEnum",
    "status" "jupiter"."TaskStatusEnum" NOT NULL,
    "score" DOUBLE PRECISION NOT NULL,
    "fusedDetectionId" TEXT NOT NULL,
    "hamalId" TEXT NOT NULL,
    "stationId" TEXT,

    CONSTRAINT "tasks_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."task_classifications" (
    "id" TEXT NOT NULL,
    "name" "jupiter"."TaskClassificationEnum" NOT NULL,
    "displayName" TEXT NOT NULL,

    CONSTRAINT "task_classifications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."spotter_classifications" (
    "id" TEXT NOT NULL,
    "name" "jupiter"."SpotterClassificationEnum" NOT NULL,
    "displayName" TEXT NOT NULL,

    CONSTRAINT "spotter_classifications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."task_statuses" (
    "id" TEXT NOT NULL,
    "name" "jupiter"."TaskStatusEnum" NOT NULL,
    "displayName" TEXT NOT NULL,

    CONSTRAINT "task_statuses_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."detected_objects" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "score" DOUBLE PRECISION NOT NULL,
    "hamalId" TEXT NOT NULL,
    "fusedDetectionId" TEXT,

    CONSTRAINT "detected_objects_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."fused_detection" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "fusedClassification" "jupiter"."FusedClassificationEnum" NOT NULL,
    "lat" DOUBLE PRECISION NOT NULL,
    "long" DOUBLE PRECISION NOT NULL,

    CONSTRAINT "fused_detection_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."fused_classifications" (
    "id" TEXT NOT NULL,
    "name" "jupiter"."FusedClassificationEnum" NOT NULL,
    "displayName" TEXT NOT NULL,

    CONSTRAINT "fused_classifications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."camera_detections" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "fusedDetectionId" TEXT NOT NULL,

    CONSTRAINT "camera_detections_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."radar_detections" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "fusedDetectionId" TEXT NOT NULL,

    CONSTRAINT "radar_detections_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."hunter_detections" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "fusedDetectionId" TEXT NOT NULL,

    CONSTRAINT "hunter_detections_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jupiter"."_CameraToStation" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "jupiter_video_server_address_key" ON "jupiter"."jupiter_video_server"("address");

-- CreateIndex
CREATE UNIQUE INDEX "jupiter_video_server_port_key" ON "jupiter"."jupiter_video_server"("port");

-- CreateIndex
CREATE UNIQUE INDEX "users_ssn_key" ON "jupiter"."users"("ssn");

-- CreateIndex
CREATE UNIQUE INDEX "users_military_id_key" ON "jupiter"."users"("military_id");

-- CreateIndex
CREATE UNIQUE INDEX "stations_active_spotter_id_key" ON "jupiter"."stations"("active_spotter_id");

-- CreateIndex
CREATE UNIQUE INDEX "tasks_fusedDetectionId_key" ON "jupiter"."tasks"("fusedDetectionId");

-- CreateIndex
CREATE UNIQUE INDEX "detected_objects_fusedDetectionId_key" ON "jupiter"."detected_objects"("fusedDetectionId");

-- CreateIndex
CREATE UNIQUE INDEX "_CameraToStation_AB_unique" ON "jupiter"."_CameraToStation"("A", "B");

-- CreateIndex
CREATE INDEX "_CameraToStation_B_index" ON "jupiter"."_CameraToStation"("B");

-- AddForeignKey
ALTER TABLE "jupiter"."camera_responsibility_polygons" ADD CONSTRAINT "camera_responsibility_polygons_camera_id_fkey" FOREIGN KEY ("camera_id") REFERENCES "jupiter"."cameras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."camera_responsibility_polygons" ADD CONSTRAINT "camera_responsibility_polygons_cell_id_fkey" FOREIGN KEY ("cell_id") REFERENCES "jupiter"."cells"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."OverlapPriority" ADD CONSTRAINT "OverlapPriority_polygonId_fkey" FOREIGN KEY ("polygonId") REFERENCES "jupiter"."camera_responsibility_polygons"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."OverlapPriority" ADD CONSTRAINT "OverlapPriority_overlappedPolygonId_fkey" FOREIGN KEY ("overlappedPolygonId") REFERENCES "jupiter"."camera_responsibility_polygons"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."cells" ADD CONSTRAINT "cells_hamalId_fkey" FOREIGN KEY ("hamalId") REFERENCES "jupiter"."hamals"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."ground_org_polygon" ADD CONSTRAINT "ground_org_polygon_ground_org_id_fkey" FOREIGN KEY ("ground_org_id") REFERENCES "jupiter"."ground_org"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."users" ADD CONSTRAINT "users_hamalId_fkey" FOREIGN KEY ("hamalId") REFERENCES "jupiter"."hamals"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."commonLang" ADD CONSTRAINT "commonLang_hamalId_fkey" FOREIGN KEY ("hamalId") REFERENCES "jupiter"."hamals"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."cameras" ADD CONSTRAINT "cameras_hamalId_fkey" FOREIGN KEY ("hamalId") REFERENCES "jupiter"."hamals"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."cameras" ADD CONSTRAINT "cameras_video_server_id_fkey" FOREIGN KEY ("video_server_id") REFERENCES "jupiter"."jupiter_video_server"("task_id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."camera_recordings" ADD CONSTRAINT "camera_recordings_camera_id_fkey" FOREIGN KEY ("camera_id") REFERENCES "jupiter"."cameras"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."radars" ADD CONSTRAINT "radars_hamalId_fkey" FOREIGN KEY ("hamalId") REFERENCES "jupiter"."hamals"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."stations" ADD CONSTRAINT "stations_cell_id_fkey" FOREIGN KEY ("cell_id") REFERENCES "jupiter"."cells"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."stations" ADD CONSTRAINT "stations_active_spotter_id_fkey" FOREIGN KEY ("active_spotter_id") REFERENCES "jupiter"."users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."tasks" ADD CONSTRAINT "tasks_fusedDetectionId_fkey" FOREIGN KEY ("fusedDetectionId") REFERENCES "jupiter"."fused_detection"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."tasks" ADD CONSTRAINT "tasks_hamalId_fkey" FOREIGN KEY ("hamalId") REFERENCES "jupiter"."hamals"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."tasks" ADD CONSTRAINT "tasks_stationId_fkey" FOREIGN KEY ("stationId") REFERENCES "jupiter"."stations"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."detected_objects" ADD CONSTRAINT "detected_objects_hamalId_fkey" FOREIGN KEY ("hamalId") REFERENCES "jupiter"."hamals"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."detected_objects" ADD CONSTRAINT "detected_objects_fusedDetectionId_fkey" FOREIGN KEY ("fusedDetectionId") REFERENCES "jupiter"."fused_detection"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."camera_detections" ADD CONSTRAINT "camera_detections_fusedDetectionId_fkey" FOREIGN KEY ("fusedDetectionId") REFERENCES "jupiter"."fused_detection"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."radar_detections" ADD CONSTRAINT "radar_detections_fusedDetectionId_fkey" FOREIGN KEY ("fusedDetectionId") REFERENCES "jupiter"."fused_detection"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."hunter_detections" ADD CONSTRAINT "hunter_detections_fusedDetectionId_fkey" FOREIGN KEY ("fusedDetectionId") REFERENCES "jupiter"."fused_detection"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."_CameraToStation" ADD CONSTRAINT "_CameraToStation_A_fkey" FOREIGN KEY ("A") REFERENCES "jupiter"."cameras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."_CameraToStation" ADD CONSTRAINT "_CameraToStation_B_fkey" FOREIGN KEY ("B") REFERENCES "jupiter"."stations"("id") ON DELETE CASCADE ON UPDATE CASCADE;
