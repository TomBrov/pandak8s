/*
  Warnings:

  - Made the column `positions` on table `segments` required. This step will fail if there are existing NULL values in that column.

*/
-- DropIndex
DROP INDEX "archive"."camera_responsibility_polygons_time_idx";

-- DropIndex
DROP INDEX "archive"."ground_org_polygons_time_idx";

-- DropIndex
DROP INDEX "archive"."segments_time_idx";

-- DropIndex
DROP INDEX "jupiter"."ground_org_polygon_position_idx";

-- DropIndex
DROP INDEX "jupiter"."tasks_position_idx";

-- AlterTable
ALTER TABLE "jupiter"."cameras" ALTER COLUMN "status" DROP DEFAULT;

-- AlterTable
ALTER TABLE "jupiter"."channel_recordings" ADD COLUMN "is_compressed" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "jupiter"."radars" ALTER COLUMN "status" DROP DEFAULT;

-- AlterTable
ALTER TABLE "jupiter"."screen_recordings" ADD COLUMN "is_compressed" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "jupiter"."segments" ALTER COLUMN "positions" SET NOT NULL;
