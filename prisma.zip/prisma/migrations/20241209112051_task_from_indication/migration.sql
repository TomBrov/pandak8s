/*
  Warnings:

  - You are about to drop the column `hamalId` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `spotterClassification` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `stationId` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `taskClassification` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the `indications` table. If the table is not empty, all the data it contains will be lost.
  - A unique constraint covering the columns `[indication_id,hamal_id]` on the table `tasks` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `hamal_id` to the `tasks` table without a default value. This is not possible if the table is not empty.
  - Added the required column `position` to the `tasks` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "jupiter"."tasks" DROP CONSTRAINT "tasks_hamalId_fkey";

-- DropForeignKey
ALTER TABLE "jupiter"."tasks" DROP CONSTRAINT "tasks_stationId_fkey";


-- DONT DO THIS AT HOME!!!
TRUNCATE TABLE "jupiter"."tasks";

-- AlterTable
ALTER TABLE "jupiter"."tasks" DROP COLUMN "hamalId",
DROP COLUMN "spotterClassification",
DROP COLUMN "stationId",
DROP COLUMN "taskClassification",
ADD COLUMN     "hamal_id" TEXT NOT NULL,
ADD COLUMN     "indication_id" TEXT,
ADD COLUMN     "position" geometry(Point, 4326) NOT NULL,
ADD COLUMN     "spotter_classification" "jupiter"."SpotterClassificationEnum",
ADD COLUMN     "station_id" TEXT,
ADD COLUMN     "task_classification" "jupiter"."TaskClassificationEnum";

-- DropTable
DROP TABLE "jupiter"."indications";

-- CreateTable
CREATE TABLE "jupiter"."radar_indications" (
    "creation_time" TIMESTAMP(3) NOT NULL,
    "id" TEXT NOT NULL,
    "radar_device_name" TEXT NOT NULL,
    "radar_indication_id" TEXT NOT NULL,
    "detection_type" TEXT NOT NULL,
    "coordinates" geometry(Point, 4326) NOT NULL,

    CONSTRAINT "radar_indications_pkey" PRIMARY KEY ("creation_time","id")
);

-- CreateIndex
CREATE UNIQUE INDEX "tasks_indication_id_hamal_id_key" ON "jupiter"."tasks"("indication_id", "hamal_id");

-- AddForeignKey
ALTER TABLE "jupiter"."tasks" ADD CONSTRAINT "tasks_hamal_id_fkey" FOREIGN KEY ("hamal_id") REFERENCES "jupiter"."hamals"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."tasks" ADD CONSTRAINT "tasks_station_id_fkey" FOREIGN KEY ("station_id") REFERENCES "jupiter"."stations"("id") ON DELETE SET NULL ON UPDATE CASCADE;
