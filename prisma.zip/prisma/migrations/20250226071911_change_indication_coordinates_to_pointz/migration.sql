/* Migrate radar_indications.coordinates to PointZ */
ALTER TABLE "jupiter"."radar_indications" 
ALTER COLUMN "coordinates" TYPE geometry(PointZ, 4326) 
USING ST_Force3D("coordinates");


/* Migrate tasks.position to PointZ */
ALTER TABLE "jupiter"."tasks" 
ALTER COLUMN "position" TYPE geometry(PointZ, 4326) 
USING ST_Force3D("position");

/* Migrate radar_indications.coordinates to PointZ */
ALTER TABLE "archive"."radar_indications" 
ALTER COLUMN "coordinates" TYPE geometry(PointZ, 4326) 
USING ST_Force3D("coordinates");


/* Migrate tasks.position to PointZ */
ALTER TABLE "archive"."tasks" 
ALTER COLUMN "position" TYPE geometry(PointZ, 4326) 
USING ST_Force3D("position");