-- Migration: add_new_channel_enum_values.sql
-- enum changes must be committed before they can be used - so adding a designated migration for this step
ALTER TYPE "jupiter"."ChannelTypeEnum" ADD VALUE IF NOT EXISTS 'PRIMARY';
ALTER TYPE "jupiter"."ChannelTypeEnum" ADD VALUE IF NOT EXISTS 'SECONDARY';
