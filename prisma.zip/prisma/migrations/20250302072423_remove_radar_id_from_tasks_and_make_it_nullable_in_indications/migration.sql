/*
  Warnings:

  - You are about to drop the column `radar_id` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `radar_id` on the `tasks` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "jupiter"."radar_indications" DROP CONSTRAINT "radar_indications_radar_id_fkey";

-- DropForeignKey
ALTER TABLE "jupiter"."tasks" DROP CONSTRAINT "tasks_radar_id_fkey";

-- AlterTable
ALTER TABLE "archive"."tasks" DROP COLUMN "radar_id";

-- AlterTable
ALTER TABLE "jupiter"."tasks" DROP COLUMN "radar_id";

-- AddForeignKey
ALTER TABLE "jupiter"."radar_indications" ADD CONSTRAINT "radar_indications_radar_id_fkey" FOREIGN KEY ("radar_id") REFERENCES "jupiter"."radars"("id") ON DELETE SET NULL ON UPDATE CASCADE;
