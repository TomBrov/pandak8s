/*
  Warnings:

  - The values [CALIBRATION,ENCRYPTION] on the enum `ActionTypeEnum` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "archive"."ActionTypeEnum_new" AS ENUM ('LOGIN', 'LOGOUT', 'CREATE_USER', 'DELETE_USER', 'NORTHING_POINT', 'DISCONNECT_FROM_CAMERA', 'CONNECT_TO_CAMERA', 'CAMERA_CALIBRATION', 'CAMERA_CREATION', 'CAMERA_DELETION', 'CAMERA_EDITING', 'RADAR_CREATION', 'RADAR_DELETION', 'RADAR_EDITING', 'QUALIFICATION', 'POLYGON_CHANGE', 'SWITCH_ACTIVE_RECORD', 'TREATMENT_END');
ALTER TABLE "jupiter"."op_logs" ALTER COLUMN "actionType" TYPE "archive"."ActionTypeEnum_new" USING ("actionType"::text::"archive"."ActionTypeEnum_new");
ALTER TYPE "archive"."ActionTypeEnum" RENAME TO "ActionTypeEnum_old";
ALTER TYPE "archive"."ActionTypeEnum_new" RENAME TO "ActionTypeEnum";
DROP TYPE "archive"."ActionTypeEnum_old";
COMMIT;
