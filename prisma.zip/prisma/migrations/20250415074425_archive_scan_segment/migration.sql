-- CreateTable archive scan segments
CREATE TABLE "archive"."segments" (
    "id" TEXT NOT NULL,
    "time" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "name" TEXT NOT NULL,
    "pattern" "jupiter"."segment_pattern" NOT NULL,
    "speed" "jupiter"."segment_speed" NOT NULL,
    "field" "jupiter"."segment_field" NOT NULL,
    "positions" geometry(LineStringZ, 4326) NOT NULL,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "planId" TEXT NOT NULL,

    CONSTRAINT "segments_pkey" PRIMARY KEY ("id","time")
);

-- set hypertable for segments with interval of 4 HRS
SELECT create_hypertable('archive.segments', 'time', chunk_time_interval => INTERVAL '4 hours');

-- add retention with interval of 3 months
SELECT add_retention_policy('archive.segments', drop_after => INTERVAL '3 months');