-- AlterEnum
ALTER TYPE "jupiter"."DeviceStatusEnum" ADD VALUE 'SEMI_ACTIVE';
