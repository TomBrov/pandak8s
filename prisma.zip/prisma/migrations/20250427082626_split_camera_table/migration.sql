-- CreateTable
CREATE TABLE "jupiter"."cameras_connections" (
    "id" TEXT NOT NULL,
    "status" "jupiter"."DeviceStatusEnum" NOT NULL,
    "status_reason" "jupiter"."DeviceStatusReasonEnum"[] DEFAULT ARRAY[]::"jupiter"."DeviceStatusReasonEnum"[],
    "active_spotter_id" TEXT,
    "camera_id" TEXT NOT NULL,

    CONSTRAINT "cameras_connections_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "cameras_connections_active_spotter_id_key" ON "jupiter"."cameras_connections"("active_spotter_id");

-- CreateIndex
CREATE UNIQUE INDEX "cameras_connections_camera_id_key" ON "jupiter"."cameras_connections"("camera_id");

-- AddForeignKey
ALTER TABLE "jupiter"."cameras_connections" ADD CONSTRAINT "cameras_connections_active_spotter_id_fkey" FOREIGN KEY ("active_spotter_id") REFERENCES "jupiter"."users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "jupiter"."cameras_connections" ADD CONSTRAINT "cameras_connections_camera_id_fkey" FOREIGN KEY ("camera_id") REFERENCES "jupiter"."cameras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Transfer data from cameras to cameras_connections
INSERT INTO "jupiter"."cameras_connections" (
    "id",
    "status",
    "status_reason",
    "active_spotter_id",
    "camera_id"
)
SELECT
    gen_random_uuid() AS "id",
    "status",
    "status_reason",
    "active_spotter_id",
    "id" AS "camera_id"
FROM "jupiter"."cameras";

-- DropForeignKey
ALTER TABLE "jupiter"."cameras" DROP CONSTRAINT "cameras_active_spotter_id_fkey";

-- DropIndex
DROP INDEX "jupiter"."cameras_active_spotter_id_key";

-- AlterTable
ALTER TABLE "jupiter"."cameras" 
DROP COLUMN "active_spotter_id",
DROP COLUMN "status",
DROP COLUMN "status_reason";
