/* Migrate camera.position to PointZ */
ALTER TABLE "jupiter"."cameras" 
ALTER COLUMN "position" TYPE geometry(PointZ, 4326) 
USING ST_Force3D("position");


/* Migrate radar.position to PointZ */
ALTER TABLE "jupiter"."radars" 
ALTER COLUMN "position" TYPE geometry(PointZ, 4326) 
USING ST_Force3D("position");
