-- AlterTable
ALTER TABLE "jupiter"."tasks" ADD COLUMN     "ground_org_polygon_id" TEXT;

-- AddForeignKey
ALTER TABLE "jupiter"."tasks" ADD CONSTRAINT "tasks_ground_org_polygon_id_fkey" FOREIGN KEY ("ground_org_polygon_id") REFERENCES "jupiter"."ground_org_polygon"("id") ON DELETE SET NULL ON UPDATE CASCADE;
