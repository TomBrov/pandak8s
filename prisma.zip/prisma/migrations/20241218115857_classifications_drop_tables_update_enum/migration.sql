/*
  Warnings:

  - You are about to drop the `spotter_classifications` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `task_classifications` table. If the table is not empty, all the data it contains will be lost.

*/
-- AlterEnum
ALTER TYPE "jupiter"."SpotterClassificationEnum" ADD VALUE 'ANIMALS';

-- DropTable
DROP TABLE "jupiter"."spotter_classifications";

-- DropTable
DROP TABLE "jupiter"."task_classifications";
