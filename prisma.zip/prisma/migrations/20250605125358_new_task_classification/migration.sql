-- AlterEnum
ALTER TYPE "jupiter"."SpotterClassificationEnum" ADD VALUE 'UNIDENTIFIED';
