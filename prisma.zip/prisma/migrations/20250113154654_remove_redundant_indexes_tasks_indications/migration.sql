-- DropIndex
DROP INDEX "jupiter"."radar_indications_creation_time_idx";

-- DropIndex
DROP INDEX "jupiter"."tasks_updated_at_idx";
