-- DropTable
DROP TABLE "jupiter"."last_indication_fetched";
