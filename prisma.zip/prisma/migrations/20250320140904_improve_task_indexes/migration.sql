/*
  Warnings:

  - Made the column `positions` on table `segments` required. This step will fail if there are existing NULL values in that column.

*/
-- DropIndex
DROP INDEX "jupiter"."tasks_status_score_updated_at_idx";

-- CreateIndex
CREATE INDEX "tasks_status_score_updated_at_type_idx" ON "jupiter"."tasks"("status" DESC, "score" DESC, "updated_at" DESC, "type" DESC);

-- CreateIndex PostGIS index
CREATE INDEX "tasks_position_idx" ON "jupiter"."tasks" USING gist("position" gist_geometry_ops_nd);
