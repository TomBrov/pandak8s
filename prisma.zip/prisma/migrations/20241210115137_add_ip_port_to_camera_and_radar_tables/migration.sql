/*
  Warnings:

  - Made the column `port` on table `cameras` required. This step will fail if there are existing NULL values in that column.
  - Added the required column `ip` to the `radars` table without a default value. This is not possible if the table is not empty.
  - Added the required column `port` to the `radars` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "jupiter"."cameras" ALTER COLUMN "ip" DROP DEFAULT,
ALTER COLUMN "port" SET NOT NULL,
ALTER COLUMN "port" DROP DEFAULT;

-- AlterTable
ALTER TABLE "jupiter"."radars" ADD COLUMN     "ip" TEXT NOT NULL,
ADD COLUMN     "port" INTEGER NOT NULL;
