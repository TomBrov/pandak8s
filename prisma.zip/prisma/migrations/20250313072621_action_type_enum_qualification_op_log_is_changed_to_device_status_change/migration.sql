/*
  Warnings:

  - The values [QUALIFICATION] on the enum `ActionTypeEnum` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "archive"."ActionTypeEnum_new" AS ENUM ('LOGIN', 'LOGOUT', 'CREATE_USER', 'DELETE_USER', 'CAMERA_SET_NORTH', 'DISCONNECT_FROM_CAMERA', 'CONNECT_TO_CAMERA', 'CAMERA_CALIBRATION', 'CAMERA_CREATION', 'CAMERA_DELETION', 'CAMERA_EDITING', 'RADAR_CREATION', 'RADAR_DELETION', 'RADAR_EDITING', 'DEVICE_STATUS_CHANGE', 'POLYGON_CHANGE', 'SWITCH_ACTIVE_RECORD', 'TASK_COMPLETION');
ALTER TABLE "jupiter"."op_logs" ALTER COLUMN "actionType" TYPE "archive"."ActionTypeEnum_new" USING ("actionType"::text::"archive"."ActionTypeEnum_new");
ALTER TYPE "archive"."ActionTypeEnum" RENAME TO "ActionTypeEnum_old";
ALTER TYPE "archive"."ActionTypeEnum_new" RENAME TO "ActionTypeEnum";
DROP TYPE "archive"."ActionTypeEnum_old";
COMMIT;

-- RenameIndex
ALTER INDEX "jupiter"."op_logs_created_at_idx_desc" RENAME TO "op_logs_created_at_idx";
