/*
  Warnings:

  - The values [IN_PROGRESS,OPEN,DONE] on the enum `TaskStatusEnum` will be removed. If these variants are still used in the database, this will fail.

*/
-- CreateEnum
/*
  Warnings:

  - The values [IN_PROGRESS,OPEN,DONE] on the enum `TaskStatusEnum` will be removed. If these variants are still used in the database, this will fail.

*/
-- Alter the current status column
BEGIN;
CREATE TYPE "jupiter"."TaskStatusEnum_new" AS ENUM ('NEW', 'ACTIVE', 'CLOSED');

ALTER TABLE "jupiter"."tasks" RENAME COLUMN "status" TO "status_old";
ALTER TABLE "jupiter"."tasks" ADD COLUMN "status" "jupiter"."TaskStatusEnum_new";
UPDATE "jupiter"."tasks" SET "status" = 'ACTIVE' WHERE "status_old" = 'IN_PROGRESS';
UPDATE "jupiter"."tasks" SET "status" = 'CLOSED' WHERE "status_old" = 'DONE';
UPDATE "jupiter"."tasks" SET "status" = 'NEW' WHERE "status_old" = 'OPEN';
ALTER TABLE "jupiter"."tasks" DROP COLUMN "status_old";

ALTER TABLE "jupiter"."tasks" ALTER COLUMN "status" SET DEFAULT 'NEW';
ALTER TABLE "jupiter"."tasks" ALTER COLUMN "status" SET NOT NULL;

-- fix archive table
ALTER TABLE "archive"."tasks" RENAME COLUMN "status" TO "status_old";
ALTER TABLE "archive"."tasks" ADD COLUMN "status" "jupiter"."TaskStatusEnum_new";
UPDATE "archive"."tasks" SET "status" = 'ACTIVE' WHERE "status_old" = 'IN_PROGRESS';
UPDATE "archive"."tasks" SET "status" = 'CLOSED' WHERE "status_old" = 'DONE';
UPDATE "archive"."tasks" SET "status" = 'NEW' WHERE "status_old" = 'OPEN';
ALTER TABLE "archive"."tasks" DROP COLUMN "status_old";

ALTER TYPE "jupiter"."TaskStatusEnum" RENAME TO "TaskStatusEnum_old";
ALTER TYPE "jupiter"."TaskStatusEnum_new" RENAME TO "TaskStatusEnum";
DROP TYPE "jupiter"."TaskStatusEnum_old";
COMMIT;

-- Add status reason column
BEGIN;
CREATE TYPE "jupiter"."TaskStatusReasonEnum" AS ENUM ('NEW', 'REOPENED', 'UNHANDLED', 'DONE');

ALTER TABLE "jupiter"."tasks" ADD COLUMN "status_reason" "jupiter"."TaskStatusReasonEnum";
UPDATE "jupiter"."tasks" 
  SET "status_reason" = 
    CASE
      WHEN "status" = 'NEW' THEN 'NEW'::"jupiter"."TaskStatusReasonEnum"
      WHEN "status" = 'ACTIVE' THEN 'NEW'::"jupiter"."TaskStatusReasonEnum"
      WHEN "status" = 'CLOSED' THEN 'DONE'::"jupiter"."TaskStatusReasonEnum"
    END;

ALTER TABLE "jupiter"."tasks" ALTER COLUMN "status_reason" SET DEFAULT 'NEW';
ALTER TABLE "jupiter"."tasks" ALTER COLUMN "status_reason" SET NOT NULL;

COMMIT;
