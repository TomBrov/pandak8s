/*
  Warnings:

  - You are about to drop the column `areaType` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `battalion` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `circleClosed` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `company` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `cooperation` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `deviceName` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `discoveryClassification` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `eventClassification` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `eventDescription` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `forceJumped` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `forcesInvolved` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `generalSpace` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `location` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `reason` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `results` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `taskClassification` on the `op_logs` table. All the data in the column will be lost.

*/
-- DropIndex
DROP INDEX "archive"."op_logs_time_idx";

-- DropIndex
DROP INDEX "archive"."radar_indications_time_idx";

-- DropIndex
DROP INDEX "archive"."tasks_time_idx";

-- AlterTable
ALTER TABLE "archive"."op_logs" DROP COLUMN "areaType",
DROP COLUMN "battalion",
DROP COLUMN "circleClosed",
DROP COLUMN "company",
DROP COLUMN "cooperation",
DROP COLUMN "deviceName",
DROP COLUMN "discoveryClassification",
DROP COLUMN "eventClassification",
DROP COLUMN "eventDescription",
DROP COLUMN "forceJumped",
DROP COLUMN "forcesInvolved",
DROP COLUMN "generalSpace",
DROP COLUMN "location",
DROP COLUMN "reason",
DROP COLUMN "results",
DROP COLUMN "taskClassification",
ADD COLUMN     "extraFields" JSONB;

