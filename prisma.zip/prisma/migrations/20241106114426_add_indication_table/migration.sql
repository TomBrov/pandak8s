-- CreateTable
CREATE TABLE "jupiter"."indications" (
    "creation_time" TIMESTAMP(3) NOT NULL,
    "id" INTEGER NOT NULL,
    "radar_id" INTEGER NOT NULL,
    "coordinates" geometry(Point, 4326) NOT NULL,
    "detection_type" TEXT,

    CONSTRAINT "indications_pkey" PRIMARY KEY ("creation_time","id","radar_id")
);
