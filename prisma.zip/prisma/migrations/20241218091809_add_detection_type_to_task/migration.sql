/*
  Warnings:

  - Added the required column `detection_type` to the `tasks` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "jupiter"."DetectionTypeEnum" AS ENUM ('VEHICLE', 'HUMAN', 'ANIMAL', 'UNIDENTIFIED', 'MOVING_UNIDENTIFIED');

-- AlterTable
ALTER TABLE "jupiter"."tasks" ADD COLUMN     "detection_type" "jupiter"."DetectionTypeEnum";
UPDATE "jupiter"."tasks" SET "detection_type" = 'MOVING_UNIDENTIFIED' WHERE "detection_type" IS NULL;
ALTER TABLE "jupiter"."tasks" ALTER COLUMN "detection_type" SET NOT NULL;

-- DropEnum
DROP TYPE "jupiter"."FusedClassificationEnum";
