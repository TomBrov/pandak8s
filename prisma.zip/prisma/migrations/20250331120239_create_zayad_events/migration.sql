CREATE TYPE "jupiter"."EventTypeEnum" AS ENUM ('EVENT', 'ENEMY');

-- CreateTable
CREATE TABLE "jupiter"."zayad_events" (
    "id" TEXT NOT NULL,
    "position" geometry(PointZ, 4326) NOT NULL,
    "type" "jupiter"."EventTypeEnum" NOT NULL, 
    "description" TEXT NOT NULL,
    "hamal_id" TEXT NOT NULL,

    CONSTRAINT "zayad_events_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "jupiter"."zayad_events" ADD CONSTRAINT "zayad_events_hamal_id_fkey" FOREIGN KEY ("hamal_id") REFERENCES "jupiter"."hamals"("id") ON DELETE CASCADE ON UPDATE CASCADE;