-- CreateIndex
CREATE INDEX "tasks_status_score_updated_at_idx" ON "jupiter"."tasks"("status", "score", "updated_at");
