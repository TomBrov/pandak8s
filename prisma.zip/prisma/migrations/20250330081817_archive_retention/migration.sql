-- set hypertable for camera responsibility polygons with interval of 4 HRS
SELECT create_hypertable('archive.camera_responsibility_polygons', 'time', chunk_time_interval => INTERVAL '4 hours');

-- set hypertable for ground org polygons with interval of 4 HRS
SELECT create_hypertable('archive.ground_org_polygons', 'time', chunk_time_interval => INTERVAL '4 hours');

-- add retention with interval of 3 months
SELECT add_retention_policy('archive.tasks', drop_after => INTERVAL '3 months');
SELECT add_retention_policy('archive.radar_indications', drop_after => INTERVAL '3 months');
SELECT add_retention_policy('archive.camera_responsibility_polygons', drop_after => INTERVAL '3 months');
SELECT add_retention_policy('archive.ground_org_polygons', drop_after => INTERVAL '3 months');