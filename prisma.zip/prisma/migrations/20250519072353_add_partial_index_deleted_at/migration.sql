-- Add partial index on cameras (id) where deleted_at is null
CREATE INDEX "idx_cameras_not_deleted"
ON "jupiter"."cameras" ("id")
WHERE "deleted_at" IS NULL;

-- Add partial index on stations (id) where deleted_at is null
CREATE INDEX "idx_stations_not_deleted"
ON "jupiter"."stations" ("id")
WHERE "deleted_at" IS NULL;

-- Add partial index on cells (id) where deleted_at is null
CREATE INDEX "idx_cells_not_deleted"
ON "jupiter"."cells" (id)
WHERE "deleted_at" IS NULL;