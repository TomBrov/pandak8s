-- CreateIndex
CREATE INDEX "camera_responsibility_polygon_position_idx" ON "jupiter"."camera_responsibility_polygons" USING GIST ("position");
