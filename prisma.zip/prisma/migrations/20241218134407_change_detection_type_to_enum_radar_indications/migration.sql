/*
  Warnings:

  - Changed the type of `detection_type` on the `radar_indications` table. No cast exists, the column would be dropped and recreated, which cannot be done if there is data, since the column is required.

*/
-- AlterTable
ALTER TABLE "jupiter"."radar_indications"
  ADD COLUMN "detection_type_new" "jupiter"."DetectionTypeEnum";

UPDATE "jupiter"."radar_indications" SET "detection_type_new"
  = CASE
      WHEN "detection_type" = 'Vehicle' THEN 'VEHICLE'::"jupiter"."DetectionTypeEnum"
      WHEN "detection_type" = 'Person' THEN 'HUMAN'::"jupiter"."DetectionTypeEnum"
      WHEN "detection_type" = 'Undefined' THEN 'UNIDENTIFIED'::"jupiter"."DetectionTypeEnum"
      WHEN "detection_type" = 'Animal' THEN 'ANIMAL'::"jupiter"."DetectionTypeEnum"
      ELSE 'MOVING_UNIDENTIFIED'::"jupiter"."DetectionTypeEnum"
    END;

-- Drop the old column
ALTER TABLE "jupiter"."radar_indications"
  DROP COLUMN "detection_type";

-- Rename the new column to the original column's name
ALTER TABLE "jupiter"."radar_indications"
  RENAME COLUMN "detection_type_new" TO "detection_type";

-- Change the column type to the enum
ALTER TABLE "jupiter"."radar_indications"
  ALTER COLUMN "detection_type" TYPE "jupiter"."DetectionTypeEnum"
  USING "detection_type"::"jupiter"."DetectionTypeEnum";

-- Set the renamed column to NOT NULL
ALTER TABLE "jupiter"."radar_indications"
  ALTER COLUMN "detection_type" SET NOT NULL;