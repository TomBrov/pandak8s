/*
  Warnings:

  - Added the required column `hamalId` to the `cameras` table with the existing hamal's ID. This is not possible if the table has hamals count different than 1.

*/

-- Add column as nullable first
ALTER TABLE "jupiter"."cameras" ADD COLUMN "hamalId" TEXT;

-- Update all cameras with the single hamal's ID
UPDATE "jupiter"."cameras" SET "hamalId" = (SELECT id FROM "jupiter"."hamals" LIMIT 1);

-- Make the column NOT NULL
ALTER TABLE "jupiter"."cameras" ALTER COLUMN "hamalId" SET NOT NULL;

-- AddForeignKey
ALTER TABLE "jupiter"."cameras" ADD CONSTRAINT "cameras_hamalId_fkey" FOREIGN KEY ("hamalId") REFERENCES "jupiter"."hamals"("id") ON DELETE CASCADE ON UPDATE CASCADE;
