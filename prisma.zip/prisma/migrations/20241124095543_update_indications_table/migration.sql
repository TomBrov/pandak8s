/*
  Warnings:

  - The primary key for the `indications` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `radar_id` on the `indications` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "jupiter"."indications" DROP CONSTRAINT "indications_pkey",
DROP COLUMN "radar_id",
ADD COLUMN     "radar_device_name" TEXT,
ADD COLUMN     "radar_indication_id" TEXT,
ALTER COLUMN "id" SET DATA TYPE TEXT,
ADD CONSTRAINT "indications_pkey" PRIMARY KEY ("creation_time", "id");
