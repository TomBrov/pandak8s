-- CreateIndex
CREATE INDEX "radar_indications_creation_time_idx" ON "jupiter"."radar_indications"("creation_time");

-- CreateIndex
CREATE INDEX "tasks_updated_at_idx" ON "jupiter"."tasks"("updated_at");
