-- CreateIndex
CREATE INDEX "radar_indications_id_idx" ON "jupiter"."radar_indications"("id");
