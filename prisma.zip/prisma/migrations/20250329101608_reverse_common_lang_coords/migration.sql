UPDATE jupiter."commonLang"
SET position = ST_SetSRID(
    ST_MakePoint(
        ST_Y(position),
        ST_X(position),
        ST_Z(position)
    ),
    4326
)
