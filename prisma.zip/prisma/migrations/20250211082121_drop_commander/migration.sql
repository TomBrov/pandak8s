/*
  Warnings:

  - You are about to drop the column `commanderId` on the `op_logs` table. All the data in the column will be lost.
  - You are about to drop the column `commanderName` on the `op_logs` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "archive"."op_logs" DROP COLUMN "commanderId",
DROP COLUMN "commanderName";
