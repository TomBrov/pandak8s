/*
  Warnings:

  - You are about to drop the column `last_time_in_polygon` on the `tasks` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "jupiter"."tasks" DROP COLUMN "last_time_in_polygon";
