/*
  Warnings:

  - A unique constraint covering the columns `[active_spotter_id]` on the table `cameras` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "jupiter"."cameras" ADD COLUMN     "active_spotter_id" TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "cameras_active_spotter_id_key" ON "jupiter"."cameras"("active_spotter_id");

-- AddForeignKey
ALTER TABLE "jupiter"."cameras" ADD CONSTRAINT "cameras_active_spotter_id_fkey" FOREIGN KEY ("active_spotter_id") REFERENCES "jupiter"."users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
