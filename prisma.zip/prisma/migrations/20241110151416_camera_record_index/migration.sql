-- CreateIndex
CREATE INDEX "camera_recordings_camera_id_recording_start_time_idx" ON "jupiter"."camera_recordings"("camera_id", "recording_start_time");
