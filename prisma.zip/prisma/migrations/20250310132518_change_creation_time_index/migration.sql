-- DropIndex
DROP INDEX "jupiter"."radar_indications_creation_time_idx";

-- CreateIndex
CREATE INDEX "radar_indications_creation_time_idx_desc" ON "jupiter"."radar_indications"("creation_time" DESC);
