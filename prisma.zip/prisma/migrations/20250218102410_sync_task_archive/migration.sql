-- Rename columns to new names
ALTER TABLE "archive"."tasks" 
    RENAME COLUMN "createdAt" TO "created_at";
ALTER TABLE "archive"."tasks" 
    RENAME COLUMN "detectionType" TO "detection_type";
ALTER TABLE "archive"."tasks" 
    RENAME COLUMN "groundOrgPolygonId" TO "ground_org_polygon_id";
ALTER TABLE "archive"."tasks" 
    RENAME COLUMN "hamalDispName" TO "hamal_dispname";
ALTER TABLE "archive"."tasks" 
    RENAME COLUMN "hamalId" TO "hamal_id";
ALTER TABLE "archive"."tasks" 
    RENAME COLUMN "indicationId" TO "indication_id";
ALTER TABLE "archive"."tasks" 
    RENAME COLUMN "spotterClassification" TO "spotter_classification";
ALTER TABLE "archive"."tasks" 
    RENAME COLUMN "stationDispName" TO "station_dispname";
ALTER TABLE "archive"."tasks" 
    RENAME COLUMN "stationId" TO "station_id";
ALTER TABLE "archive"."tasks" 
    RENAME COLUMN "statusReason" TO "status_reason";
ALTER TABLE "archive"."tasks" 
    RENAME COLUMN "taskClassification" TO "task_classification";

-- Add new columns that didn't exist before
ALTER TABLE "archive"."tasks" 
    ADD COLUMN IF NOT EXISTS "camera_id" TEXT,
    ADD COLUMN IF NOT EXISTS "camera_dispname" TEXT,
    ADD COLUMN IF NOT EXISTS "event_classification" "jupiter"."EventClassificationEnum";

-- Set default for status_reason if it doesn't exist
ALTER TABLE "archive"."tasks" 
    ALTER COLUMN "status_reason" SET DEFAULT 'NEW';
