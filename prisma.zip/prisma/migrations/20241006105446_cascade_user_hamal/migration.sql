-- DropForeignKey
ALTER TABLE "jupiter"."users" DROP CONSTRAINT "users_hamalId_fkey";

-- AddForeignKey
ALTER TABLE "jupiter"."users" ADD CONSTRAINT "users_hamalId_fkey" FOREIGN KEY ("hamalId") REFERENCES "jupiter"."hamals"("id") ON DELETE CASCADE ON UPDATE CASCADE;
