-- CreateExtension
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";
