/*
  Warnings:

  - Added the required column `radar_id` to the `radar_indications` table without a default value. This is not possible if the table is not empty.
  - Added the required column `radar_id` to the `radar_indications` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "archive"."radar_indications" ADD COLUMN     "radar_id" TEXT,
ADD COLUMN     "speed" DOUBLE PRECISION NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "archive"."tasks" ADD COLUMN     "speed" DOUBLE PRECISION NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "jupiter"."radar_indications" ADD COLUMN     "radar_id" TEXT,
ADD COLUMN     "speed" DOUBLE PRECISION NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "jupiter"."tasks" ADD COLUMN     "speed" DOUBLE PRECISION NOT NULL DEFAULT 0;

-- AddForeignKey
ALTER TABLE "jupiter"."radar_indications" ADD CONSTRAINT "radar_indications_radar_id_fkey" FOREIGN KEY ("radar_id") REFERENCES "jupiter"."radars"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
