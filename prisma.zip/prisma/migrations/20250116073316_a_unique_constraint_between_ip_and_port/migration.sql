/*
  Warnings:

  - A unique constraint covering the columns `[ip,port]` on the table `radars` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "radars_ip_port_key" ON "jupiter"."radars"("ip", "port");
