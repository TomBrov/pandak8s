-- AlterTable
ALTER TABLE "jupiter"."cells" ADD COLUMN "is_deleted" BOOLEAN DEFAULT FALSE;

-- AlterTable
ALTER TABLE "jupiter"."stations" ADD COLUMN "is_deleted" BOOLEAN DEFAULT FALSE;