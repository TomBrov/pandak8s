-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "archive";

-- CreateEnum
CREATE TYPE "archive"."ActionTypeEnum" AS ENUM ('התחברות', 'התנתקות', 'יצירת משתמש', 'מחיקת משתמש', 'שינוי בפוליגון', 'החלפת מרשם פעיל ל...', 'כיול', 'הצפנה', 'כשירות', 'יצירה', 'מחיקה', 'עריכה', 'סיום טיפול');

-- CreateEnum
CREATE TYPE "archive"."CategoryEnum" AS ENUM ('TASK', 'USER', 'DEVICE', 'MANUAL_REPORT');

-- CreateEnum
CREATE TYPE "archive"."AreaTypeEnum" AS ENUM ('SEAM', 'DEPTH', 'SETTLEMENT');

-- CreateEnum
CREATE TYPE "archive"."EventClassificationEnum" AS ENUM ('HOT_HAMMER', 'TOMAHAWK', 'HURRICANE', 'TURKISH_HORSEMAN', 'HORSEMAN_TURKISH', 'MEANING', 'TZAMBAR', 'BAKTAVIM', 'HAFSAD', 'AVALAG');

-- CreateTable
CREATE TABLE "archive"."camera_responsibility_polygons" (
    "id" TEXT NOT NULL,
    "time" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "name" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "position" geometry(Polygon,4326) NOT NULL,
    "cameraId" TEXT NOT NULL,
    "cellRowDate" SERIAL NOT NULL,
    "cellId" TEXT NOT NULL,
    "cellDispName" TEXT NOT NULL,
    "hamalId" TEXT NOT NULL,
    "hamalDispName" TEXT NOT NULL,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "cameraDispName" TEXT NOT NULL,

    CONSTRAINT "camera_responsibility_polygons_pkey" PRIMARY KEY ("id","time")
);

-- CreateTable
CREATE TABLE "archive"."ground_org_polygons" (
    "id" TEXT NOT NULL,
    "time" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "name" TEXT NOT NULL,
    "position" geometry(Polygon,4326) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "metadata" JSONB NOT NULL,
    "polygonType" "jupiter"."GroundOrgPolygonType" NOT NULL DEFAULT 'PRIORITY',
    "groundOrgId" TEXT NOT NULL,
    "groundOrgName" TEXT NOT NULL,
    "groundOrgIsTurnOn" BOOLEAN NOT NULL DEFAULT false,
    "groundOrgCreatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "groundOrgUpdatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "ground_org_polygons_pkey" PRIMARY KEY ("id","time")
);

-- CreateTable
CREATE TABLE "archive"."tasks" (
    "id" TEXT NOT NULL,
    "time" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "status" "jupiter"."TaskStatusEnum" NOT NULL DEFAULT 'OPEN',
    "score" DOUBLE PRECISION NOT NULL,
    "indicationId" TEXT,
    "position" geometry(Point,4326) NOT NULL,
    "spotterClassification" "jupiter"."SpotterClassificationEnum",
    "taskClassification" "jupiter"."TaskClassificationEnum",
    "detectionType" "jupiter"."DetectionTypeEnum" NOT NULL,
    "groundOrgPolygonId" TEXT,
    "hamalId" TEXT NOT NULL,
    "hamalDispName" TEXT NOT NULL,
    "stationId" TEXT,
    "stationDispName" TEXT,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "tasks_pkey" PRIMARY KEY ("id","time")
);

-- CreateTable
CREATE TABLE "archive"."op_logs" (
    "id" TEXT NOT NULL,
    "time" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "category" "archive"."CategoryEnum" NOT NULL,
    "actionType" "archive"."ActionTypeEnum" NOT NULL,
    "deviceName" TEXT,
    "cellId" TEXT,
    "cellDispName" TEXT,
    "stationId" TEXT,
    "stationDispName" TEXT,
    "userId" TEXT,
    "username" TEXT,
    "commanderId" TEXT,
    "commanderName" TEXT,
    "taskClassification" "jupiter"."TaskClassificationEnum",
    "discoveryClassification" "jupiter"."SpotterClassificationEnum",
    "eventClassification" "archive"."EventClassificationEnum",
    "generalSpace" TEXT,
    "eventDescription" TEXT,
    "cooperation" TEXT,
    "areaType" "archive"."AreaTypeEnum",
    "company" TEXT,
    "battalion" TEXT,
    "forcesInvolved" INTEGER,
    "forceJumped" BOOLEAN,
    "circleClosed" BOOLEAN,
    "reason" TEXT,
    "results" TEXT,
    "location" geometry(Point, 4326),

    CONSTRAINT "op_logs_pkey" PRIMARY KEY ("id","time","category")
);

-- CreateTable
CREATE TABLE "archive"."radar_indications" (
    "id" TEXT NOT NULL,
    "time" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "radarDeviceName" TEXT NOT NULL,
    "radarIndicationId" TEXT NOT NULL,
    "coordinates" geometry(Point,4326) NOT NULL,
    "detectionType" "jupiter"."DetectionTypeEnum" NOT NULL,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "radar_indications_pkey" PRIMARY KEY ("time","id")
);

-- set hypertable for tasks with interval of 4 HRS
SELECT create_hypertable('archive.tasks', 'time', chunk_time_interval => INTERVAL '4 hours');

-- set hypertable for op_logs with interval of 1 day
SELECT create_hypertable('archive.op_logs', 'time', chunk_time_interval => INTERVAL '1 day');

-- set hypertable for radar_indications with interval of 2 HRS
SELECT create_hypertable('archive.radar_indications', 'time', chunk_time_interval => INTERVAL '2 hours');