-- AlterTable
ALTER TABLE "jupiter"."cameras" ADD COLUMN     "deleted_at" TIMESTAMP(3);
