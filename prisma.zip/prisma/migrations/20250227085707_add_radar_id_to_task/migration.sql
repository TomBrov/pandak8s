/*
  Warnings:

  - Added the required column `radar_id` to the `tasks` table without a default value. This is not possible if the table is not empty.
  - Added the required column `radar_id` to the `tasks` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "archive"."tasks" ADD COLUMN     "radar_id" TEXT;

-- AlterTable
ALTER TABLE "jupiter"."tasks" ADD COLUMN     "radar_id" TEXT;

-- AddForeignKey
ALTER TABLE "jupiter"."tasks" ADD CONSTRAINT "tasks_radar_id_fkey" FOREIGN KEY ("radar_id") REFERENCES "jupiter"."radars"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
