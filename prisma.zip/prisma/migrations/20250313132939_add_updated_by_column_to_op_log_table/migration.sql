-- AlterTable
ALTER TABLE "jupiter"."op_logs" ADD COLUMN     "updated_by" TEXT;
