/*
  Warnings:

  - Made the column `detection_type` on table `indications` required. This step will fail if there are existing NULL values in that column.
  - Made the column `radar_device_name` on table `indications` required. This step will fail if there are existing NULL values in that column.
  - Made the column `radar_indication_id` on table `indications` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "jupiter"."indications" ALTER COLUMN "detection_type" SET NOT NULL,
ALTER COLUMN "radar_device_name" SET NOT NULL,
ALTER COLUMN "radar_indication_id" SET NOT NULL;
