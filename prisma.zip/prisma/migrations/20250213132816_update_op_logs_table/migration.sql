/*
  Warnings:

  - You are about to drop the `op_logs` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropTable
DROP TABLE "archive"."op_logs";

-- CreateTable
CREATE TABLE "jupiter"."op_logs" (
    "id" TEXT NOT NULL,
    "time" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "category" "archive"."CategoryEnum" NOT NULL,
    "actionType" "archive"."ActionTypeEnum" NOT NULL,
    "cellId" TEXT,
    "cellDispName" TEXT,
    "stationId" TEXT,
    "stationDispName" TEXT,
    "userId" TEXT,
    "username" TEXT,
    "extraFields" JSONB,

    CONSTRAINT "op_logs_pkey" PRIMARY KEY ("id")
);
