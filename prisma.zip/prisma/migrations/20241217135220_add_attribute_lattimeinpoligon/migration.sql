-- AlterTable
ALTER TABLE "jupiter"."tasks" ADD COLUMN     "last_time_in_polygon" TIMESTAMP(3);
