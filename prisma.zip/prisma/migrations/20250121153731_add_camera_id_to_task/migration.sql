-- AlterTable
ALTER TABLE "jupiter"."tasks" ADD COLUMN     "camera_id" TEXT;

-- AddForeignKey
ALTER TABLE "jupiter"."tasks" ADD CONSTRAINT "tasks_camera_id_fkey" FOREIGN KEY ("camera_id") REFERENCES "jupiter"."cameras"("id") ON DELETE SET NULL ON UPDATE CASCADE;
