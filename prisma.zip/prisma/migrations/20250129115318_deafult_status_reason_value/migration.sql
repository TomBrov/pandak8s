UPDATE "jupiter"."cameras"
SET "status_reason" = ARRAY[]::"jupiter"."DeviceStatusReasonEnum"[]
WHERE array_length("status_reason", 1) = 1 AND "status_reason"[1] IS NULL;

UPDATE "jupiter"."radars"
SET "status_reason" = ARRAY[]::"jupiter"."DeviceStatusReasonEnum"[]
WHERE array_length("status_reason", 1) = 1 AND "status_reason"[1] IS NULL;

-- AlterTable
ALTER TABLE "jupiter"."cameras" ALTER COLUMN "status_reason" SET DEFAULT ARRAY[]::"jupiter"."DeviceStatusReasonEnum"[];

-- AlterTable
ALTER TABLE "jupiter"."radars" ALTER COLUMN "status_reason" SET DEFAULT ARRAY[]::"jupiter"."DeviceStatusReasonEnum"[];
