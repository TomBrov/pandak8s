-- AlterTable
ALTER TABLE "jupiter"."radars" ADD COLUMN     "deleted_at" TIMESTAMP(3);
