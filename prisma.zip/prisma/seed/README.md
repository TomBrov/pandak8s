## Overview

When you run the system for the first time, you need to run a seed script that creates a user in the system, so that you can login.

## Run Seed Script

- You need this ENV for running the script !! Otherwise the script will not run

```
SUPER_ADMIN_USERNAME="211566989" // Must, ID
SUPER_ADMIN_PASSWORD='your-password' // Optional, deafult 'password'
```

- Command

```
npm run prisma:seed
```

## Run Mock Script

This script is meant to generate a mock ground org with 500 polygons in the area of Hamal Tzofim.
This script does **NOT** mock a real hamal - it creates random 4-vertix polygon.

- **The database needs to be seeded first!!!**

- Command

```bash
npm run prisma:mock
```

The script will create the following:

- `FAKE` camera.
- camera responsibility polygon covering hamal tzofim's approximated area.
- ground org (it will be turned on if it is the only ground in the database).
- ~500 ground org polygons that don't intersect each other.
  (we approximate 500 because we limit the script to attempts at creating random polygons.)
