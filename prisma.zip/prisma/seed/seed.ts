import {
  PrismaClient,
  UserRolesEnum,
  SegmentFieldEnum,
  SegmentPatternEnum,
  SegmentSpeedEnum,
  RadarTypeEnum,
  ChannelTypeEnum,
  DeviceStatusEnum,
} from '../prisma-client';
import _GeoJson from 'geojson';
import { LocalKms } from '../utils';

const prisma = new PrismaClient();
const localKms = new LocalKms();

const seedDatabase = async () => {
  const isExistingUser = await prisma.jupiterUser.findMany();

  if (isExistingUser.length === 0) {
    const hamals = await Promise.all([
      prisma.hamal.create({ data: { displayName: 'שם חמ"ל' } }),
    ]);

    const isSimulatorActive = process.env.IS_SIMULATOR_ACTIVE;
    if (isSimulatorActive) {
      const radarSimulatorDBEntry = await prisma.radar.findFirst({
        where: { radarType: RadarTypeEnum.SIMULATOR },
        select: { id: true },
      });

      if (!radarSimulatorDBEntry) {
        await prisma.$executeRaw`
          INSERT INTO jupiter.radars (
            id, name, ip, port, "hamalId", status, color, position, "radar_type"
          ) VALUES (
            gen_random_uuid(),
            'radar-simulator',
            'localhost',
            3000,
            ${hamals[0].id},
            'INACTIVE'::"jupiter"."DeviceStatusEnum",
            'gold',
            ST_SetSRID(ST_MakePoint(33, 35, 0), 4326),
            'SIMULATOR'::"jupiter"."RadarTypeEnum"
          )
        `;
      }
    }
    const cells = await Promise.all([
      prisma.cell.create({
        data: { displayName: 'תא 1', hamalId: hamals[0].id },
      }),
      prisma.cell.create({
        data: { displayName: 'תא 2', hamalId: hamals[0].id },
      }),
    ]);

    await Promise.all([
      prisma.station.create({
        data: {
          displayName: 'עמדה 1',
          cellId: cells[0].id,
          type: 'INVESTIGATOR',
        },
      }),
      prisma.station.create({
        data: { displayName: 'עמדה 2', cellId: cells[0].id, type: 'MONITOR' },
      }),
      prisma.station.create({
        data: { displayName: 'עמדה 3', cellId: cells[1].id, type: 'MONITOR' },
      }),
    ]);

    const createdCameras = await prisma.$queryRaw<
      { id: string; name: string }[]
    >`
  INSERT INTO jupiter.cameras (
    id, name, color, position, ip, port, "hamalId"
  ) VALUES
    (
      gen_random_uuid(),
      'מצלמה 1',
      '#FF0000',
      ST_SetSRID(ST_MakePoint(35.22366, 31.900432, 0), 4326),
      '0.0.0.0',
      60901,
      ${hamals[0].id}
    ),
    (
      gen_random_uuid(),
      'מצלמה 2',
      '#00FF00',
      ST_SetSRID(ST_MakePoint(35.226327, 31.898685, 0), 4326),
      '0.0.0.1',
      60901,
      ${hamals[0].id}
    ),
    (
      gen_random_uuid(),
     'שבעתה',
      '#0000FF',
      ST_SetSRID(ST_MakePoint(35.226327, 31.898685, 0), 4326),
     '172.21.21.172',
     '60901',
      ${hamals[0].id}
    )
  RETURNING id, name
`;

    await prisma.cameraConn.createMany({
      data: [
        {
          cameraId: createdCameras[0].id,
          status: DeviceStatusEnum.ACTIVE,
        },
        {
          cameraId: createdCameras[1].id,
          status: DeviceStatusEnum.INACTIVE,
        },
        {
          cameraId: createdCameras[2].id,
          status: DeviceStatusEnum.INACTIVE,
        },
      ],
    });

    await Promise.all([
      prisma.channel.create({
        data: {
          name: 'מצלמה 1 - ערוץ ראשי',
          type: ChannelTypeEnum.PRIMARY,
          IP: '0.0.0.0',
          port: 51008,
          cameraId: createdCameras[0].id,
        },
      }),
      prisma.channel.create({
        data: {
          name: 'מצלמה 1 - ערוץ משני',
          type: ChannelTypeEnum.SECONDARY,
          IP: '0.0.0.0',
          port: 51009,
          cameraId: createdCameras[0].id,
        },
      }),
      prisma.channel.create({
        data: {
          name: 'מצלמה 2 - ערוץ ראשי',
          type: ChannelTypeEnum.PRIMARY,
          IP: '0.0.0.0',
          port: 51008,
          cameraId: createdCameras[1].id,
        },
      }),
      prisma.channel.create({
        data: {
          name: 'מצלמה 2 - ערוץ משני',
          type: ChannelTypeEnum.SECONDARY,
          IP: '0.0.0.0',
          port: 51009,
          cameraId: createdCameras[1].id,
        },
      }),
      prisma.channel.create({
        data: {
          name: 'שבעתה - ערוץ ראשי',
          type: ChannelTypeEnum.PRIMARY,
          IP: '172.21.21.20',
          port: 51008,
          cameraId: createdCameras[2].id,
        },
      }),
      prisma.channel.create({
        data: {
          name: 'שבעתה - ערוץ משני',
          type: ChannelTypeEnum.SECONDARY,
          IP: '172.21.21.20',
          port: 51009,
          cameraId: createdCameras[2].id,
        },
      }),
    ]);

    const scanPlan = await prisma.scanPlan.create({
      data: { name: 'תכנית בוקר', hamalId: hamals[0].id },
    });

    const positions = {
      type: 'LineString',
      coordinates: [
        [35.36069473341192, 31.97729708342368, 0],
        [35.36471815867324, 32.01514096748953, 0],
        [35.32455410685492, 32.03112903948693, 0],
        [35.26416267621977, 32.01607147972223, 0],
        [35.28874553754008, 31.9585776308882, 0],
      ],
    };

    await Promise.all([
      prisma.$executeRaw`INSERT INTO jupiter.segments (id, name, pattern, speed, field, positions, "planId") VALUES (
        gen_random_uuid(),
        'Segment 1',
        ${SegmentPatternEnum.STRIP}::jupiter.segment_pattern,
        ${SegmentSpeedEnum.X0_5}::jupiter.segment_speed,
        ${SegmentFieldEnum.WIDE}::jupiter.segment_field,
        ST_SetSRID(ST_GeomFromGeoJSON(${JSON.stringify(positions)}), 4326),
        ${scanPlan.id}
      )`,
      prisma.$executeRaw`INSERT INTO jupiter.segments (id, name, pattern, speed, field, positions, "planId") VALUES (
        gen_random_uuid(),
        'Segment 2',
        ${SegmentPatternEnum.PERIPHERAL}::jupiter.segment_pattern,
        ${SegmentSpeedEnum.X2}::jupiter.segment_speed,
        ${SegmentFieldEnum.VERY_NARROW}::jupiter.segment_field,
        ST_SetSRID(ST_GeomFromGeoJSON(${JSON.stringify(positions)}), 4326),
        ${scanPlan.id}
      )`,
    ]);

    const username = process.env.SUPER_ADMIN_USERNAME!;

    const hashedPassword = localKms.encryptString(
      process.env.SUPER_ADMIN_PASSWORD || 'password',
    );
    await prisma.jupiterUser.create({
      data: {
        ssn: username,
        hashedPassword,
        militaryId: '123456789',
        firstName: 'Super',
        lastName: 'Admin',
        hamalId: hamals[0].id,
        role: UserRolesEnum.SUPER_ADMIN,
      },
    });

    console.log('Database seeded successfully!');
  } else {
    console.log('Database already seeded');
  }
};

seedDatabase()
  .catch((error) => {
    throw error;
  })
  .finally(() => {
    void prisma.$disconnect();
  });
