import * as turf from '@turf/turf';
import _GeoJson from 'geojson';
import { v4 as uuidv4 } from 'uuid';
import {
  $Enums,
  Cell,
  DeviceStatusEnum,
  GroundOrg,
  GroundOrgPolygonType,
  JupiterVendor,
  Prisma,
  PrismaClient,
} from '../prisma-client';

const MAX_ATTEMPTS = 1000000;
const NUM_OF_POLYGONS = 500;
const hamalBoundingBoxPolygon: _GeoJson.Polygon = {
  coordinates: [
    [
      [34.96160535020299, 32.2286257576],
      [34.96160535020299, 32.06377834060022],
      [35.06440076847798, 32.06377834060022],
      [35.06440076847798, 32.2286257576],
      [34.96160535020299, 32.2286257576],
    ],
  ],
  type: 'Polygon',
};
const bbox = turf.bbox(hamalBoundingBoxPolygon);

// Calculate the maximum radius allowed by the bbox
const bboxWidth = bbox[2] - bbox[0];
const bboxHeight = bbox[3] - bbox[1];
const maxAllowedRadius = Math.min(bboxWidth, bboxHeight) / 10;

const prisma = new PrismaClient();

const randomGrade = () => {
  return Math.floor(Math.random() * 10) + 1;
};

const generateRandomPolygons = () => {
  const polygons: _GeoJson.Polygon[] = [
    turf.randomPolygon(1, {
      bbox: bbox,
      max_radial_length: maxAllowedRadius,
      num_vertices: 4,
    }).features[0].geometry,
  ];

  for (let i = 0; i < MAX_ATTEMPTS; i++) {
    const newPolygon = turf.randomPolygon(1, {
      bbox: bbox,
      max_radial_length: maxAllowedRadius,
      num_vertices: 4,
    }).features[0];

    if (
      polygons.every((polygon) => !turf.booleanIntersects(polygon, newPolygon))
    ) {
      polygons.push(newPolygon.geometry);
    }

    if (polygons.length === NUM_OF_POLYGONS) {
      break;
    }
  }

  console.log('Generated polygons:', polygons.length);
  console.log('Expected Generated polygons:', NUM_OF_POLYGONS);

  return polygons;
};

const createFakeCamera = async (cell: Cell) => {
  const fakeCameraId = await prisma.$queryRaw<[{ cameraId: string }]>`
        INSERT INTO jupiter.cameras (
            id,
            name,
            color,
            ip,
            port,
            position,
            vendor,
            "hamalId"
        ) VALUES (
            gen_random_uuid(),
            ${'fake-camera ' + cell.displayName},
            'gold',
            '0.0.0.0',
            60901,
            ST_SetSRID(ST_MakePoint(33, 35, 0), 4326),
            ${JupiterVendor.FAKE}::jupiter.jupiter_vendor,
            ${cell.hamalId}
        )
        RETURNING id as "cameraId"
    `;

  await prisma.cameraConn.create({
    data: {
      cameraId: fakeCameraId[0].cameraId,
      status: DeviceStatusEnum.ACTIVE,
    },
  });

  return fakeCameraId;
};

const createCameraChannels = async (cameraId: string) => {
  return await prisma.channel.createMany({
    data: [
      {
        id: uuidv4(),
        name: `${cameraId} PRIMARY channel`,
        cameraId: cameraId,
        IP: '0.0.0.0',
        port: 51010,
        type: $Enums.ChannelTypeEnum.PRIMARY,
      },
      {
        id: uuidv4(),
        name: `${cameraId} SECONDARY channel`,
        cameraId: cameraId,
        IP: '0.0.0.0',
        port: 51011,
        type: $Enums.ChannelTypeEnum.SECONDARY,
      },
    ],
  });
};

const createCameraResponsibilityPolygon = async (
  cameraId: string,
  cell: Cell,
) => {
  return await prisma.$queryRaw`
      INSERT INTO jupiter.camera_responsibility_polygons (
        id,
        name,
        position,
        camera_id,
        cell_id
      ) VALUES (
        gen_random_uuid(),
        gen_random_uuid()::text,
        ST_GeomFromGeoJSON(${hamalBoundingBoxPolygon}),
        ${cameraId},
        ${cell.id}
      )
      RETURNING id;
    `;
};

const createGroundOrg = async () => {
  const count = await prisma.groundOrg.count();

  return await prisma.groundOrg.create({
    data: {
      name: `MOCK GROUND ORG ${Date.now().toString().slice(-5)}`,
      isTurnOn: count === 0,
    },
  });
};

const createGroundOrgPolygons = async (groundOrg: GroundOrg) => {
  const polygons = generateRandomPolygons();

  const query = Prisma.sql`
    INSERT INTO jupiter.ground_org_polygon (
      id,
      name,
      position,
      ground_org_id,
      polygon_type,
      metadata
    ) VALUES ${Prisma.join(
      polygons.map((polygon, index) =>
        Prisma.raw(`(
          gen_random_uuid(),
          'POLYGON-${index}',
          ST_GeomFromGeoJSON('${JSON.stringify(polygon)}'),
          '${groundOrg.id}',
          '${GroundOrgPolygonType.PRIORITY}'::jupiter."GroundOrgPolygonType",
          '{"humanGrade": "${randomGrade()}","animalGrade": "${randomGrade()}","vehicleGrade": "${randomGrade()}","undefiendGrade": "${randomGrade()}","movingUndefiendGrade": "${randomGrade()}"}'::json
        )`),
      ),
      ',',
    )}
    RETURNING id;
  `;

  return await prisma.$queryRaw(query);
};

const mockGroundOrg = async () => {
  const cell = await prisma.cell.findFirst({});
  if (!cell) {
    throw new Error('Cell not found - Seed the database first');
  }

  const [{ cameraId }] = await createFakeCamera(cell);
  await createCameraChannels(cameraId);
  await createCameraResponsibilityPolygon(cameraId, cell);
  const groundOrg = await createGroundOrg();
  await createGroundOrgPolygons(groundOrg);
};

mockGroundOrg()
  .catch((error) => {
    throw error;
  })
  .finally(() => {
    void prisma.$disconnect();
  });
