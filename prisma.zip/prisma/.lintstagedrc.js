module.exports = {
  '*.{js,jsx,ts,tsx}': ['prettier --write', 'npm run lint:files'],
  '*.{ts,tsx}': () => 'npm run typecheck',
  '*.{json,md,mdx,css,html,cjs,mjs}': ['prettier --write'],
};
