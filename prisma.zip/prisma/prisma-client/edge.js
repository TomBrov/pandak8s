
Object.defineProperty(exports, "__esModule", { value: true });

const {
  PrismaClientKnownRequestError,
  PrismaClientUnknownRequestError,
  PrismaClientRustPanicError,
  PrismaClientInitializationError,
  PrismaClientValidationError,
  NotFoundError,
  getPrismaClient,
  sqltag,
  empty,
  join,
  raw,
  skip,
  Decimal,
  Debug,
  objectEnumValues,
  makeStrictEnum,
  Extensions,
  warnOnce,
  defineDmmfProperty,
  Public,
  getRuntime
} = require('./runtime/edge.js')


const Prisma = {}

exports.Prisma = Prisma
exports.$Enums = {}

/**
 * Prisma Client JS version: 5.22.0
 * Query Engine version: 605197351a3c8bdd595af2d2a9bc3025bca48ea2
 */
Prisma.prismaVersion = {
  client: "5.22.0",
  engine: "605197351a3c8bdd595af2d2a9bc3025bca48ea2"
}

Prisma.PrismaClientKnownRequestError = PrismaClientKnownRequestError;
Prisma.PrismaClientUnknownRequestError = PrismaClientUnknownRequestError
Prisma.PrismaClientRustPanicError = PrismaClientRustPanicError
Prisma.PrismaClientInitializationError = PrismaClientInitializationError
Prisma.PrismaClientValidationError = PrismaClientValidationError
Prisma.NotFoundError = NotFoundError
Prisma.Decimal = Decimal

/**
 * Re-export of sql-template-tag
 */
Prisma.sql = sqltag
Prisma.empty = empty
Prisma.join = join
Prisma.raw = raw
Prisma.validator = Public.validator

/**
* Extensions
*/
Prisma.getExtensionContext = Extensions.getExtensionContext
Prisma.defineExtension = Extensions.defineExtension

/**
 * Shorthand utilities for JSON filtering
 */
Prisma.DbNull = objectEnumValues.instances.DbNull
Prisma.JsonNull = objectEnumValues.instances.JsonNull
Prisma.AnyNull = objectEnumValues.instances.AnyNull

Prisma.NullTypes = {
  DbNull: objectEnumValues.classes.DbNull,
  JsonNull: objectEnumValues.classes.JsonNull,
  AnyNull: objectEnumValues.classes.AnyNull
}





/**
 * Enums
 */
exports.Prisma.TransactionIsolationLevel = makeStrictEnum({
  ReadUncommitted: 'ReadUncommitted',
  ReadCommitted: 'ReadCommitted',
  RepeatableRead: 'RepeatableRead',
  Serializable: 'Serializable'
});

exports.Prisma.CameraResponsibilityPolygonScalarFieldEnum = {
  id: 'id',
  name: 'name',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  cameraId: 'cameraId',
  cellId: 'cellId',
  cellRowIndex: 'cellRowIndex'
};

exports.Prisma.OverlapPriorityScalarFieldEnum = {
  polygonId: 'polygonId',
  overlappedPolygonId: 'overlappedPolygonId',
  ranking: 'ranking'
};

exports.Prisma.CellScalarFieldEnum = {
  id: 'id',
  displayName: 'displayName',
  hamalId: 'hamalId'
};

exports.Prisma.GroundOrgScalarFieldEnum = {
  id: 'id',
  name: 'name',
  isTurnOn: 'isTurnOn',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.GroundOrgPolygonScalarFieldEnum = {
  id: 'id',
  name: 'name',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  type: 'type',
  groundOrgId: 'groundOrgId',
  metadata: 'metadata'
};

exports.Prisma.IndicationScalarFieldEnum = {
  creationTime: 'creationTime',
  id: 'id',
  radarId: 'radarId',
  detectionType: 'detectionType'
};

exports.Prisma.ScanPlanScalarFieldEnum = {
  id: 'id',
  name: 'name',
  cameraId: 'cameraId'
};

exports.Prisma.ScanSegmentScalarFieldEnum = {
  id: 'id',
  name: 'name',
  pattern: 'pattern',
  speed: 'speed',
  field: 'field',
  planId: 'planId'
};

exports.Prisma.JupiterVideoServerScalarFieldEnum = {
  taskId: 'taskId',
  address: 'address',
  port: 'port'
};

exports.Prisma.JupiterUserScalarFieldEnum = {
  id: 'id',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  ssn: 'ssn',
  militaryId: 'militaryId',
  email: 'email',
  firstName: 'firstName',
  lastName: 'lastName',
  phoneNumber: 'phoneNumber',
  hashedPassword: 'hashedPassword',
  hashedRt: 'hashedRt',
  hamalId: 'hamalId',
  role: 'role'
};

exports.Prisma.ScreenRecordingScalarFieldEnum = {
  id: 'id',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  hlsVideoPath: 'hlsVideoPath',
  recordingStartTime: 'recordingStartTime',
  fileName: 'fileName',
  duration: 'duration',
  stationId: 'stationId'
};

exports.Prisma.HamalScalarFieldEnum = {
  id: 'id',
  displayName: 'displayName'
};

exports.Prisma.CommonLangScalarFieldEnum = {
  id: 'id',
  lat: 'lat',
  lng: 'lng',
  description: 'description',
  hamalId: 'hamalId'
};

exports.Prisma.DeviceStatusScalarFieldEnum = {
  id: 'id',
  name: 'name',
  displayName: 'displayName'
};

exports.Prisma.CameraScalarFieldEnum = {
  id: 'id',
  name: 'name',
  color: 'color',
  lat: 'lat',
  IP: 'IP',
  port: 'port',
  streamingPort: 'streamingPort',
  streamingPath: 'streamingPath',
  long: 'long',
  status: 'status',
  isRecording: 'isRecording',
  vendor: 'vendor',
  cellId: 'cellId',
  videoServerId: 'videoServerId',
  activeSpotterId: 'activeSpotterId'
};

exports.Prisma.CameraRecordingsScalarFieldEnum = {
  id: 'id',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  cameraId: 'cameraId',
  recordingDatetime: 'recordingDatetime',
  duration: 'duration',
  fileName: 'fileName',
  url: 'url'
};

exports.Prisma.RadarScalarFieldEnum = {
  id: 'id',
  name: 'name',
  color: 'color',
  lat: 'lat',
  long: 'long',
  status: 'status',
  hamalId: 'hamalId'
};

exports.Prisma.StationScalarFieldEnum = {
  id: 'id',
  displayName: 'displayName',
  type: 'type',
  cellRowIndex: 'cellRowIndex',
  activeSpotterId: 'activeSpotterId',
  cellId: 'cellId'
};

exports.Prisma.TaskScalarFieldEnum = {
  id: 'id',
  name: 'name',
  description: 'description',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  taskClassification: 'taskClassification',
  spotterClassification: 'spotterClassification',
  status: 'status',
  score: 'score',
  fusedDetectionId: 'fusedDetectionId',
  hamalId: 'hamalId',
  stationId: 'stationId'
};

exports.Prisma.TaskClassificationScalarFieldEnum = {
  id: 'id',
  name: 'name',
  displayName: 'displayName'
};

exports.Prisma.SpotterClassificationScalarFieldEnum = {
  id: 'id',
  name: 'name',
  displayName: 'displayName'
};

exports.Prisma.TaskStatusScalarFieldEnum = {
  id: 'id',
  name: 'name',
  displayName: 'displayName'
};

exports.Prisma.DetectedObjectScalarFieldEnum = {
  id: 'id',
  name: 'name',
  description: 'description',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  score: 'score',
  hamalId: 'hamalId',
  fusedDetectionId: 'fusedDetectionId'
};

exports.Prisma.FusedDetectionScalarFieldEnum = {
  id: 'id',
  name: 'name',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  fusedClassification: 'fusedClassification',
  lat: 'lat',
  long: 'long'
};

exports.Prisma.FusedClassificationScalarFieldEnum = {
  id: 'id',
  name: 'name',
  displayName: 'displayName'
};

exports.Prisma.CameraDetectionScalarFieldEnum = {
  id: 'id',
  name: 'name',
  createdAt: 'createdAt',
  fusedDetectionId: 'fusedDetectionId'
};

exports.Prisma.RadarDetectionScalarFieldEnum = {
  id: 'id',
  name: 'name',
  createdAt: 'createdAt',
  fusedDetectionId: 'fusedDetectionId'
};

exports.Prisma.HunterDetectionScalarFieldEnum = {
  id: 'id',
  name: 'name',
  createdAt: 'createdAt',
  fusedDetectionId: 'fusedDetectionId'
};

exports.Prisma.SortOrder = {
  asc: 'asc',
  desc: 'desc'
};

exports.Prisma.JsonNullValueInput = {
  JsonNull: Prisma.JsonNull
};

exports.Prisma.QueryMode = {
  default: 'default',
  insensitive: 'insensitive'
};

exports.Prisma.JsonNullValueFilter = {
  DbNull: Prisma.DbNull,
  JsonNull: Prisma.JsonNull,
  AnyNull: Prisma.AnyNull
};

exports.Prisma.NullsOrder = {
  first: 'first',
  last: 'last'
};
exports.GroundOrgPolygonType = exports.$Enums.GroundOrgPolygonType = {
  PRIORITY: 'PRIORITY',
  IGNORE: 'IGNORE'
};

exports.SegmentPatternEnum = exports.$Enums.SegmentPatternEnum = {
  STRIP: 'STRIP',
  PERIPHERAL: 'PERIPHERAL'
};

exports.SegmentSpeedEnum = exports.$Enums.SegmentSpeedEnum = {
  X0_5: 'X0_5',
  X1: 'X1',
  X2: 'X2'
};

exports.SegmentFieldEnum = exports.$Enums.SegmentFieldEnum = {
  WIDE: 'WIDE',
  NARROW: 'NARROW',
  VERY_NARROW: 'VERY_NARROW'
};

exports.UserRolesEnum = exports.$Enums.UserRolesEnum = {
  SUPER_ADMIN: 'SUPER_ADMIN',
  COMMANDER: 'COMMANDER',
  SPOTTER: 'SPOTTER'
};

exports.DeviceStatusEnum = exports.$Enums.DeviceStatusEnum = {
  ACTIVE: 'ACTIVE',
  INACTIVE: 'INACTIVE',
  ERROR: 'ERROR',
  INITIALIZATION: 'INITIALIZATION'
};

exports.JupiterVendor = exports.$Enums.JupiterVendor = {
  FAKE: 'FAKE',
  OTHER: 'OTHER',
  FILE: 'FILE',
  MPEG_TS: 'MPEG_TS'
};

exports.StationType = exports.$Enums.StationType = {
  MONITOR: 'MONITOR',
  INVESTIGATOR: 'INVESTIGATOR'
};

exports.TaskClassificationEnum = exports.$Enums.TaskClassificationEnum = {
  OUR_FORCES: 'OUR_FORCES',
  FALSE_ALARM: 'FALSE_ALARM',
  DETECTION_OF_ROUTINE: 'DETECTION_OF_ROUTINE',
  EXCEPTION_DETECTION: 'EXCEPTION_DETECTION',
  EVENT: 'EVENT',
  SUSPICIOUS: 'SUSPICIOUS'
};

exports.SpotterClassificationEnum = exports.$Enums.SpotterClassificationEnum = {
  PERSON: 'PERSON',
  VEHICLE: 'VEHICLE',
  ANIMAL: 'ANIMAL',
  WILED_ANIMAL: 'WILED_ANIMAL',
  ARMED_MAN: 'ARMED_MAN',
  GROUP_OF_PEOPLE: 'GROUP_OF_PEOPLE',
  HERD_WITH_A_SHEPHERD: 'HERD_WITH_A_SHEPHERD',
  HERD_WITHOUT_A_SHEPHERD: 'HERD_WITHOUT_A_SHEPHERD',
  HOME_VISIT: 'HOME_VISIT',
  FENCE_ALERT: 'FENCE_ALERT'
};

exports.TaskStatusEnum = exports.$Enums.TaskStatusEnum = {
  IN_PROGRESS: 'IN_PROGRESS',
  OPEN: 'OPEN',
  DONE: 'DONE'
};

exports.FusedClassificationEnum = exports.$Enums.FusedClassificationEnum = {
  VEHICLE: 'VEHICLE',
  HUMAN: 'HUMAN',
  ANIMAL: 'ANIMAL',
  UNIDENTIFIED: 'UNIDENTIFIED',
  MOVING_UNIDENTIFIED: 'MOVING_UNIDENTIFIED'
};

exports.Prisma.ModelName = {
  CameraResponsibilityPolygon: 'CameraResponsibilityPolygon',
  OverlapPriority: 'OverlapPriority',
  Cell: 'Cell',
  GroundOrg: 'GroundOrg',
  GroundOrgPolygon: 'GroundOrgPolygon',
  Indication: 'Indication',
  ScanPlan: 'ScanPlan',
  ScanSegment: 'ScanSegment',
  JupiterVideoServer: 'JupiterVideoServer',
  JupiterUser: 'JupiterUser',
  ScreenRecording: 'ScreenRecording',
  Hamal: 'Hamal',
  CommonLang: 'CommonLang',
  DeviceStatus: 'DeviceStatus',
  Camera: 'Camera',
  CameraRecordings: 'CameraRecordings',
  Radar: 'Radar',
  Station: 'Station',
  Task: 'Task',
  TaskClassification: 'TaskClassification',
  SpotterClassification: 'SpotterClassification',
  TaskStatus: 'TaskStatus',
  DetectedObject: 'DetectedObject',
  FusedDetection: 'FusedDetection',
  FusedClassification: 'FusedClassification',
  CameraDetection: 'CameraDetection',
  RadarDetection: 'RadarDetection',
  HunterDetection: 'HunterDetection'
};
/**
 * Create the Client
 */
const config = {
  "generator": {
    "name": "client",
    "provider": {
      "fromEnvVar": null,
      "value": "prisma-client-js"
    },
    "output": {
      "value": "/Users/tomb/Desktop/miluim/1337-jupiter-monorepo/libs/prisma/prisma-client",
      "fromEnvVar": null
    },
    "config": {
      "engineType": "library"
    },
    "binaryTargets": [
      {
        "fromEnvVar": null,
        "value": "darwin-arm64",
        "native": true
      },
      {
        "fromEnvVar": null,
        "value": "linux-musl-openssl-3.0.x"
      },
      {
        "fromEnvVar": null,
        "value": "linux-arm64-openssl-3.0.x"
      },
      {
        "fromEnvVar": null,
        "value": "debian-openssl-3.0.x"
      }
    ],
    "previewFeatures": [
      "multiSchema",
      "postgresqlExtensions",
      "prismaSchemaFolder",
      "omitApi"
    ],
    "sourceFilePath": "/Users/tomb/Desktop/miluim/1337-jupiter-monorepo/libs/prisma/schema/schema.prisma",
    "isCustomOutput": true
  },
  "relativeEnvPaths": {
    "rootEnvPath": null
  },
  "relativePath": "../schema",
  "clientVersion": "5.22.0",
  "engineVersion": "605197351a3c8bdd595af2d2a9bc3025bca48ea2",
  "datasourceNames": [
    "db"
  ],
  "activeProvider": "postgresql",
  "postinstall": false,
  "inlineDatasources": {
    "db": {
      "url": {
        "fromEnvVar": "DATABASE_URL",
        "value": null
      }
    }
  },
  "inlineSchema": "model CameraResponsibilityPolygon {\n  id                         String                                 @id @default(uuid())\n  name                       String\n  createdAt                  DateTime                               @default(now()) @map(\"created_at\")\n  updatedAt                  DateTime                               @default(now()) @updatedAt @map(\"updated_at\")\n  position                   Unsupported(\"geometry(Polygon, 4326)\")\n  camera                     Camera                                 @relation(fields: [cameraId], references: [id], onDelete: Cascade)\n  cameraId                   String                                 @map(\"camera_id\")\n  cell                       Cell                                   @relation(fields: [cellId], references: [id], onDelete: Cascade)\n  cellId                     String                                 @map(\"cell_id\")\n  cellRowIndex               Int                                    @default(autoincrement()) @map(\"cell_row_date\")\n  overlappedPolygonsPriority OverlapPriority[]                      @relation(\"overlappedPolygonsPriority\")\n  intersectedPriority        OverlapPriority[]                      @relation(\"intersectedPriority\")\n\n  @@map(\"camera_responsibility_polygons\")\n  @@schema(\"jupiter\")\n}\n\nmodel OverlapPriority {\n  polygonId                   String\n  overlappedPolygonId         String\n  ranking                     Int\n  cameraResponsibilityPolygon CameraResponsibilityPolygon @relation(\"overlappedPolygonsPriority\", fields: [polygonId], references: [id], onDelete: Cascade)\n  overlappedPolygon           CameraResponsibilityPolygon @relation(\"intersectedPriority\", fields: [overlappedPolygonId], references: [id], onDelete: Cascade)\n\n  @@id([polygonId, overlappedPolygonId])\n  @@map(\"overlap_priority\")\n  @@schema(\"jupiter\")\n}\n\nmodel Cell {\n  id          String    @id @default(uuid())\n  displayName String    @map(\"display_name\")\n  hamal       Hamal     @relation(fields: [hamalId], references: [id], onDelete: Cascade)\n  stations    Station[]\n\n  hamalId                     String\n  CameraResponsibilityPolygon CameraResponsibilityPolygon[]\n  cameras                     Camera[]\n\n  @@map(\"cells\")\n  @@schema(\"jupiter\")\n}\n\nenum TaskClassificationEnum {\n  OUR_FORCES\n  FALSE_ALARM\n  DETECTION_OF_ROUTINE\n  EXCEPTION_DETECTION\n  EVENT\n  SUSPICIOUS\n\n  @@schema(\"jupiter\")\n}\n\nenum SpotterClassificationEnum {\n  PERSON\n  VEHICLE\n  ANIMAL\n  WILED_ANIMAL\n  ARMED_MAN\n  GROUP_OF_PEOPLE\n  HERD_WITH_A_SHEPHERD\n  HERD_WITHOUT_A_SHEPHERD\n  HOME_VISIT\n  FENCE_ALERT\n\n  @@schema(\"jupiter\")\n}\n\nenum FusedClassificationEnum {\n  VEHICLE\n  HUMAN\n  ANIMAL\n  UNIDENTIFIED\n  MOVING_UNIDENTIFIED\n\n  @@schema(\"jupiter\")\n}\n\nenum TaskStatusEnum {\n  IN_PROGRESS\n  OPEN\n  DONE\n\n  @@schema(\"jupiter\")\n}\n\nenum DeviceStatusEnum {\n  ACTIVE\n  INACTIVE\n  ERROR\n  INITIALIZATION\n\n  @@schema(\"jupiter\")\n}\n\nenum StationType {\n  MONITOR\n  INVESTIGATOR\n\n  @@schema(\"jupiter\")\n}\n\nenum UserRolesEnum {\n  SUPER_ADMIN\n  COMMANDER\n  SPOTTER\n\n  @@schema(\"jupiter\")\n}\n\nenum JupiterVendor {\n  FAKE\n  OTHER\n  FILE\n  MPEG_TS\n\n  @@map(\"jupiter_vendor\")\n  @@schema(\"jupiter\")\n}\n\nenum SegmentPatternEnum {\n  STRIP\n  PERIPHERAL\n\n  @@map(\"segment_pattern\")\n  @@schema(\"jupiter\")\n}\n\nenum SegmentSpeedEnum {\n  X0_5\n  X1\n  X2\n\n  @@map(\"segment_speed\")\n  @@schema(\"jupiter\")\n}\n\nenum SegmentFieldEnum {\n  WIDE\n  NARROW\n  VERY_NARROW\n\n  @@map(\"segment_field\")\n  @@schema(\"jupiter\")\n}\n\nmodel GroundOrg {\n  id                String             @id @default(uuid())\n  name              String\n  isTurnOn          Boolean            @default(false) @map(\"is_turn_on\")\n  createdAt         DateTime           @default(now()) @map(\"created_at\")\n  updatedAt         DateTime           @default(now()) @updatedAt @map(\"updated_at\")\n  groundOrgPolygons GroundOrgPolygon[]\n\n  @@map(\"ground_org\")\n  @@schema(\"jupiter\")\n}\n\nenum GroundOrgPolygonType {\n  PRIORITY\n  IGNORE\n\n  @@schema(\"jupiter\")\n}\n\nmodel GroundOrgPolygon {\n  id          String                                 @id @default(uuid())\n  name        String\n  position    Unsupported(\"geometry(Polygon, 4326)\")\n  groundOrg   GroundOrg                              @relation(fields: [groundOrgId], references: [id], onDelete: Cascade)\n  createdAt   DateTime                               @default(now()) @map(\"created_at\")\n  updatedAt   DateTime                               @default(now()) @updatedAt @map(\"updated_at\")\n  type        GroundOrgPolygonType                   @default(PRIORITY) @map(\"polygon_type\")\n  groundOrgId String                                 @map(\"ground_org_id\")\n  metadata    Json                                   @default(\"{}\") @map(\"metadata\")\n\n  @@map(\"ground_org_polygon\")\n  @@schema(\"jupiter\")\n}\n\nmodel Indication {\n  creationTime  DateTime                             @map(\"creation_time\")\n  id            Int\n  radarId       Int                                  @map(\"radar_id\")\n  coordinates   Unsupported(\"geometry(Point, 4326)\")\n  detectionType String?                              @map(\"detection_type\")\n\n  @@id([creationTime, id, radarId])\n  @@map(\"indications\")\n  @@schema(\"jupiter\")\n}\n\nmodel ScanPlan {\n  id     String @id @default(uuid())\n  name   String\n  camera Camera @relation(fields: [cameraId], references: [id])\n\n  cameraId String @map(\"camera_id\")\n\n  segments ScanSegment[] @relation(\"PlanToSegments\")\n\n  @@map(\"scan_plans\")\n  @@schema(\"jupiter\")\n}\n\nmodel ScanSegment {\n  id        String                                    @id @default(uuid())\n  name      String\n  plan      ScanPlan                                  @relation(\"PlanToSegments\", fields: [planId], references: [id], onDelete: Cascade)\n  pattern   SegmentPatternEnum\n  speed     SegmentSpeedEnum\n  field     SegmentFieldEnum\n  positions Unsupported(\"geometry(LineString, 4326)\")\n\n  planId String\n\n  @@map(\"segments\")\n  @@schema(\"jupiter\")\n}\n\ngenerator client {\n  provider        = \"prisma-client-js\"\n  previewFeatures = [\"multiSchema\", \"postgresqlExtensions\", \"omitApi\", \"prismaSchemaFolder\"]\n  output          = \"../prisma-client\"\n  binaryTargets   = [\"native\", \"linux-musl-openssl-3.0.x\", \"linux-arm64-openssl-3.0.x\", \"debian-openssl-3.0.x\"]\n}\n\ndatasource db {\n  provider   = \"postgresql\"\n  url        = env(\"DATABASE_URL\")\n  extensions = [postgis, uuidOssp(map: \"uuid-ossp\"), fuzzystrmatch, postgis_tiger_geocoder, postgis_topology]\n  schemas    = [\"jupiter\"]\n}\n\nmodel JupiterVideoServer {\n  taskId  String   @id @map(\"task_id\")\n  address String   @unique\n  port    Int?     @unique\n  cameras Camera[]\n\n  @@map(\"jupiter_video_server\")\n  @@schema(\"jupiter\")\n}\n\nmodel JupiterUser {\n  id          String   @id @default(uuid())\n  createdAt   DateTime @default(now()) @map(\"created_at\")\n  updatedAt   DateTime @default(now()) @updatedAt @map(\"updated_at\")\n  ssn         String   @unique // תעודת זהות\n  militaryId  String?  @unique @map(\"military_id\") // תעודת זהות צבאית\n  email       String\n  firstName   String\n  lastName    String\n  phoneNumber String\n\n  hashedPassword String // hashed password\n  hashedRt       String? // hashed refresh token\n\n  hamalId String\n  Hamal   Hamal?   @relation(fields: [hamalId], references: [id], onDelete: Cascade)\n  station Station?\n  Camera  Camera?\n\n  role UserRolesEnum\n\n  @@map(\"users\")\n  @@schema(\"jupiter\")\n}\n\nmodel ScreenRecording {\n  id                 String   @id @default(uuid())\n  createdAt          DateTime @default(now()) @map(\"created_at\")\n  updatedAt          DateTime @default(now()) @updatedAt @map(\"updated_at\")\n  hlsVideoPath       String   @map(\"hls_video_path\")\n  recordingStartTime DateTime @map(\"recording_start_time\")\n  fileName           String   @map(\"file_name\")\n  duration           Float?   @default(60)\n  station            Station  @relation(fields: [stationId], references: [id])\n  stationId          String   @map(\"station_id\")\n\n  @@map(\"screen_recordings\")\n  @@schema(\"jupiter\")\n}\n\nmodel Hamal {\n  id              String           @id @default(uuid())\n  displayName     String           @map(\"display_name\")\n  cells           Cell[]\n  tasks           Task[]\n  detectedObjects DetectedObject[]\n  radars          Radar[]\n  users           JupiterUser[]\n  commonLangs     CommonLang[]\n\n  @@map(\"hamals\")\n  @@schema(\"jupiter\")\n}\n\nmodel CommonLang {\n  id          String @id @default(uuid())\n  lat         Float\n  lng         Float\n  description String\n  hamalId     String\n  hamal       Hamal  @relation(fields: [hamalId], references: [id])\n\n  @@map(\"commonLang\")\n  @@schema(\"jupiter\")\n}\n\nmodel DeviceStatus {\n  id          String           @id @default(uuid())\n  name        DeviceStatusEnum\n  displayName String\n\n  @@map(\"device_statuses\")\n  @@schema(\"jupiter\")\n}\n\nmodel Camera {\n  id            String           @id @default(uuid())\n  name          String\n  color         String\n  lat           Float\n  IP            String           @default(\"0.0.0.0\") @map(\"ip\")\n  port          Int?             @default(80)\n  streamingPort Int?             @map(\"streaming_port\")\n  streamingPath String?          @map(\"streaming_path\")\n  long          Float\n  status        DeviceStatusEnum\n  isRecording   Boolean          @default(false) @map(\"is_recording\")\n\n  vendor JupiterVendor @default(FAKE)\n\n  cell Cell? @relation(fields: [cellId], references: [id], onDelete: Cascade)\n\n  cellId                      String?\n  cameraResponsibilityPolygon CameraResponsibilityPolygon[]\n  cameraRecordings            CameraRecordings[]\n  videoServer                 JupiterVideoServer?           @relation(fields: [videoServerId], references: [taskId])\n  videoServerId               String?                       @map(\"video_server_id\")\n  scanPlans                   ScanPlan[]\n\n  user            JupiterUser? @relation(fields: [activeSpotterId], references: [id])\n  activeSpotterId String?      @unique @map(\"active_spotter_id\")\n\n  @@map(\"cameras\")\n  @@schema(\"jupiter\")\n}\n\nmodel CameraRecordings {\n  id                String   @id @default(uuid())\n  createdAt         DateTime @default(now()) @map(\"created_at\")\n  updatedAt         DateTime @default(now()) @updatedAt @map(\"updated_at\")\n  camera            Camera   @relation(fields: [cameraId], references: [id])\n  cameraId          String   @map(\"camera_id\")\n  recordingDatetime DateTime @map(\"recording_datetime\")\n  duration          Float\n  fileName          String   @map(\"file_name\")\n  url               String   @map(\"url\")\n\n  @@map(\"camera_recordings\")\n  @@schema(\"jupiter\")\n}\n\nmodel Radar {\n  id     String           @id @default(uuid())\n  name   String\n  color  String\n  lat    Float\n  long   Float\n  status DeviceStatusEnum\n\n  hamal Hamal @relation(fields: [hamalId], references: [id])\n\n  hamalId String\n\n  @@map(\"radars\")\n  @@schema(\"jupiter\")\n}\n\nmodel Station {\n  id           String      @id @default(uuid())\n  displayName  String      @map(\"display_name\")\n  cell         Cell        @relation(fields: [cellId], references: [id], onDelete: Cascade)\n  type         StationType\n  cellRowIndex Int         @default(autoincrement()) @map(\"cell_row_date\")\n\n  tasks Task[]\n  user  JupiterUser? @relation(fields: [activeSpotterId], references: [id])\n\n  activeSpotterId String?           @unique @map(\"active_spotter_id\")\n  cellId          String            @map(\"cell_id\")\n  ScreenRecording ScreenRecording[]\n\n  @@map(\"stations\")\n  @@schema(\"jupiter\")\n}\n\nmodel Task {\n  id                    String                     @id @default(uuid())\n  name                  String\n  description           String?\n  createdAt             DateTime                   @default(now()) @map(\"created_at\")\n  updatedAt             DateTime                   @default(now()) @updatedAt @map(\"updated_at\")\n  taskClassification    TaskClassificationEnum?\n  spotterClassification SpotterClassificationEnum?\n  status                TaskStatusEnum\n  fusedDetection        FusedDetection             @relation(fields: [fusedDetectionId], references: [id])\n  score                 Float\n  hamal                 Hamal                      @relation(fields: [hamalId], references: [id])\n  station               Station?                   @relation(fields: [stationId], references: [id])\n\n  fusedDetectionId String  @unique\n  hamalId          String\n  stationId        String?\n\n  @@map(\"tasks\")\n  @@schema(\"jupiter\")\n}\n\nmodel TaskClassification {\n  id          String                 @id @default(uuid())\n  name        TaskClassificationEnum\n  displayName String\n\n  @@map(\"task_classifications\")\n  @@schema(\"jupiter\")\n}\n\nmodel SpotterClassification {\n  id          String                    @id @default(uuid())\n  name        SpotterClassificationEnum\n  displayName String\n\n  @@map(\"spotter_classifications\")\n  @@schema(\"jupiter\")\n}\n\nmodel TaskStatus {\n  id          String         @id @default(uuid())\n  name        TaskStatusEnum\n  displayName String\n\n  @@map(\"task_statuses\")\n  @@schema(\"jupiter\")\n}\n\nmodel DetectedObject {\n  id             String          @id @default(uuid())\n  name           String\n  description    String?\n  createdAt      DateTime        @default(now()) @map(\"created_at\")\n  updatedAt      DateTime        @default(now()) @updatedAt @map(\"updated_at\")\n  hamal          Hamal           @relation(fields: [hamalId], references: [id])\n  fusedDetection FusedDetection? @relation(fields: [fusedDetectionId], references: [id])\n  score          Float\n\n  hamalId          String\n  fusedDetectionId String? @unique\n\n  @@map(\"detected_objects\")\n  @@schema(\"jupiter\")\n}\n\nmodel FusedDetection {\n  id                  String                  @id @default(uuid())\n  name                String\n  createdAt           DateTime                @default(now()) @map(\"created_at\")\n  updatedAt           DateTime                @default(now()) @updatedAt @map(\"updated_at\")\n  fusedClassification FusedClassificationEnum\n  lat                 Float\n  long                Float\n\n  cameraDetections CameraDetection[]\n  radarDetections  RadarDetection[]\n  hunterDetections HunterDetection[]\n\n  task           Task?\n  detectedObject DetectedObject?\n\n  @@map(\"fused_detection\")\n  @@schema(\"jupiter\")\n}\n\nmodel FusedClassification {\n  id          String                  @id @default(uuid())\n  name        FusedClassificationEnum\n  displayName String\n\n  @@map(\"fused_classifications\")\n  @@schema(\"jupiter\")\n}\n\nmodel CameraDetection {\n  id             String         @id @default(uuid())\n  name           String\n  createdAt      DateTime       @default(now()) @map(\"created_at\")\n  fusedDetection FusedDetection @relation(fields: [fusedDetectionId], references: [id])\n\n  fusedDetectionId String\n\n  @@map(\"camera_detections\")\n  @@schema(\"jupiter\")\n}\n\nmodel RadarDetection {\n  id             String         @id @default(uuid())\n  name           String\n  createdAt      DateTime       @default(now()) @map(\"created_at\")\n  fusedDetection FusedDetection @relation(fields: [fusedDetectionId], references: [id])\n\n  fusedDetectionId String\n\n  @@map(\"radar_detections\")\n  @@schema(\"jupiter\")\n}\n\nmodel HunterDetection {\n  id             String         @id @default(uuid())\n  name           String\n  createdAt      DateTime       @default(now()) @map(\"created_at\")\n  fusedDetection FusedDetection @relation(fields: [fusedDetectionId], references: [id])\n\n  fusedDetectionId String\n\n  @@map(\"hunter_detections\")\n  @@schema(\"jupiter\")\n}\n",
  "inlineSchemaHash": "a23e98abbc775628d958dac450a6c03d32dd8d071ec7342d5518651146ece716",
  "copyEngine": true
}
config.dirname = '/'

config.runtimeDataModel = JSON.parse("{\"models\":{\"CameraResponsibilityPolygon\":{\"dbName\":\"camera_responsibility_polygons\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"dbName\":\"created_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"dbName\":\"updated_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"camera\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Camera\",\"relationName\":\"CameraToCameraResponsibilityPolygon\",\"relationFromFields\":[\"cameraId\"],\"relationToFields\":[\"id\"],\"relationOnDelete\":\"Cascade\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cameraId\",\"dbName\":\"camera_id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cell\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Cell\",\"relationName\":\"CameraResponsibilityPolygonToCell\",\"relationFromFields\":[\"cellId\"],\"relationToFields\":[\"id\"],\"relationOnDelete\":\"Cascade\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cellId\",\"dbName\":\"cell_id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cellRowIndex\",\"dbName\":\"cell_row_date\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Int\",\"default\":{\"name\":\"autoincrement\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"overlappedPolygonsPriority\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"OverlapPriority\",\"relationName\":\"overlappedPolygonsPriority\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"intersectedPriority\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"OverlapPriority\",\"relationName\":\"intersectedPriority\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"OverlapPriority\":{\"dbName\":\"overlap_priority\",\"fields\":[{\"name\":\"polygonId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"overlappedPolygonId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"ranking\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Int\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cameraResponsibilityPolygon\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"CameraResponsibilityPolygon\",\"relationName\":\"overlappedPolygonsPriority\",\"relationFromFields\":[\"polygonId\"],\"relationToFields\":[\"id\"],\"relationOnDelete\":\"Cascade\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"overlappedPolygon\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"CameraResponsibilityPolygon\",\"relationName\":\"intersectedPriority\",\"relationFromFields\":[\"overlappedPolygonId\"],\"relationToFields\":[\"id\"],\"relationOnDelete\":\"Cascade\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":{\"name\":null,\"fields\":[\"polygonId\",\"overlappedPolygonId\"]},\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"Cell\":{\"dbName\":\"cells\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"displayName\",\"dbName\":\"display_name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"hamal\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Hamal\",\"relationName\":\"CellToHamal\",\"relationFromFields\":[\"hamalId\"],\"relationToFields\":[\"id\"],\"relationOnDelete\":\"Cascade\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"stations\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Station\",\"relationName\":\"CellToStation\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"hamalId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"CameraResponsibilityPolygon\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"CameraResponsibilityPolygon\",\"relationName\":\"CameraResponsibilityPolygonToCell\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cameras\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Camera\",\"relationName\":\"CameraToCell\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"GroundOrg\":{\"dbName\":\"ground_org\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"isTurnOn\",\"dbName\":\"is_turn_on\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Boolean\",\"default\":false,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"dbName\":\"created_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"dbName\":\"updated_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"groundOrgPolygons\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"GroundOrgPolygon\",\"relationName\":\"GroundOrgToGroundOrgPolygon\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"GroundOrgPolygon\":{\"dbName\":\"ground_org_polygon\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"groundOrg\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"GroundOrg\",\"relationName\":\"GroundOrgToGroundOrgPolygon\",\"relationFromFields\":[\"groundOrgId\"],\"relationToFields\":[\"id\"],\"relationOnDelete\":\"Cascade\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"dbName\":\"created_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"dbName\":\"updated_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"type\",\"dbName\":\"polygon_type\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"GroundOrgPolygonType\",\"default\":\"PRIORITY\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"groundOrgId\",\"dbName\":\"ground_org_id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"metadata\",\"dbName\":\"metadata\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Json\",\"default\":\"{}\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"Indication\":{\"dbName\":\"indications\",\"fields\":[{\"name\":\"creationTime\",\"dbName\":\"creation_time\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Int\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"radarId\",\"dbName\":\"radar_id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Int\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"detectionType\",\"dbName\":\"detection_type\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":{\"name\":null,\"fields\":[\"creationTime\",\"id\",\"radarId\"]},\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"ScanPlan\":{\"dbName\":\"scan_plans\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"camera\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Camera\",\"relationName\":\"CameraToScanPlan\",\"relationFromFields\":[\"cameraId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cameraId\",\"dbName\":\"camera_id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"segments\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"ScanSegment\",\"relationName\":\"PlanToSegments\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"ScanSegment\":{\"dbName\":\"segments\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"plan\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"ScanPlan\",\"relationName\":\"PlanToSegments\",\"relationFromFields\":[\"planId\"],\"relationToFields\":[\"id\"],\"relationOnDelete\":\"Cascade\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"pattern\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"SegmentPatternEnum\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"speed\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"SegmentSpeedEnum\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"field\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"SegmentFieldEnum\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"planId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"JupiterVideoServer\":{\"dbName\":\"jupiter_video_server\",\"fields\":[{\"name\":\"taskId\",\"dbName\":\"task_id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"address\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":true,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"port\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":true,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Int\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cameras\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Camera\",\"relationName\":\"CameraToJupiterVideoServer\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"JupiterUser\":{\"dbName\":\"users\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"dbName\":\"created_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"dbName\":\"updated_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"ssn\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":true,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"militaryId\",\"dbName\":\"military_id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":true,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"email\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"firstName\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"lastName\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"phoneNumber\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"hashedPassword\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"hashedRt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"hamalId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"Hamal\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Hamal\",\"relationName\":\"HamalToJupiterUser\",\"relationFromFields\":[\"hamalId\"],\"relationToFields\":[\"id\"],\"relationOnDelete\":\"Cascade\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"station\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Station\",\"relationName\":\"JupiterUserToStation\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"Camera\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Camera\",\"relationName\":\"CameraToJupiterUser\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"role\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"UserRolesEnum\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"ScreenRecording\":{\"dbName\":\"screen_recordings\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"dbName\":\"created_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"dbName\":\"updated_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"hlsVideoPath\",\"dbName\":\"hls_video_path\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"recordingStartTime\",\"dbName\":\"recording_start_time\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fileName\",\"dbName\":\"file_name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"duration\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Float\",\"default\":60,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"station\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Station\",\"relationName\":\"ScreenRecordingToStation\",\"relationFromFields\":[\"stationId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"stationId\",\"dbName\":\"station_id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"Hamal\":{\"dbName\":\"hamals\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"displayName\",\"dbName\":\"display_name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cells\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Cell\",\"relationName\":\"CellToHamal\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"tasks\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Task\",\"relationName\":\"HamalToTask\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"detectedObjects\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DetectedObject\",\"relationName\":\"DetectedObjectToHamal\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"radars\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Radar\",\"relationName\":\"HamalToRadar\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"users\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"JupiterUser\",\"relationName\":\"HamalToJupiterUser\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"commonLangs\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"CommonLang\",\"relationName\":\"CommonLangToHamal\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"CommonLang\":{\"dbName\":\"commonLang\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"lat\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Float\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"lng\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Float\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"description\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"hamalId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"hamal\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Hamal\",\"relationName\":\"CommonLangToHamal\",\"relationFromFields\":[\"hamalId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"DeviceStatus\":{\"dbName\":\"device_statuses\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DeviceStatusEnum\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"displayName\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"Camera\":{\"dbName\":\"cameras\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"color\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"lat\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Float\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"IP\",\"dbName\":\"ip\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":\"0.0.0.0\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"port\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Int\",\"default\":80,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"streamingPort\",\"dbName\":\"streaming_port\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Int\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"streamingPath\",\"dbName\":\"streaming_path\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"long\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Float\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"status\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DeviceStatusEnum\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"isRecording\",\"dbName\":\"is_recording\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Boolean\",\"default\":false,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"vendor\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"JupiterVendor\",\"default\":\"FAKE\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cell\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Cell\",\"relationName\":\"CameraToCell\",\"relationFromFields\":[\"cellId\"],\"relationToFields\":[\"id\"],\"relationOnDelete\":\"Cascade\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cellId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cameraResponsibilityPolygon\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"CameraResponsibilityPolygon\",\"relationName\":\"CameraToCameraResponsibilityPolygon\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cameraRecordings\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"CameraRecordings\",\"relationName\":\"CameraToCameraRecordings\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"videoServer\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"JupiterVideoServer\",\"relationName\":\"CameraToJupiterVideoServer\",\"relationFromFields\":[\"videoServerId\"],\"relationToFields\":[\"taskId\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"videoServerId\",\"dbName\":\"video_server_id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"scanPlans\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"ScanPlan\",\"relationName\":\"CameraToScanPlan\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"user\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"JupiterUser\",\"relationName\":\"CameraToJupiterUser\",\"relationFromFields\":[\"activeSpotterId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"activeSpotterId\",\"dbName\":\"active_spotter_id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":true,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"CameraRecordings\":{\"dbName\":\"camera_recordings\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"dbName\":\"created_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"dbName\":\"updated_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"camera\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Camera\",\"relationName\":\"CameraToCameraRecordings\",\"relationFromFields\":[\"cameraId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cameraId\",\"dbName\":\"camera_id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"recordingDatetime\",\"dbName\":\"recording_datetime\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"duration\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Float\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fileName\",\"dbName\":\"file_name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"url\",\"dbName\":\"url\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"Radar\":{\"dbName\":\"radars\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"color\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"lat\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Float\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"long\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Float\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"status\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DeviceStatusEnum\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"hamal\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Hamal\",\"relationName\":\"HamalToRadar\",\"relationFromFields\":[\"hamalId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"hamalId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"Station\":{\"dbName\":\"stations\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"displayName\",\"dbName\":\"display_name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cell\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Cell\",\"relationName\":\"CellToStation\",\"relationFromFields\":[\"cellId\"],\"relationToFields\":[\"id\"],\"relationOnDelete\":\"Cascade\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"type\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"StationType\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cellRowIndex\",\"dbName\":\"cell_row_date\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Int\",\"default\":{\"name\":\"autoincrement\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"tasks\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Task\",\"relationName\":\"StationToTask\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"user\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"JupiterUser\",\"relationName\":\"JupiterUserToStation\",\"relationFromFields\":[\"activeSpotterId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"activeSpotterId\",\"dbName\":\"active_spotter_id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":true,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cellId\",\"dbName\":\"cell_id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"ScreenRecording\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"ScreenRecording\",\"relationName\":\"ScreenRecordingToStation\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"Task\":{\"dbName\":\"tasks\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"description\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"dbName\":\"created_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"dbName\":\"updated_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"taskClassification\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"TaskClassificationEnum\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"spotterClassification\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"SpotterClassificationEnum\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"status\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"TaskStatusEnum\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fusedDetection\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"FusedDetection\",\"relationName\":\"FusedDetectionToTask\",\"relationFromFields\":[\"fusedDetectionId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"score\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Float\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"hamal\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Hamal\",\"relationName\":\"HamalToTask\",\"relationFromFields\":[\"hamalId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"station\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Station\",\"relationName\":\"StationToTask\",\"relationFromFields\":[\"stationId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fusedDetectionId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":true,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"hamalId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"stationId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"TaskClassification\":{\"dbName\":\"task_classifications\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"TaskClassificationEnum\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"displayName\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"SpotterClassification\":{\"dbName\":\"spotter_classifications\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"SpotterClassificationEnum\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"displayName\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"TaskStatus\":{\"dbName\":\"task_statuses\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"TaskStatusEnum\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"displayName\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"DetectedObject\":{\"dbName\":\"detected_objects\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"description\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"dbName\":\"created_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"dbName\":\"updated_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"hamal\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Hamal\",\"relationName\":\"DetectedObjectToHamal\",\"relationFromFields\":[\"hamalId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fusedDetection\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"FusedDetection\",\"relationName\":\"DetectedObjectToFusedDetection\",\"relationFromFields\":[\"fusedDetectionId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"score\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Float\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"hamalId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fusedDetectionId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":true,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"FusedDetection\":{\"dbName\":\"fused_detection\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"dbName\":\"created_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"dbName\":\"updated_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"fusedClassification\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"FusedClassificationEnum\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"lat\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Float\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"long\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Float\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"cameraDetections\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"CameraDetection\",\"relationName\":\"CameraDetectionToFusedDetection\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"radarDetections\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"RadarDetection\",\"relationName\":\"FusedDetectionToRadarDetection\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"hunterDetections\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"HunterDetection\",\"relationName\":\"FusedDetectionToHunterDetection\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"task\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Task\",\"relationName\":\"FusedDetectionToTask\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"detectedObject\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DetectedObject\",\"relationName\":\"DetectedObjectToFusedDetection\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"FusedClassification\":{\"dbName\":\"fused_classifications\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"FusedClassificationEnum\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"displayName\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"CameraDetection\":{\"dbName\":\"camera_detections\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"dbName\":\"created_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fusedDetection\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"FusedDetection\",\"relationName\":\"CameraDetectionToFusedDetection\",\"relationFromFields\":[\"fusedDetectionId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fusedDetectionId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"RadarDetection\":{\"dbName\":\"radar_detections\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"dbName\":\"created_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fusedDetection\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"FusedDetection\",\"relationName\":\"FusedDetectionToRadarDetection\",\"relationFromFields\":[\"fusedDetectionId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fusedDetectionId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"HunterDetection\":{\"dbName\":\"hunter_detections\",\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"default\":{\"name\":\"uuid(4)\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"dbName\":\"created_at\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fusedDetection\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"FusedDetection\",\"relationName\":\"FusedDetectionToHunterDetection\",\"relationFromFields\":[\"fusedDetectionId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fusedDetectionId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false}},\"enums\":{\"TaskClassificationEnum\":{\"values\":[{\"name\":\"OUR_FORCES\",\"dbName\":null},{\"name\":\"FALSE_ALARM\",\"dbName\":null},{\"name\":\"DETECTION_OF_ROUTINE\",\"dbName\":null},{\"name\":\"EXCEPTION_DETECTION\",\"dbName\":null},{\"name\":\"EVENT\",\"dbName\":null},{\"name\":\"SUSPICIOUS\",\"dbName\":null}],\"dbName\":null},\"SpotterClassificationEnum\":{\"values\":[{\"name\":\"PERSON\",\"dbName\":null},{\"name\":\"VEHICLE\",\"dbName\":null},{\"name\":\"ANIMAL\",\"dbName\":null},{\"name\":\"WILED_ANIMAL\",\"dbName\":null},{\"name\":\"ARMED_MAN\",\"dbName\":null},{\"name\":\"GROUP_OF_PEOPLE\",\"dbName\":null},{\"name\":\"HERD_WITH_A_SHEPHERD\",\"dbName\":null},{\"name\":\"HERD_WITHOUT_A_SHEPHERD\",\"dbName\":null},{\"name\":\"HOME_VISIT\",\"dbName\":null},{\"name\":\"FENCE_ALERT\",\"dbName\":null}],\"dbName\":null},\"FusedClassificationEnum\":{\"values\":[{\"name\":\"VEHICLE\",\"dbName\":null},{\"name\":\"HUMAN\",\"dbName\":null},{\"name\":\"ANIMAL\",\"dbName\":null},{\"name\":\"UNIDENTIFIED\",\"dbName\":null},{\"name\":\"MOVING_UNIDENTIFIED\",\"dbName\":null}],\"dbName\":null},\"TaskStatusEnum\":{\"values\":[{\"name\":\"IN_PROGRESS\",\"dbName\":null},{\"name\":\"OPEN\",\"dbName\":null},{\"name\":\"DONE\",\"dbName\":null}],\"dbName\":null},\"DeviceStatusEnum\":{\"values\":[{\"name\":\"ACTIVE\",\"dbName\":null},{\"name\":\"INACTIVE\",\"dbName\":null},{\"name\":\"ERROR\",\"dbName\":null},{\"name\":\"INITIALIZATION\",\"dbName\":null}],\"dbName\":null},\"StationType\":{\"values\":[{\"name\":\"MONITOR\",\"dbName\":null},{\"name\":\"INVESTIGATOR\",\"dbName\":null}],\"dbName\":null},\"UserRolesEnum\":{\"values\":[{\"name\":\"SUPER_ADMIN\",\"dbName\":null},{\"name\":\"COMMANDER\",\"dbName\":null},{\"name\":\"SPOTTER\",\"dbName\":null}],\"dbName\":null},\"JupiterVendor\":{\"values\":[{\"name\":\"FAKE\",\"dbName\":null},{\"name\":\"OTHER\",\"dbName\":null},{\"name\":\"FILE\",\"dbName\":null},{\"name\":\"MPEG_TS\",\"dbName\":null}],\"dbName\":\"jupiter_vendor\"},\"SegmentPatternEnum\":{\"values\":[{\"name\":\"STRIP\",\"dbName\":null},{\"name\":\"PERIPHERAL\",\"dbName\":null}],\"dbName\":\"segment_pattern\"},\"SegmentSpeedEnum\":{\"values\":[{\"name\":\"X0_5\",\"dbName\":null},{\"name\":\"X1\",\"dbName\":null},{\"name\":\"X2\",\"dbName\":null}],\"dbName\":\"segment_speed\"},\"SegmentFieldEnum\":{\"values\":[{\"name\":\"WIDE\",\"dbName\":null},{\"name\":\"NARROW\",\"dbName\":null},{\"name\":\"VERY_NARROW\",\"dbName\":null}],\"dbName\":\"segment_field\"},\"GroundOrgPolygonType\":{\"values\":[{\"name\":\"PRIORITY\",\"dbName\":null},{\"name\":\"IGNORE\",\"dbName\":null}],\"dbName\":null}},\"types\":{}}")
defineDmmfProperty(exports.Prisma, config.runtimeDataModel)
config.engineWasm = undefined

config.injectableEdgeEnv = () => ({
  parsed: {
    DATABASE_URL: typeof globalThis !== 'undefined' && globalThis['DATABASE_URL'] || typeof process !== 'undefined' && process.env && process.env.DATABASE_URL || undefined
  }
})

if (typeof globalThis !== 'undefined' && globalThis['DEBUG'] || typeof process !== 'undefined' && process.env && process.env.DEBUG || undefined) {
  Debug.enable(typeof globalThis !== 'undefined' && globalThis['DEBUG'] || typeof process !== 'undefined' && process.env && process.env.DEBUG || undefined)
}

const PrismaClient = getPrismaClient(config)
exports.PrismaClient = PrismaClient
Object.assign(exports, Prisma)

