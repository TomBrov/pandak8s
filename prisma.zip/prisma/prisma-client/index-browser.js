
Object.defineProperty(exports, "__esModule", { value: true });

const {
  Decimal,
  objectEnumValues,
  makeStrictEnum,
  Public,
  getRuntime,
  skip
} = require('./runtime/index-browser.js')


const Prisma = {}

exports.Prisma = Prisma
exports.$Enums = {}

/**
 * Prisma Client JS version: 5.22.0
 * Query Engine version: 605197351a3c8bdd595af2d2a9bc3025bca48ea2
 */
Prisma.prismaVersion = {
  client: "5.22.0",
  engine: "605197351a3c8bdd595af2d2a9bc3025bca48ea2"
}

Prisma.PrismaClientKnownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientKnownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)};
Prisma.PrismaClientUnknownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientUnknownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientRustPanicError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientRustPanicError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientInitializationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientInitializationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientValidationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientValidationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.NotFoundError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`NotFoundError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.Decimal = Decimal

/**
 * Re-export of sql-template-tag
 */
Prisma.sql = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`sqltag is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.empty = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`empty is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.join = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`join is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.raw = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`raw is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.validator = Public.validator

/**
* Extensions
*/
Prisma.getExtensionContext = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.getExtensionContext is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.defineExtension = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.defineExtension is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}

/**
 * Shorthand utilities for JSON filtering
 */
Prisma.DbNull = objectEnumValues.instances.DbNull
Prisma.JsonNull = objectEnumValues.instances.JsonNull
Prisma.AnyNull = objectEnumValues.instances.AnyNull

Prisma.NullTypes = {
  DbNull: objectEnumValues.classes.DbNull,
  JsonNull: objectEnumValues.classes.JsonNull,
  AnyNull: objectEnumValues.classes.AnyNull
}



/**
 * Enums
 */

exports.Prisma.TransactionIsolationLevel = makeStrictEnum({
  ReadUncommitted: 'ReadUncommitted',
  ReadCommitted: 'ReadCommitted',
  RepeatableRead: 'RepeatableRead',
  Serializable: 'Serializable'
});

exports.Prisma.CameraResponsibilityPolygonScalarFieldEnum = {
  id: 'id',
  name: 'name',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  cameraId: 'cameraId',
  cellId: 'cellId',
  cellRowIndex: 'cellRowIndex'
};

exports.Prisma.OverlapPriorityScalarFieldEnum = {
  polygonId: 'polygonId',
  overlappedPolygonId: 'overlappedPolygonId',
  ranking: 'ranking'
};

exports.Prisma.CellScalarFieldEnum = {
  id: 'id',
  displayName: 'displayName',
  hamalId: 'hamalId'
};

exports.Prisma.GroundOrgScalarFieldEnum = {
  id: 'id',
  name: 'name',
  isTurnOn: 'isTurnOn',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.GroundOrgPolygonScalarFieldEnum = {
  id: 'id',
  name: 'name',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  type: 'type',
  groundOrgId: 'groundOrgId',
  metadata: 'metadata'
};

exports.Prisma.IndicationScalarFieldEnum = {
  creationTime: 'creationTime',
  id: 'id',
  radarId: 'radarId',
  detectionType: 'detectionType'
};

exports.Prisma.ScanPlanScalarFieldEnum = {
  id: 'id',
  name: 'name',
  cameraId: 'cameraId'
};

exports.Prisma.ScanSegmentScalarFieldEnum = {
  id: 'id',
  name: 'name',
  pattern: 'pattern',
  speed: 'speed',
  field: 'field',
  planId: 'planId'
};

exports.Prisma.JupiterVideoServerScalarFieldEnum = {
  taskId: 'taskId',
  address: 'address',
  port: 'port'
};

exports.Prisma.JupiterUserScalarFieldEnum = {
  id: 'id',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  ssn: 'ssn',
  militaryId: 'militaryId',
  email: 'email',
  firstName: 'firstName',
  lastName: 'lastName',
  phoneNumber: 'phoneNumber',
  hashedPassword: 'hashedPassword',
  hashedRt: 'hashedRt',
  hamalId: 'hamalId',
  role: 'role'
};

exports.Prisma.ScreenRecordingScalarFieldEnum = {
  id: 'id',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  hlsVideoPath: 'hlsVideoPath',
  recordingStartTime: 'recordingStartTime',
  fileName: 'fileName',
  duration: 'duration',
  stationId: 'stationId'
};

exports.Prisma.HamalScalarFieldEnum = {
  id: 'id',
  displayName: 'displayName'
};

exports.Prisma.CommonLangScalarFieldEnum = {
  id: 'id',
  lat: 'lat',
  lng: 'lng',
  description: 'description',
  hamalId: 'hamalId'
};

exports.Prisma.DeviceStatusScalarFieldEnum = {
  id: 'id',
  name: 'name',
  displayName: 'displayName'
};

exports.Prisma.CameraScalarFieldEnum = {
  id: 'id',
  name: 'name',
  color: 'color',
  lat: 'lat',
  IP: 'IP',
  port: 'port',
  streamingPort: 'streamingPort',
  streamingPath: 'streamingPath',
  long: 'long',
  status: 'status',
  isRecording: 'isRecording',
  vendor: 'vendor',
  cellId: 'cellId',
  videoServerId: 'videoServerId',
  activeSpotterId: 'activeSpotterId'
};

exports.Prisma.CameraRecordingsScalarFieldEnum = {
  id: 'id',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  cameraId: 'cameraId',
  recordingDatetime: 'recordingDatetime',
  duration: 'duration',
  fileName: 'fileName',
  url: 'url'
};

exports.Prisma.RadarScalarFieldEnum = {
  id: 'id',
  name: 'name',
  color: 'color',
  lat: 'lat',
  long: 'long',
  status: 'status',
  hamalId: 'hamalId'
};

exports.Prisma.StationScalarFieldEnum = {
  id: 'id',
  displayName: 'displayName',
  type: 'type',
  cellRowIndex: 'cellRowIndex',
  activeSpotterId: 'activeSpotterId',
  cellId: 'cellId'
};

exports.Prisma.TaskScalarFieldEnum = {
  id: 'id',
  name: 'name',
  description: 'description',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  taskClassification: 'taskClassification',
  spotterClassification: 'spotterClassification',
  status: 'status',
  score: 'score',
  fusedDetectionId: 'fusedDetectionId',
  hamalId: 'hamalId',
  stationId: 'stationId'
};

exports.Prisma.TaskClassificationScalarFieldEnum = {
  id: 'id',
  name: 'name',
  displayName: 'displayName'
};

exports.Prisma.SpotterClassificationScalarFieldEnum = {
  id: 'id',
  name: 'name',
  displayName: 'displayName'
};

exports.Prisma.TaskStatusScalarFieldEnum = {
  id: 'id',
  name: 'name',
  displayName: 'displayName'
};

exports.Prisma.DetectedObjectScalarFieldEnum = {
  id: 'id',
  name: 'name',
  description: 'description',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  score: 'score',
  hamalId: 'hamalId',
  fusedDetectionId: 'fusedDetectionId'
};

exports.Prisma.FusedDetectionScalarFieldEnum = {
  id: 'id',
  name: 'name',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  fusedClassification: 'fusedClassification',
  lat: 'lat',
  long: 'long'
};

exports.Prisma.FusedClassificationScalarFieldEnum = {
  id: 'id',
  name: 'name',
  displayName: 'displayName'
};

exports.Prisma.CameraDetectionScalarFieldEnum = {
  id: 'id',
  name: 'name',
  createdAt: 'createdAt',
  fusedDetectionId: 'fusedDetectionId'
};

exports.Prisma.RadarDetectionScalarFieldEnum = {
  id: 'id',
  name: 'name',
  createdAt: 'createdAt',
  fusedDetectionId: 'fusedDetectionId'
};

exports.Prisma.HunterDetectionScalarFieldEnum = {
  id: 'id',
  name: 'name',
  createdAt: 'createdAt',
  fusedDetectionId: 'fusedDetectionId'
};

exports.Prisma.SortOrder = {
  asc: 'asc',
  desc: 'desc'
};

exports.Prisma.JsonNullValueInput = {
  JsonNull: Prisma.JsonNull
};

exports.Prisma.QueryMode = {
  default: 'default',
  insensitive: 'insensitive'
};

exports.Prisma.JsonNullValueFilter = {
  DbNull: Prisma.DbNull,
  JsonNull: Prisma.JsonNull,
  AnyNull: Prisma.AnyNull
};

exports.Prisma.NullsOrder = {
  first: 'first',
  last: 'last'
};
exports.GroundOrgPolygonType = exports.$Enums.GroundOrgPolygonType = {
  PRIORITY: 'PRIORITY',
  IGNORE: 'IGNORE'
};

exports.SegmentPatternEnum = exports.$Enums.SegmentPatternEnum = {
  STRIP: 'STRIP',
  PERIPHERAL: 'PERIPHERAL'
};

exports.SegmentSpeedEnum = exports.$Enums.SegmentSpeedEnum = {
  X0_5: 'X0_5',
  X1: 'X1',
  X2: 'X2'
};

exports.SegmentFieldEnum = exports.$Enums.SegmentFieldEnum = {
  WIDE: 'WIDE',
  NARROW: 'NARROW',
  VERY_NARROW: 'VERY_NARROW'
};

exports.UserRolesEnum = exports.$Enums.UserRolesEnum = {
  SUPER_ADMIN: 'SUPER_ADMIN',
  COMMANDER: 'COMMANDER',
  SPOTTER: 'SPOTTER'
};

exports.DeviceStatusEnum = exports.$Enums.DeviceStatusEnum = {
  ACTIVE: 'ACTIVE',
  INACTIVE: 'INACTIVE',
  ERROR: 'ERROR',
  INITIALIZATION: 'INITIALIZATION'
};

exports.JupiterVendor = exports.$Enums.JupiterVendor = {
  FAKE: 'FAKE',
  OTHER: 'OTHER',
  FILE: 'FILE',
  MPEG_TS: 'MPEG_TS'
};

exports.StationType = exports.$Enums.StationType = {
  MONITOR: 'MONITOR',
  INVESTIGATOR: 'INVESTIGATOR'
};

exports.TaskClassificationEnum = exports.$Enums.TaskClassificationEnum = {
  OUR_FORCES: 'OUR_FORCES',
  FALSE_ALARM: 'FALSE_ALARM',
  DETECTION_OF_ROUTINE: 'DETECTION_OF_ROUTINE',
  EXCEPTION_DETECTION: 'EXCEPTION_DETECTION',
  EVENT: 'EVENT',
  SUSPICIOUS: 'SUSPICIOUS'
};

exports.SpotterClassificationEnum = exports.$Enums.SpotterClassificationEnum = {
  PERSON: 'PERSON',
  VEHICLE: 'VEHICLE',
  ANIMAL: 'ANIMAL',
  WILED_ANIMAL: 'WILED_ANIMAL',
  ARMED_MAN: 'ARMED_MAN',
  GROUP_OF_PEOPLE: 'GROUP_OF_PEOPLE',
  HERD_WITH_A_SHEPHERD: 'HERD_WITH_A_SHEPHERD',
  HERD_WITHOUT_A_SHEPHERD: 'HERD_WITHOUT_A_SHEPHERD',
  HOME_VISIT: 'HOME_VISIT',
  FENCE_ALERT: 'FENCE_ALERT'
};

exports.TaskStatusEnum = exports.$Enums.TaskStatusEnum = {
  IN_PROGRESS: 'IN_PROGRESS',
  OPEN: 'OPEN',
  DONE: 'DONE'
};

exports.FusedClassificationEnum = exports.$Enums.FusedClassificationEnum = {
  VEHICLE: 'VEHICLE',
  HUMAN: 'HUMAN',
  ANIMAL: 'ANIMAL',
  UNIDENTIFIED: 'UNIDENTIFIED',
  MOVING_UNIDENTIFIED: 'MOVING_UNIDENTIFIED'
};

exports.Prisma.ModelName = {
  CameraResponsibilityPolygon: 'CameraResponsibilityPolygon',
  OverlapPriority: 'OverlapPriority',
  Cell: 'Cell',
  GroundOrg: 'GroundOrg',
  GroundOrgPolygon: 'GroundOrgPolygon',
  Indication: 'Indication',
  ScanPlan: 'ScanPlan',
  ScanSegment: 'ScanSegment',
  JupiterVideoServer: 'JupiterVideoServer',
  JupiterUser: 'JupiterUser',
  ScreenRecording: 'ScreenRecording',
  Hamal: 'Hamal',
  CommonLang: 'CommonLang',
  DeviceStatus: 'DeviceStatus',
  Camera: 'Camera',
  CameraRecordings: 'CameraRecordings',
  Radar: 'Radar',
  Station: 'Station',
  Task: 'Task',
  TaskClassification: 'TaskClassification',
  SpotterClassification: 'SpotterClassification',
  TaskStatus: 'TaskStatus',
  DetectedObject: 'DetectedObject',
  FusedDetection: 'FusedDetection',
  FusedClassification: 'FusedClassification',
  CameraDetection: 'CameraDetection',
  RadarDetection: 'RadarDetection',
  HunterDetection: 'HunterDetection'
};

/**
 * This is a stub Prisma Client that will error at runtime if called.
 */
class PrismaClient {
  constructor() {
    return new Proxy(this, {
      get(target, prop) {
        let message
        const runtime = getRuntime()
        if (runtime.isEdge) {
          message = `PrismaClient is not configured to run in ${runtime.prettyName}. In order to run Prisma Client on edge runtime, either:
- Use Prisma Accelerate: https://pris.ly/d/accelerate
- Use Driver Adapters: https://pris.ly/d/driver-adapters
`;
        } else {
          message = 'PrismaClient is unable to run in this browser environment, or has been bundled for the browser (running in `' + runtime.prettyName + '`).'
        }
        
        message += `
If this is unexpected, please open an issue: https://pris.ly/prisma-prisma-bug-report`

        throw new Error(message)
      }
    })
  }
}

exports.PrismaClient = PrismaClient

Object.assign(exports, Prisma)
