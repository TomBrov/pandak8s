import crypto from 'crypto';
import fs from 'fs';
import * as path from 'node:path';
import * as process from 'node:process';
export class LocalKms {
  private readonly key: Buffer;
  private readonly iv: Buffer;
  private readonly algorithm: string;

  constructor() {
    const symmetric32 = process.env.SYMMETRIC_32_BYTES_KEY_FILE;
    const symmetric16 = process.env.SYMMETRIC_16_BYTES_KEY_FILE;
    const algorithm = process.env.CRYPTO_ALGORITHM;

    if (!symmetric32 || !symmetric16 || !algorithm) {
      throw new Error(
        'env SYMMETRIC_32_BYTES_KEY_FILE, SYMMETRIC_16_BYTES_KEY_FILE, CRYPTO_ALGORITHM is missing or incorrect',
      );
    }

    const root = path.resolve(process.cwd());

    this.key = Buffer.from(
      fs.readFileSync(`${root}/${symmetric32}`, 'utf8'),
      'hex',
    );
    this.iv = Buffer.from(
      fs.readFileSync(`${root}/${symmetric16}`, 'utf8'),
      'hex',
    );
    this.algorithm = algorithm;
  }

  encryptString(plaintext: string): string {
    if (!plaintext) return plaintext;

    const cipher = crypto.createCipheriv(this.algorithm, this.key, this.iv);
    return cipher.update(plaintext, 'utf8', 'base64') + cipher.final('base64');
  }
}
