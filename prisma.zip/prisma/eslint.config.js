const prismaConfig = require('@libraries/eslint-config/eslint.prisma.config');

/** @type {import("eslint").Linter.Config} */
module.exports = [...prismaConfig];
