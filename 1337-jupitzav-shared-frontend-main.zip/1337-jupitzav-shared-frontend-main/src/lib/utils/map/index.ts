import {
  LatLng,
  LatLngBoundsLiteral,
  LatLngExpression,
  LatLngTuple,
} from 'leaflet';

export const getBoundingBox = (
  coordinates: LatLngTuple[],
): LatLngBoundsLiteral | undefined => {
  if (!coordinates?.length) {
    return undefined;
  }

  let minLat = coordinates[0]![0];
  let maxLat = coordinates[0]![0];
  let minLng = coordinates[0]![1];
  let maxLng = coordinates[0]![1];

  coordinates.forEach((coordinate: LatLngTuple) => {
    const lat = coordinate[0];
    const lng = coordinate[1];
    if (lat && lng) {
      if (lat < minLat) minLat = lat;
      if (lat > maxLat) maxLat = lat;
      if (lng < minLng) minLng = lng;
      if (lng > maxLng) maxLng = lng;
    }
  });

  return [
    [minLat, minLng],
    [maxLat, maxLng],
  ];
};

export const getMapCenter = (
  coordinates: LatLngTuple[],
): LatLngTuple | undefined => {
  const boundingBox = getBoundingBox(coordinates);
  if (!boundingBox) {
    return undefined;
  }

  const avgLat = (boundingBox[0]![0] + boundingBox[1]![0]) / 2;
  const avgLng = (boundingBox[0]![1] + boundingBox[1]![1]) / 2;

  return [avgLat, avgLng];
};

export function validateLangInIsraelArea(lat: number) {
  return lat >= 34.2 && lat <= 36;
}

export function validateLatInIsraelArea(lang: number) {
  return lang >= 29.49 && lang <= 33.4;
}

export const convertGeoJsonToLatLngExpressions = (
  positions: GeoJSON.Position[],
): LatLngExpression[] => {
  return positions.map((point) => {
    return new LatLng(point[0]!, point[1]!);
  });
};
