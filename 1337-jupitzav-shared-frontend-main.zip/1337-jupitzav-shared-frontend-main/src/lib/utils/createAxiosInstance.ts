import axios, {
  CreateAxiosDefaults,
  AxiosInstance,
  AxiosResponse,
  InternalAxiosRequestConfig,
  AxiosError,
} from 'axios';
import { AuthServiceType } from '../types/AuthService';

export const createClient = (
  params: CreateAxiosDefaults,
  AuthService: AuthServiceType,
  addJwtToReq: boolean,
): AxiosInstance => {
  const client = axios.create(params);

  const logOnDev = (
    _message: string,
    _log?: AxiosResponse | InternalAxiosRequestConfig | AxiosError,
  ) => {};

  client.interceptors.request.use(async (request) => {
    try {
      const { method, url } = request;

      if (addJwtToReq) {
        const jwtToken = await AuthService.getToken();

        if (jwtToken) {
          request.headers['Authorization'] = `Bearer ${jwtToken}`;
        }
      }

      logOnDev(`🚀 [${method?.toUpperCase()}] ${url} | Request`, request);
    } catch (error) {
      console.error(error);
    }

    return request;
  });

  client.interceptors.response.use(
    (response) => {
      const { method, url } = response.config;
      const { status } = response;

      logOnDev(
        `✨ [${method?.toUpperCase()}] ${url} | Response ${status}`,
        response,
      );

      return response;
    },
    (error) => {
      if (!error.response) {
        return Promise.reject(error);
      }
      const { message } = error;
      const { status, data } = error.response;
      const { method, url } = error.config;

      logOnDev(
        `🚨 [${method?.toUpperCase()}] ${url} | Error ${status} ${data?.message || ''} | ${message}`,
        error,
      );

      return Promise.reject(error);
    },
  );

  return client;
};
