export function validateIsraelId(islId: string): boolean {
  const digits = islId.split('').map(Number);
  if (digits.length !== 9) {
    return false;
  }
  if (digits.find((x) => x === undefined)) {
    return false;
  }
  let sum = 0;
  for (let i = 0; i < 8; i++) {
    let digit = digits[i] || 0;
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    sum += digit;
  }
  const lastDigit = digits[8];
  return (sum + (lastDigit || 0)) % 10 === 0;
}

export const phoneRegex = new RegExp(/^\+[1-9]{1}[0-9]{3,14}$/);
export const strongPasswordRegex = new RegExp(
  /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).{8,16}$/,
);
