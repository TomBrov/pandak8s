export function isLocalDev(): boolean {
  return (
    new Set(['localhost', '127.0.0.1']).has(window.location.hostname) &&
    window.location.port !== '8080'
  );
}
