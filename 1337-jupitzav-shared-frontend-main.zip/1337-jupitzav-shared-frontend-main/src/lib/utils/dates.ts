export function dateToTime(date: Date) {
  return date.toLocaleTimeString('he-IL', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatSelectedDates({
  fromDate,
  toDate,
  fallback,
}: {
  fromDate?: number;
  toDate?: number;
  fallback: string;
}) {
  if (!fromDate || !toDate) {
    return fallback;
  }

  return `${formatDate(new Date(fromDate)).replace(',', ' |')} - ${formatDate(new Date(toDate)).replace(',', ' |')}`;
}

export function formatDate(
  toFormat: Date,
  options: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  },
) {
  const formatter = new Intl.DateTimeFormat('he-IL', options);
  return formatter.format(toFormat);
}
