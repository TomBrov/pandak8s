import { RawEvent } from './event';
import { Detection } from './detection';

export interface MissionType {
  id: number;
  name: string;
}

export interface MissionClassification {
  id: number;
  name: string;
}

export enum MissionStatus {
  OPEN = 'OPEN',
  INPROGRESS = 'INPROGRESS',
  CLOSED = 'CLOSED',
}

export interface Mission {
  id: string;
  name: string;
  description: string | null;
  grade: number;
  status: MissionStatus;
  createdAt: Date;
  updatedAt: Date;
  rawEventId: string;
  handleBy: string | null;
  creatorName: string | null;
  creatorType: string | null;
  hamal: string;
  cityId?: string;
  startHandle: Date | null;
  endHandle: Date | null;
  rawEvent?: RawEvent;
  missionType: MissionType;
  classification: MissionClassification;
  detection?: Detection;
  brigadeId?: string;
}
