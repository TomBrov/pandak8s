export enum DetectionOrigin {
  AI1337 = 'AI1337',
  MATZPEN = 'MATZPEN',
}

export type Detection = {
  id: string;
  createdAt: Date;
  detectionTime: Date;
  origin: DetectionOrigin;
  model: string;
  modelVersion: number;
  s3ImageUrl: string;
  missionId: string;
  ipCameraId: string;
  DetectionLabel: DetectionLabel[];
};

export type DetectionLabel = {
  id: string;
  createdAt: Date;
  name: string;
  score: number;
  minx?: number;
  miny?: number;
  maxx?: number;
  maxy?: number;
  text?: string;
  textScore?: number;
  detectionId: string;
};
