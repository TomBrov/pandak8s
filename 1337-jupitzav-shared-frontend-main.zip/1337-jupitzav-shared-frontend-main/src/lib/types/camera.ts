export enum CameraType {
  HUNTER = 'HUNTER',
  IPCAMERA = 'IPCAMERA',
}

export enum CameraTypeWithActive {
  HUNTER = 'HUNTER',
  IPCAMERA = 'IPCAMERA',

  IPCAMERAACTIVE = 'IPCAMERAACTIVE',
  IPCAMERAHIDDEN = 'IPCAMERAHIDDEN',
  IPCAMERAINACTIVE = 'IPCAMERAINACTIVE',
}

export enum CameraStatus {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE',
  ERROR = 'ERROR',
  INITIALIZATION = 'INITIALIZATION',
}

export type Camera = {
  IP: string;
  ptzIp?: string;
  displayName: string;
  id: string;
  lat: string;
  long: string;
  isPtz: boolean;
  port: number;
  status: CameraStatus;
  updatedAt: Date;
  relatedHunters: string[];
  autoDetection?: boolean;
  isRecording?: boolean;
  createdAt: Date;
  // TODO: when the backend change - change all the optionals
  streamingPort?: number | null;
  missionGrade?: number;
  vendor?: string;
  powerUnitDate?: Date;
  generateDate?: Date;
  isConnectedToElectricity: boolean;
  brigade?: { id: string; name: string };
  camouflageType?: { id: string; name: string };
  isUpsideDown: boolean;
  lastPingDate?: Date;
  pingLatency?: number;
  lastUpdatePowerUnitDate?: Date;
  powerAmount?: string;
  simPhoneNumber?: string;
  simSerialNumber?: string;
  mapLocation?: string;
  serialNumber?: string;
  cityId?: string;
  region?: string;
  model?: string;
  cityCameraLocation?: { id: string; name: string };
  isShowed?: boolean;
};
