export interface RawEvent {
  id: string;
  createdAt: Date;
  updatedAt: Date;
  data: string;
  s3ImageUrl: string;
  IMEI: string;
  hunterkey: string;
}
