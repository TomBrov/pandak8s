export type userSignInAfterMyIdFunc = () => any;
export type userLoginFunc = (ssn: string, password: string) => Promise<string>;
export interface AuthServiceType {
  getToken: () => Promise<string>;
  signIn: (
    username?: string,
    userSignInAfterMyIdf?: userSignInAfterMyIdFunc,
  ) => Promise<{ [key: string]: any }>;
  validateSession: () => Promise<void>;
  sendCustomChallengeAnswer?: (
    user: { [key: string]: any },
    otp: string,
    userLogin: userLoginFunc,
  ) => Promise<{ [key: string]: any }>;
}
