import * as React from 'react';
import { Column } from '@tanstack/react-table';

import { Badge, Popover } from '@radix-ui/themes';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from './Command';
import { CLEAN_FILTERS, NO_RESULTS } from './DataTable.constants';
import {
  BadgeStyled,
  ButtonStyled,
  CheckIconContainer,
  CheckIconStyled,
  PlusCircledIconStyled,
  PopoverContentStyled,
  ResetFiltersButtonStyled,
  SeparatorStyled,
} from './DataTableCommon';
import styled from 'styled-components';
import * as styles from './styles';

interface DataTableFacetedFilterProps<TData, TValue> {
  column?: Column<TData, TValue>;
  title?: string;
  options: {
    label: string;
    value: string;
    icon?: React.ComponentType<{ className?: string }>;
  }[];
}

const SelectedValuesSizeBadge = styled(Badge)`
  ${styles.SelectedValuesSizeBadge}
`;

const SelectedValuesContainer = styled.div`
  ${styles.SelectedValuesContainer}
`;

const OptionIconContainer = styled.span`
  ${styles.OptionIconContainer}
`;

const FacetStyled = styled.span`
  ${styles.FacetStyled}
`;

export function DataTableFacetedFilter<TData, TValue>({
  column,
  title,
  options,
}: DataTableFacetedFilterProps<TData, TValue>) {
  const facets = column?.getFacetedUniqueValues();
  const selectedValues = new Set(column?.getFilterValue() as string[]);

  return (
    <Popover.Root>
      <Popover.Trigger>
        <ButtonStyled variant="outline">
          <PlusCircledIconStyled />
          {title}
          {selectedValues?.size > 0 && (
            <>
              <SeparatorStyled orientation="vertical" />
              <SelectedValuesSizeBadge>
                {selectedValues.size}
              </SelectedValuesSizeBadge>
              <SelectedValuesContainer>
                {selectedValues.size > 1 ? (
                  <BadgeStyled>{selectedValues.size}</BadgeStyled>
                ) : (
                  options
                    .filter((option) => selectedValues.has(option.value))
                    .map((option) => (
                      <BadgeStyled key={option.value}>
                        {option.label}
                      </BadgeStyled>
                    ))
                )}
              </SelectedValuesContainer>
            </>
          )}
        </ButtonStyled>
      </Popover.Trigger>
      <PopoverContentStyled align="start">
        <Command>
          <CommandInput placeholder={title} />
          <CommandList>
            <CommandEmpty>{NO_RESULTS}</CommandEmpty>
            <CommandGroup>
              {options.map((option) => {
                const isSelected = selectedValues.has(option.value);
                return (
                  <CommandItem
                    key={option.value}
                    onSelect={() => {
                      if (isSelected) {
                        selectedValues.delete(option.value);
                      } else {
                        selectedValues.add(option.value);
                      }
                      const filterValues = Array.from(selectedValues);
                      column?.setFilterValue(
                        filterValues?.length ? filterValues : undefined,
                      );
                    }}
                  >
                    <CheckIconContainer isSelected={isSelected}>
                      <CheckIconStyled />
                    </CheckIconContainer>
                    {option.icon && (
                      <OptionIconContainer>
                        <option.icon />
                      </OptionIconContainer>
                    )}
                    <span>{option.label}</span>
                    {facets?.get(option.value) && (
                      <FacetStyled>{`(${facets.get(option.value)})`}</FacetStyled>
                    )}
                  </CommandItem>
                );
              })}
            </CommandGroup>
            {selectedValues.size > 0 && (
              <>
                <CommandSeparator />
                <CommandGroup>
                  <ResetFiltersButtonStyled
                    onSelect={() => column?.setFilterValue(undefined)}
                  >
                    {CLEAN_FILTERS}
                  </ResetFiltersButtonStyled>
                </CommandGroup>
              </>
            )}
          </CommandList>
        </Command>
      </PopoverContentStyled>
    </Popover.Root>
  );
}
