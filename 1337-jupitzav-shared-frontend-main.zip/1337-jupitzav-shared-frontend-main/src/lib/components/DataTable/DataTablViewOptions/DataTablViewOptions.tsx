import { MixerHorizontalIcon } from '@radix-ui/react-icons';
import { Table } from '@tanstack/react-table';
import * as styles from './styles';
import { Button, DropdownMenu } from '@radix-ui/themes';
import { COLUMNS_VIEW, NUMBER_HIDDEN_COLUMNS } from '../DataTable.constants';
import React from 'react';
import styled from 'styled-components';

interface DataTableViewOptionsProps<TData> {
  table: Table<TData>;
  getColNameByAccessorKey: (key: string) => string;
}

const Container = styled(DropdownMenu.Root)`
  ${styles.Container}
`;

export function DataTableViewOptions<TData>({
  table,
  getColNameByAccessorKey,
}: DataTableViewOptionsProps<TData>) {
  const hiddenColumns = table
    .getAllColumns()
    .filter((column) => !column.getIsVisible()).length;

  const hiddenColumnsText = React.useMemo(() => {
    return `${NUMBER_HIDDEN_COLUMNS(hiddenColumns)}`;
  }, [hiddenColumns]);

  return (
    <Container>
      <DropdownMenu.Trigger>
        <Button variant="outline" className="button-dropdown">
          <MixerHorizontalIcon className="icon" />
          {COLUMNS_VIEW} - {hiddenColumnsText}
        </Button>
      </DropdownMenu.Trigger>
      <DropdownMenu.Content align="end" className="content">
        <DropdownMenu.Label dir="rtl">{COLUMNS_VIEW}</DropdownMenu.Label>
        <DropdownMenu.Separator />
        {table
          .getAllColumns()
          .filter(
            (column) =>
              typeof column.accessorFn !== 'undefined' && column.getCanHide(),
          )
          .map((column) => {
            return (
              <DropdownMenu.CheckboxItem
                dir="rtl"
                key={column.id}
                className="capitalize"
                checked={column.getIsVisible()}
                onCheckedChange={(value) => column.toggleVisibility(!!value)}
              >
                {getColNameByAccessorKey(column.id)}
              </DropdownMenu.CheckboxItem>
            );
          })}
      </DropdownMenu.Content>
    </Container>
  );
}
