import { css } from 'styled-components';

export const Container = css`
  .custom-class {
    margin-left: auto;
    display: none;
    height: 2rem;
    > .icon {
      margin-right: 0.5rem;
      height: 1rem;
      width: 1rem;
    }
  }

  @media (min-width: 1024px) {
    .custom-class {
      display: flex;
    }
  }

  .content {
    min-width: 150px;
  }

  .capitalize {
    text-transform: capitalize;
  }
`;
