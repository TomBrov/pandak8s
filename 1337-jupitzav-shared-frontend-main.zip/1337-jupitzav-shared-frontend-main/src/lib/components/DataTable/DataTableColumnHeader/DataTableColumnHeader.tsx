import {
  ArrowDownIcon,
  ArrowUpIcon,
  CaretSortIcon,
  EyeNoneIcon,
} from '@radix-ui/react-icons';
import { Column } from '@tanstack/react-table';
import { Button, DropdownMenu } from '@radix-ui/themes';
import { ASCENDING, DESCENDING, HIDE_COLUMN } from '../DataTable.constants';
import styled from 'styled-components';
import * as styles from './styles';

interface DataTableColumnHeaderProps<TData, TValue>
  extends React.HTMLAttributes<HTMLDivElement> {
  column: Column<TData, TValue>;
  title: string;
}

const Container = styled.div`
  ${styles.Container}
`;

const Label = styled.div`
  ${styles.Label}
`;

const DropdownMenuItem = styled(DropdownMenu.Item)`
  ${styles.DropdownMenuItem}
`;

export function DataTableColumnHeader<TData, TValue>({
  column,
  title,
  className,
}: DataTableColumnHeaderProps<TData, TValue>) {
  if (!column.getCanSort()) {
    return <Label>{title}</Label>;
  }

  return (
    <Container className={className} dir="rtl">
      <DropdownMenu.Root>
        <DropdownMenu.Trigger>
          <Button variant="ghost" className="title-button">
            <span>{title}</span>
            {column.getIsSorted() === 'desc' ? (
              <ArrowDownIcon className="icon-button" />
            ) : column.getIsSorted() === 'asc' ? (
              <ArrowUpIcon className="icon-button" />
            ) : (
              <CaretSortIcon className="icon-button" />
            )}
          </Button>
        </DropdownMenu.Trigger>
        <DropdownMenu.Content align="start">
          <DropdownMenuItem onClick={() => column.toggleSorting(false)}>
            <ArrowUpIcon className="drop-down-icon" />
            {ASCENDING}
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => column.toggleSorting(true)}>
            <ArrowDownIcon className="drop-down-icon" />
            {DESCENDING}
          </DropdownMenuItem>
          <DropdownMenu.Separator />
          <DropdownMenuItem onClick={() => column.toggleVisibility(false)}>
            <EyeNoneIcon className="drop-down-icon" />
            {HIDE_COLUMN}
          </DropdownMenuItem>
        </DropdownMenu.Content>
      </DropdownMenu.Root>
    </Container>
  );
}
