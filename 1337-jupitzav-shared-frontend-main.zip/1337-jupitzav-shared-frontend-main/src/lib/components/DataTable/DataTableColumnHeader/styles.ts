import { css } from 'styled-components';

export const Container = css`
  display: flex;
  align-items: center;
  margin-left: 0.5rem;

  .title-button {
    margin-left: 0.75rem;
    height: 2rem;
    font-size: 0.875rem;
    text-align: right;
    font-weight: 500;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .icon-button {
    margin-left: 0.5rem;
    height: 1rem;
    width: 1rem;
  }
`;

export const Label = css`
  display: flex;
  align-items: center;
  font-size: 0.875rem;
  height: 2rem;
  color: var(--accent-a11);
  font-weight: 500;
`;

export const DropdownMenuItem = css`
  .drop-down-icon {
    margin-right: 0.5rem;
    height: 0.875rem;
    width: 0.875rem;
    color: #fff;
  }
`;
