import * as React from 'react';
import { Column } from '@tanstack/react-table';

import { Popover } from '@radix-ui/themes';
import { CLEAN_FILTERS, NO_RESULTS } from './DataTable.constants';
import {
  Command,
  CommandInput,
  CommandEmpty,
  CommandList,
  CommandGroup,
  CommandItem,
  CommandSeparator,
} from './Command';
import {
  BadgeStyled,
  ButtonStyled,
  CheckIconContainer,
  CheckIconStyled,
  PlusCircledIconStyled,
  PopoverContentStyled,
  ResetFiltersButtonStyled,
  SeparatorStyled,
} from './DataTableCommon';

export type RangeValue = {
  min?: number;
  max?: number;
};

type RangeOption = {
  label: string;
  value: RangeValue;
};

interface DataTableRangeFilterProps<TData, TValue> {
  column?: Column<TData, TValue>;
  title: string;
  rangeOptions: RangeOption[];
}

export function DataTableRangeFilter<TData, TValue>({
  column,
  title,
  rangeOptions,
}: DataTableRangeFilterProps<TData, TValue>) {
  const [selectedRange, setSelectedRange] = React.useState<
    RangeOption | undefined
  >();

  const checkIfSelected = (range: RangeOption) => {
    const filterValue = column?.getFilterValue() as number[];
    if (!filterValue) {
      return false;
    }
    const isSelected =
      selectedRange &&
      selectedRange?.value?.min === range?.value?.min &&
      selectedRange?.value?.max === range?.value?.max;
    return isSelected;
  };
  const cleanFilters = () => {
    column?.setFilterValue(undefined);
    setSelectedRange(undefined);
  };

  const handleRangeSelection = (range: RangeOption) => {
    const isSelected = checkIfSelected(range);

    if (isSelected) {
      cleanFilters();
    } else {
      if (range?.value?.min === undefined || range?.value?.max === undefined) {
        return;
      }
      column?.setFilterValue([range?.value?.min, range?.value?.max]);
      setSelectedRange(range);
    }
  };

  const showLabel =
    !!selectedRange && !!column?.getFilterValue() && selectedRange?.label;

  return (
    <Popover.Root>
      <Popover.Trigger>
        <ButtonStyled variant="outline">
          <PlusCircledIconStyled />
          {title}
          {showLabel && (
            <>
              <SeparatorStyled orientation="vertical" />
              <BadgeStyled>{selectedRange?.label}</BadgeStyled>
            </>
          )}
        </ButtonStyled>
      </Popover.Trigger>
      <PopoverContentStyled align="end">
        <Command>
          <CommandInput placeholder={title} />
          <CommandList>
            <CommandEmpty>{NO_RESULTS}</CommandEmpty>
            <CommandGroup>
              {rangeOptions.map((option) => {
                const isSelected = checkIfSelected(option);
                return (
                  <CommandItem
                    key={option.value.min}
                    onSelect={() => {
                      handleRangeSelection(option);
                    }}
                  >
                    <CheckIconContainer isSelected={isSelected}>
                      <CheckIconStyled />
                    </CheckIconContainer>
                    <span dir="ltr">{option.label}</span>
                  </CommandItem>
                );
              })}
            </CommandGroup>
            {!!selectedRange && (
              <>
                <CommandSeparator />
                <CommandGroup>
                  <ResetFiltersButtonStyled
                    onSelect={() => {
                      cleanFilters();
                    }}
                  >
                    {CLEAN_FILTERS}
                  </ResetFiltersButtonStyled>
                </CommandGroup>
              </>
            )}
          </CommandList>
        </Command>
      </PopoverContentStyled>
    </Popover.Root>
  );
}
