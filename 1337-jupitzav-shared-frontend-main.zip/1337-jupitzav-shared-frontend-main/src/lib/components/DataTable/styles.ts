import { css } from 'styled-components';
import { CheckIconContainerProps } from './models';
import { whiteA, slate } from '@radix-ui/colors';

export const ContainerDataTable = css`
  border-radius: 0.375rem;

  .rt-TableRootTable {
    direction: rtl;
  }

  .table-root {
    background-color: ${({ theme }) => theme.table.tableBg};
    direction: rtl;
  }

  .table-header {
    position: sticky;
    top: 0;
    z-index: 10;
    border-color: rgb(226 232 240);
    border-width: 1px;
    & > * {
      border-color: rgb(226 232 240);
      border-top-width: 1px;
      border-bottom-width: 0px;
    }
  }

  .row-header-table {
    position: relative;
    text-align: right;
    color: black; //todo change
  }

  .column-header-table {
    position: sticky;
  }

  .table-body {
    direction: rtl;
    border-width: 1px;
    border-color: rgb(226 232 240);
    text-align: right;
    font-size: 0.875rem;
    border-color: rgb(226 232 240);
    border-width: 1px;
    line-height: 1.25rem;
    color: var(--primary-color); //todo change
    & > * {
      border-color: rgb(226 232 240);
      border-top-width: 1px;
      border-bottom-width: 0px;
    }
  }

  .row-table {
    color: rgb(241 245 249);
    opacity: 0.7;
  }

  .sticky-cell-table {
    position: sticky;
    left: 0;
  }

  .no-result-cell {
    height: 6rem;
    text-align: center;
  }

  .edit-column {
    width: 5rem;
  }
`;

export const CheckIconContainer = css<CheckIconContainerProps>`
  margin-left: 0.5rem;
  display: flex;
  height: 1rem;
  width: 1rem;
  align-items: center;
  justify-content: center;

  svg {
    visibility: ${(props) => (props.isSelected ? 'visible' : 'hidden')};
  }
`;

export const CheckIconStyled = css`
  width: 1rem;
  height: 1rem;
  color: ${whiteA};
`;

export const ButtonStyled = css`
  height: 2rem;
`;

export const PlusCircledIconStyled = css`
  margin-left: 0.5rem;
  height: 1rem;
  width: 1rem;
`;

export const SeparatorStyled = css`
  margin: 0 0.5rem;
  height: 1rem;
`;

export const BadgeStyled = css`
  border-radius: 0.125rem;
  padding: 0 0.25rem;
  font-weight: normal;
  direction: ltr;
`;

export const PopoverContentStyled = css`
  width: 200px;
  padding: 0;
`;

export const ResetFiltersButtonStyled = css`
  justify-content: center;
  text-align: center;
`;

export const SelectedValuesSizeBadge = css`
  padding-left: 0.25rem;
  padding-right: 0.25rem;
  border-radius: 0.125rem;
  font-weight: 400;

  @media (min-width: 1024px) {
    display: none;
  }
`;

export const SelectedValuesContainer = css`
  display: none;
  gap: 0.5rem;

  @media (min-width: 1024px) {
    display: flex;
  }
`;

export const OptionIconContainer = css`
  > * {
    margin-left: 0.5rem;
    width: 1rem;
    height: 1rem;
    color: ${slate.slate10};
  }
`;

export const FacetStyled = css`
  display: flex;
  margin-right: 0.25rem;
  justify-content: center;
  align-items: center;
  height: 1rem;
  font-size: 0.75rem;
  line-height: 1rem;
`;
