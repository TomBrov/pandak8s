import { flexRender, Row, RowData, Table } from '@tanstack/react-table';
import { NO_RESULTS } from './DataTable.constants';
import { Table as RadixTable } from '@radix-ui/themes';
import { DirectionProvider } from '@radix-ui/react-direction';
import { Fragment } from 'react';
import * as styles from './styles';
import styled from 'styled-components';
import clsx from 'clsx';

declare module '@tanstack/react-table' {
  interface ColumnMeta<TData extends RowData, TValue> {
    className?: string;
    isSticky?: boolean;
  }
}
interface DataTablePaginationProps<TData> {
  table: Table<TData>;
  columnsLength: number;
  CollapsedComponent?: (row: Row<TData>) => React.ReactNode;
  noResultsMessage?: string;
}

const Container = styled.div`
  ${styles.ContainerDataTable}
`;

export function DataTable<TData>({
  table,
  columnsLength,
  CollapsedComponent,
  noResultsMessage = NO_RESULTS,
}: DataTablePaginationProps<TData>) {
  return (
    <DirectionProvider dir="rtl">
      <Container>
        <RadixTable.Root className="table-root" variant="ghost" size="3">
          <RadixTable.Header className="table-header">
            {table.getHeaderGroups().map((headerGroup) => (
              <RadixTable.Row className="row-header-table" key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <RadixTable.ColumnHeaderCell
                      className={clsx(
                        header.column.columnDef.meta?.className,
                        header.column.columnDef.meta?.isSticky &&
                          'column-header-table',
                      )}
                      key={header.id}
                      colSpan={header.colSpan}
                    >
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext(),
                          )}
                    </RadixTable.ColumnHeaderCell>
                  );
                })}
              </RadixTable.Row>
            ))}
          </RadixTable.Header>
          <RadixTable.Body className="table-body">
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <Fragment key={row.id}>
                  <RadixTable.Row
                    className="row-table"
                    key={row.id}
                    data-state={row.getIsSelected() && 'selected'}
                  >
                    {row.getVisibleCells().map((cell) => (
                      <RadixTable.Cell
                        key={cell.id}
                        dir={cell.column.id === 'phoneNumber' ? 'ltr' : 'rtl'}
                        className={clsx(
                          cell.column.columnDef.meta?.className,
                          cell.column.columnDef.meta?.isSticky &&
                            'sticky-cell-table',
                        )}
                      >
                        {flexRender(
                          cell.column.columnDef.cell,
                          cell.getContext(),
                        )}
                      </RadixTable.Cell>
                    ))}
                  </RadixTable.Row>
                  {row.getIsExpanded() &&
                    CollapsedComponent &&
                    CollapsedComponent(row)}
                </Fragment>
              ))
            ) : (
              <RadixTable.Row>
                <RadixTable.Cell
                  colSpan={columnsLength}
                  className="no-result-cell"
                >
                  {noResultsMessage}
                </RadixTable.Cell>
              </RadixTable.Row>
            )}
          </RadixTable.Body>
        </RadixTable.Root>
      </Container>
    </DirectionProvider>
  );
}
