export const CLEAN_FILTERS = 'ניקוי פילטרים';
export const ROWS_PER_PAGE = 'שורות לכל עמוד';
export const COLUMNS_VIEW = 'תצוגת עמודות';
export const NUMBER_HIDDEN_COLUMNS = (number: number) => `${number} מוסתרות`;

export const ASCENDING = 'סדר עולה';
export const DESCENDING = 'סדר יורד';
export const HIDE_COLUMN = 'הסתר עמודה';
export const GOTO_FIRST_PAGE = 'מעבר לעמוד הראשון';
export const GOTO_PREVIOUS_PAGE = 'חזרה לעמוד הקודם';
export const GOTO_NEXT_PAGE = 'מעבר לעמוד הבא';
export const GOTO_LAST_PAGE = 'מעבר לעמוד האחרון';
export const NO_RESULTS = 'לא נמצאו תוצאות';
export const PAGE_OF = (page: number, totalPages: number) =>
  `עמוד ${page} מתוך ${totalPages}`;
export const ROWS_OF = (currentRows: number, totalRows: number) =>
  `${currentRows} מתוך ${totalRows} פריטים`;
