import { CheckIcon, PlusCircledIcon } from '@radix-ui/react-icons';

import { Badge, Button, Separator, Popover } from '@radix-ui/themes';
import styled from 'styled-components';
import * as styles from './styles';
import { CheckIconContainerProps } from './models';
import { CommandItem } from './Command';

export const CheckIconContainer = styled.div<CheckIconContainerProps>`
  ${styles.CheckIconContainer}
`;

export const CheckIconStyled = styled(CheckIcon)`
  ${styles.CheckIconStyled}
`;

export const ButtonStyled = styled(Button)`
  ${styles.ButtonStyled}
`;

export const PlusCircledIconStyled = styled(PlusCircledIcon)`
  ${styles.PlusCircledIconStyled}
`;

export const SeparatorStyled = styled(Separator)`
  ${styles.SeparatorStyled}
`;

export const BadgeStyled = styled(Badge)`
  ${styles.BadgeStyled}
`;

export const PopoverContentStyled = styled(Popover.Content)`
  ${styles.PopoverContentStyled}
`;

export const ResetFiltersButtonStyled = styled(CommandItem)`
  ${styles.ResetFiltersButtonStyled}
`;
