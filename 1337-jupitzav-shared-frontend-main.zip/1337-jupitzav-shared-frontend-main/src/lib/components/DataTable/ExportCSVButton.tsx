import { Button } from '@radix-ui/themes';
import { CSVLink } from 'react-csv';
import { Table } from '@tanstack/react-table';

interface ExportCSVButtonProps<TData> {
  table: Table<TData>;
  getColNameByAccessorKey: (key: string) => string;
  filename?: string;
}

export function ExportCSVButton<TData>({
  table,
  getColNameByAccessorKey,
  filename = 'my-file',
}: ExportCSVButtonProps<TData>) {
  function convertObjectsToCSV() {
    const columns = table.getAllColumns();
    const header = columns
      .filter((column) => column.getIsVisible())
      .map((column) => getColNameByAccessorKey(column.id));

    const rows = table.getRowModel().rows.map((row) => {
      const obj = row.original;
      return columns
        .filter((column) => column.getIsVisible())
        .map((column) =>
          // @ts-ignore
          column.accessorFn ? column.accessorFn(obj) : obj[column.id],
        );
    });
    rows.unshift(header);
    return rows;
  }

  const csvData = convertObjectsToCSV();

  return (
    <Button asChild>
      <CSVLink
        className="downloadbtn"
        filename={`${filename}.csv`}
        data={csvData}
      >
        ייצוא נתונים לCSV
      </CSVLink>
    </Button>
  );
}
