export interface CheckIconContainerProps {
  isSelected?: boolean;
}
