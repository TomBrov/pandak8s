import { css } from 'styled-components';

export const Container = css`
  .row-per-page-text {
    font-size: 0.875rem;
    font-weight: 500;
  }

  .trigger-btn {
    height: 2rem;
    width: 70px;
  }

  .select-contentaaa > * {
    height: fit-content;
  }

  .rows-of-container {
    font-size: 0.875rem;
    font-weight: 500;
  }
  .page-of-container {
    font-size: 0.875rem;
    font-weight: 500;
    width: 100px;
  }

  .right-button {
    display: none;
    height: 2rem;
    width: 2rem;
    padding: 0;
    > .icon-style {
      height: 1rem;
      width: 1rem;
    }
  }

  @media (min-width: 1024px) {
    .right-button {
      display: flex;
    }
  }
`;
