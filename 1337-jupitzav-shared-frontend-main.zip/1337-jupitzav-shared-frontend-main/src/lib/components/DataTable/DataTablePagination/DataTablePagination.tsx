import {
  ChevronLeftIcon,
  ChevronRightIcon,
  DoubleArrowLeftIcon,
  DoubleArrowRightIcon,
} from '@radix-ui/react-icons';
import { Table } from '@tanstack/react-table';
import { Button, Flex, Select } from '@radix-ui/themes';
import * as styles from './styles';
import { PAGE_OF, ROWS_OF, ROWS_PER_PAGE } from '../DataTable.constants';
import styled from 'styled-components';

interface DataTablePaginationProps<TData> {
  table: Table<TData>;
}

const Container = styled(Flex)`
  ${styles.Container}
`;

const SelectContent = styled(Select.Content)`
  height: fit-content;
`;

export function DataTablePagination<TData>({
  table,
}: DataTablePaginationProps<TData>) {
  const filteredRowsLength = table.getRowModel().rows.length;
  const totalRowsLength = table.getCoreRowModel().rows.length;
  return (
    <Container
      display={'flex'}
      align={'center'}
      justify={'between'}
      px={'2'}
      dir="rtl"
    >
      <Flex align={'center'} gap={'6'} style={{ flex: '1 1 0%' }}>
        <Flex align={'center'} gap={'2'} style={{ flex: '1 1 0%' }}>
          <p className="row-per-page-text">{ROWS_PER_PAGE}</p>
          <Select.Root
            dir="rtl"
            value={`${table.getState().pagination.pageSize}`}
            onValueChange={(value) => {
              table.setPageSize(Number(value));
            }}
          >
            <Select.Trigger className="trigger-btn" />
            <SelectContent side="top">
              {[10, 20, 30, 40, 50].map((pageSize) => (
                <Select.Item dir="rtl" key={pageSize} value={`${pageSize}`}>
                  {pageSize}
                </Select.Item>
              ))}
            </SelectContent>
          </Select.Root>
        </Flex>
        <Flex className="rows-of-container" align={'center'} justify={'center'}>
          {ROWS_OF(filteredRowsLength, totalRowsLength)}
        </Flex>
        <Flex className="page-of-container" align={'center'} justify={'center'}>
          {PAGE_OF(
            table.getState().pagination.pageIndex + 1,
            table.getPageCount(),
          )}
        </Flex>
        <Flex align={'center'} gap={'2'}>
          <Button
            variant="outline"
            className="right-button"
            onClick={() => table.setPageIndex(0)}
            disabled={!table.getCanPreviousPage()}
          >
            <DoubleArrowRightIcon className="icon-style" />
          </Button>
          <Button
            variant="outline"
            className="right-button"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
          >
            <ChevronRightIcon className="icon-style" />
          </Button>
          <Button
            variant="outline"
            className="right-button"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
          >
            <ChevronLeftIcon className="icon-style" />
          </Button>
          <Button
            variant="outline"
            className="right-button"
            onClick={() => table.setPageIndex(table.getPageCount() - 1)}
            disabled={!table.getCanNextPage()}
          >
            <DoubleArrowLeftIcon className="icon-style" />
          </Button>
        </Flex>
      </Flex>
    </Container>
  );
}
