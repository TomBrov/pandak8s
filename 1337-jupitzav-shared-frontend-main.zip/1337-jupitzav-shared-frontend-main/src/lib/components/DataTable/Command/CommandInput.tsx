import { Command as CommandPrimitive } from 'cmdk';
import styled from 'styled-components';
import * as styles from './styles';
import { MagnifyingGlassIcon } from '@radix-ui/react-icons';
import React from 'react';

const CommandPrimitiveInputContainer = styled.div`
  ${styles.CommandPrimitiveInputContainer}
`;

export const CommandInput = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Input>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Input>
>(({ className, ...props }, ref) => (
  <CommandPrimitiveInputContainer cmdk-input-wrapper="">
    <MagnifyingGlassIcon className="MagnifyingGlassIcon" />
    <CommandPrimitive.Input
      ref={ref}
      className={`CommandPrimitiveInput ${className}`}
      {...props}
    />
  </CommandPrimitiveInputContainer>
));

CommandInput.displayName = CommandPrimitive.Input.displayName;
