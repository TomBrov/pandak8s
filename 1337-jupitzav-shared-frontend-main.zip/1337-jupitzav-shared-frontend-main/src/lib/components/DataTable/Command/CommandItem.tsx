import { Command as CommandPrimitive } from 'cmdk';
import React from 'react';
import styled from 'styled-components';
import * as styles from './styles';

const CommandPrimitiveItemStyled = styled(CommandPrimitive.Item)`
  ${styles.CommandItem}
`;

export const CommandItem = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Item>
>(({ className, ...props }, ref) => (
  <CommandPrimitiveItemStyled ref={ref} className={className} {...props} />
));

CommandItem.displayName = CommandPrimitive.Item.displayName;
