import React from 'react';
import { Command as CommandPrimitive } from 'cmdk';
import styled from 'styled-components';
import * as styles from './styles';

const CommandPrimitiveSeparatorStyled = styled(CommandPrimitive.Separator)`
  ${styles.CommandSeparator}
`;

export const CommandSeparator = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <CommandPrimitiveSeparatorStyled ref={ref} className={className} {...props} />
));

CommandSeparator.displayName = CommandPrimitive.Separator.displayName;
