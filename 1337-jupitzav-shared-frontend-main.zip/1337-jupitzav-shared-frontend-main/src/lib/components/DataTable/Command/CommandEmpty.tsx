import React from 'react';
import { Command as CommandPrimitive } from 'cmdk';
import * as styles from './styles';
import styled from 'styled-components';

const CommandPrimitiveEmptyStyled = styled(CommandPrimitive.Empty)`
  ${styles.CommandEmpty}
`;

export const CommandEmpty = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Empty>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Empty>
>((props, ref) => <CommandPrimitiveEmptyStyled ref={ref} {...props} />);

CommandEmpty.displayName = CommandPrimitive.Empty.displayName;
