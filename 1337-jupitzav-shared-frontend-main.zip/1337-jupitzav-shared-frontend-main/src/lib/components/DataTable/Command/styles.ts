import { css } from 'styled-components';
import { whiteA } from '@radix-ui/colors';

export const Command = css`
  display: flex;
  overflow: hidden;
  flex-direction: column;
  border-radius: 0.375rem;
  width: 100%;
  height: 100%;
  color: #ffffff;
`;

export const CommandPrimitiveInputContainer = css`
  display: flex;
  padding-left: 0.75rem;
  padding-right: 0.75rem;
  align-items: center;
  border-bottom-width: 1px;

  .MagnifyingGlassIcon {
    margin-right: 0.5rem;
    shrink: 0;
    width: 1rem;
    height: 1rem;
    opacity: 0.5;
  }

  .CommandPrimitiveInput {
    display: flex;
    padding-top: 0.25rem;
    padding-bottom: 0.25rem;
    border-radius: 0.375rem;
    outline-style: none;
    width: 100%;
    font-size: 0.875rem;
    line-height: 1.25rem;
    background-color: transparent;
  }
`;

export const CommandInputIcon = css`
  margin-right: 0.5rem;
  shrink: 0;
  width: 1rem;
  height: 1rem;
  opacity: 0.5;
`;

export const CommandEmpty = css`
  padding-top: 1.5rem;
  padding-bottom: 1.5rem;
  font-size: 0.875rem;
  line-height: 1.25rem;
  text-align: center;
  color: ${whiteA.whiteA12};
`;

export const CommandSeparator = css`
  margin-left: -0.25rem;
  margin-right: -0.25rem;
  height: 1px;
  background-color: ${whiteA.whiteA3};
`;

export const CommandGroup = css`
  overflow: hidden;
  padding: 0.25rem;
  color: ${whiteA.whiteA12};

  &[cmdk-group-heading] {
    padding-left: 0.5rem;
    padding-right: 0.5rem;
    padding-top: 0.375rem;
    padding-bottom: 0.375rem;
    font-size: 0.75rem;
    font-weight: 500;
    color: ${whiteA.whiteA12};
  }
`;

export const CommandItem = css`
  position: relative;
  display: flex;
  cursor: default;
  user-select: none;
  align-items: center;
  border-radius: 0.125rem;
  padding-left: 0.5rem;
  padding-right: 0.5rem;
  padding-top: 0.375rem;
  padding-bottom: 0.375rem;
  font-size: 0.875rem;
  outline: none;

  &[aria-selected='true'] {
    background-color: #7958fe;
    background-opacity: 0.3;
  }

  &[data-disabled='true'] {
    pointer-events: none;
    opacity: 0.5;
  }
`;
