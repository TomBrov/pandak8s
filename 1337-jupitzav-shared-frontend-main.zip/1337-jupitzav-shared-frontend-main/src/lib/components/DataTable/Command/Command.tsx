import { Command as CommandPrimitive } from 'cmdk';
import React from 'react';
import styled from 'styled-components';
import * as styles from './styles';

const CommandPrimitiveStyled = styled(CommandPrimitive)`
  ${styles.Command}
`;

const Command = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive>
>(({ className, ...props }, ref) => (
  <CommandPrimitiveStyled ref={ref} className={className} {...props} />
));

Command.displayName = CommandPrimitive.displayName;
