import React from 'react';
import { Command as CommandPrimitive } from 'cmdk';
import styled from 'styled-components';
import * as styles from './styles';

const CommandPrimitiveGroupStyled = styled(CommandPrimitive.Group)`
  ${styles.CommandGroup}
`;

export const CommandGroup = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Group>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Group>
>(({ className, ...props }, ref) => (
  <CommandPrimitiveGroupStyled ref={ref} className={className} {...props} />
));

CommandGroup.displayName = CommandPrimitive.Group.displayName;
