import { ScrollArea } from '@radix-ui/themes';
import { Command as CommandPrimitive } from 'cmdk';
import React from 'react';
import styled from 'styled-components';

const CommandPrimitiveStyled = styled(CommandPrimitive.List)`
  max-height: 300px;
`;

const ScrollAreaStyled = styled(ScrollArea)`
  overflow: hidden;
`;

export const CommandList = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.List>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.List>
>(({ className, ...props }, ref) => (
  <ScrollAreaStyled scrollbars="vertical">
    <div dir="rtl">
      <CommandPrimitiveStyled ref={ref} className={className} {...props} />
    </div>
  </ScrollAreaStyled>
));

CommandList.displayName = CommandPrimitive.List.displayName;
