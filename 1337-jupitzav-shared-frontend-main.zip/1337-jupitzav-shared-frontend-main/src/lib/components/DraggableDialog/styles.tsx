import styled from 'styled-components';
import { AlertDialog } from '@radix-ui/themes';

export type StyledAlertDialogContentProps = {
  customWidth?: string;
  customHeight?: string;
  bigDialog?: boolean;
  isDisabled?: boolean;
  withBackdrop?: boolean;
};

export const StyledAlertDialogContent = styled(
  AlertDialog.Content,
)<StyledAlertDialogContentProps>`
  max-width: ${({ customWidth, bigDialog }) =>
    customWidth ? customWidth : bigDialog ? 700 : 450};
  height: ${({ customHeight }) => (customHeight ? customHeight : 'unset')};
  cursor: ${({ isDisabled }) => (isDisabled ? 'auto' : 'move')};
  flex-direction: 'column';
  display: 'flex';
  --color-overlay: 'transparent' !important;

  > .close-button {
    align-items: center;
  }

  > .title {
    text-align: center;
  }

  > .description-container {
    display: flex;
    text-align: center;
    font-size: 0.75rem;
    gap: 0.5rem;
    > .description-svg {
      width: 1rem;
      height: 1rem;
    }
    > .description {
      color: rgb(100 116 139);
    }
  }

  > .children-container {
    flex: 1 1 0;
    display: flex;
    flex-direction: 'column';
  }
`;
