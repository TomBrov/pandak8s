import { AlertDialog, Box, Button, Flex } from '@radix-ui/themes';
import Draggable from 'react-draggable';
import React, { useRef, ComponentProps } from 'react';
import { Cross1Icon } from '@radix-ui/react-icons';
import { StyledAlertDialogContent } from './styles';

type AlertDialogRootProps = ComponentProps<typeof AlertDialog.Root>;

export type DraggableDialogProps = {
  openDialog: boolean;
  setOpenDialog?: AlertDialogRootProps['onOpenChange'];
  children: React.ReactNode;
  triggerButton?: React.ReactNode;
  title?: string;
  description?: string;
  customWidth?: string;
  customHeight?: string;
  bigDialog?: boolean;
  isDisabled?: boolean;
  showCloseButton?: boolean;
};

// TODO: we need to work on the styles of this component and make sure it's relevant to the design of both apps
export const DraggableDialog = ({
  openDialog,
  setOpenDialog,
  children,
  title,
  description,
  triggerButton,
  isDisabled = false,
  customWidth,
  customHeight,
  bigDialog = false,
  showCloseButton = true,
}: DraggableDialogProps) => {
  const draggableRef = useRef(null);

  return (
    <AlertDialog.Root open={openDialog} onOpenChange={setOpenDialog}>
      {triggerButton && (
        <AlertDialog.Trigger className="cursor-pointer">
          {triggerButton}
        </AlertDialog.Trigger>
      )}
      {openDialog && (
        <Draggable disabled={isDisabled} nodeRef={draggableRef}>
          <StyledAlertDialogContent
            ref={draggableRef}
            customWidth={customWidth}
            customHeight={customHeight}
            bigDialog={bigDialog}
            isDisabled={isDisabled}
          >
            <AlertDialog.Cancel>
              {showCloseButton && (
                <Button
                  variant="soft"
                  className="close-button cursor-pointer doNotDragOmClick"
                >
                  <Cross1Icon />
                </Button>
              )}
            </AlertDialog.Cancel>
            {title && (
              <AlertDialog.Title className="title" size="6">
                {title}
              </AlertDialog.Title>
            )}
            {description && (
              <Flex className="description-container" justify="center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="description-svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z"
                  />
                </svg>
                <span className="description">{description}</span>
              </Flex>
            )}
            <Box className="children-container">{children}</Box>
          </StyledAlertDialogContent>
        </Draggable>
      )}
    </AlertDialog.Root>
  );
};
