import { SetStateAction } from 'react';
import { Button, Flex, Text } from '@radix-ui/themes';
import { SubmitHandler, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, InputField } from '../Form';
import * as zod from 'zod';
import { Popover } from '@radix-ui/themes';
import React from 'react';
import { CANCEL_BUTTON } from '../../constants';

const createGeneralPopoverSchema = zod.object({
  name: zod.string().min(1, {
    message: 'שדה חובה',
  }),
});

export type CreateSchemaType = zod.infer<typeof createGeneralPopoverSchema>;

export interface GeneralPopoverProps {
  onFinish: (data: CreateSchemaType) => void;
  entityName: string;
  placeHolder: string;
  dialogTitle: string;
  buttonTitle: string;
  setIsFormOpen: React.Dispatch<SetStateAction<boolean>>;
  defaultValue?: string;
}

export const CreateGeneralPopover = ({
  onFinish,
  entityName,
  placeHolder,
  dialogTitle,
  buttonTitle,
  setIsFormOpen,
  defaultValue = '',
}: GeneralPopoverProps) => {
  const form = useForm<CreateSchemaType>({
    mode: 'onSubmit',
    reValidateMode: 'onChange',
    resolver: zodResolver(createGeneralPopoverSchema),
    defaultValues: {
      name: defaultValue,
    },
  });

  const onSubmit: SubmitHandler<CreateSchemaType> = async (data) => {
    try {
      await onFinish(data);
      setIsFormOpen(false);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <Flex gap="5" direction="column">
            <Text className="pink-title" size="2">
              {dialogTitle}
            </Text>
            <InputField
              autoFocus
              required
              control={form.control}
              name="name"
              label={entityName}
              placeholder={placeHolder}
            />
            <Flex gap="3" justify="end">
              <Popover.Close>
                <Button
                  onClick={() => setIsFormOpen(false)}
                  size="1"
                  variant="soft"
                  color="gray"
                >
                  {CANCEL_BUTTON}
                </Button>
              </Popover.Close>
              <Button size="1" type="submit">
                {buttonTitle}
              </Button>
            </Flex>
          </Flex>
        </form>
      </Form>
    </div>
  );
};
