import * as React from 'react';
import { Dialog } from '@radix-ui/themes';
import { Cross2Icon } from '@radix-ui/react-icons';
import { Flex, IconButton } from '@radix-ui/themes';
import styled from 'styled-components';
import * as styles from './styles';

const Sheet = Dialog.Root;

const SheetTrigger = Dialog.Trigger;

const SheetClose = Dialog.Close;

const SheetContendContainer = styled(Dialog.Content)<{
  side: 'left' | 'right' | 'bottom' | 'top';
}>`
  ${styles.SheetContendContainer}
  ${({ side }) => {
    switch (side) {
      case 'bottom':
        return styles.SheetContendBottomStyle;
      case 'left':
        return styles.SheetContendLeftStyle;
      case 'right':
        return styles.SheetContendRightStyle;
      case 'top':
        return styles.SheetContendTopStyle;
    }
  }}
`;
interface SheetContentProps
  extends React.ComponentPropsWithoutRef<typeof Dialog.Content> {
  side: 'left' | 'right' | 'bottom' | 'top';
}

const SheetContent = React.forwardRef<
  React.ElementRef<typeof Dialog.Content>,
  SheetContentProps
>(({ side = 'right', className, children, ...props }, ref) => (
  <SheetContendContainer side={side} ref={ref} className={className} {...props}>
    <Flex direction="column">{children}</Flex>
    <Dialog.Close className="dialog-close">
      <IconButton variant="solid" className="delete-button">
        <Cross2Icon className="delete-icon" />
        <span className="delete-button-text">Close</span>
      </IconButton>
    </Dialog.Close>
  </SheetContendContainer>
));
SheetContent.displayName = Dialog.Content.displayName;

const SheetHeaderContainer = styled(Flex)`
  ${styles.SheetHeaderContainer}
`;

const SheetHeader = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <SheetHeaderContainer direction={'column'} className={className} {...props} />
);
SheetHeader.displayName = 'SheetHeader';

const SheetFooterContainer = styled(Flex)`
  ${styles.SheetFooterContainer}
`;
const SheetFooter = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <SheetFooterContainer
    direction={'column-reverse'}
    className={className}
    {...props}
  />
);
SheetFooter.displayName = 'SheetFooter';

const DialogTitle = styled(Dialog.Title)`
  ${styles.DialogTitle}
`;
const SheetTitle = React.forwardRef<
  React.ElementRef<typeof Dialog.Title>,
  React.ComponentPropsWithoutRef<typeof Dialog.Title>
>(({ className, ...props }, ref) => (
  <DialogTitle ref={ref} className={className} {...props} />
)); // add tailwind text-foreground class
SheetTitle.displayName = Dialog.Title.displayName;

const DialogDescription = styled(Dialog.Description)`
  ${styles.DialogDescription}
`;

const SheetDescription = React.forwardRef<
  React.ElementRef<typeof Dialog.Description>,
  React.ComponentPropsWithoutRef<typeof Dialog.Description>
>(({ className, ...props }, ref) => (
  <DialogDescription ref={ref} className={className} {...props} /> // add tailwind text-muted-foreground class
));
SheetDescription.displayName = Dialog.Description.displayName;

export {
  Sheet,
  SheetTrigger,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetFooter,
  SheetTitle,
  SheetDescription,
};
