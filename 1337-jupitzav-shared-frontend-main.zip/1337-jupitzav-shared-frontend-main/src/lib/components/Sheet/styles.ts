import { css } from 'styled-components';

export const SheetContendTopStyle = css`
  @keyframes slide-in-from-top {
    0% {
      transform: translateX(calc(var(--dialog-hight) * -1));
    }
    100% {
      transform: translateX(0px);
    }
  }

  @keyframes slide-out-to-top {
    0% {
      transform: translateX(0px);
    }
    100% {
      transform: translateX(calc(var(--dialog-hight) * -1));
    }
  }

  border-bottom-width: 1px;
  border-bottom-style: solid;
  border-bottom-color: rgb(148 163 184);

  left: 0px;
  right: 0px;
  bottom: 0px;
  top: 0px;
  border-bottom-width: 1px;

  &[data-state='open'] {
    animation-name: slide-in-from-top;
    //slide-in-from-top
  }
  &[data-state='closed'] {
    animation-name: slide-out-to-top;
    //slide-out-to-top
  }
`;

export const SheetContendBottomStyle = css`
  @keyframes slide-in-from-bottom {
    0% {
      transform: translateX(calc(100vh + var(--dialog-hight)));
    }
    100% {
      transform: translateX(100vh);
    }
  }

  @keyframes slide-out-to-bottom {
    0% {
      transform: translateX(100vh);
    }
    100% {
      transform: translateX(calc(100vh + var(--dialog-hight)));
    }
  }

  border-top-width: 1px;
  border-top-style: solid;
  border-top-color: rgb(148 163 184);
  left: 0px;
  right: 0px;
  bottom: 0px;
  border-top-width: 1px;
  &[data-state='open'] {
    animation-name: slide-in-from-bottom;
  }
  &[data-state='closed'] {
    animation-name: slide-out-to-bottom;
  }
`;

export const SheetContendLeftStyle = css`
  @keyframes slide-in-from-left {
    0% {
      transform: translateX(calc(var(--dialog-width) * -1));
    }
    100% {
      transform: translateX(0px);
    }
  }

  @keyframes slide-out-to-left {
    0% {
      transform: translateX(0px);
    }
    100% {
      transform: translateX(calc(var(--dialog-width) * -1));
    }
  }

  border-right-width: 1px;
  border-right-style: solid;
  border-right-color: rgb(148 163 184);

  top: 0px;
  bottom: 0px;
  left: 0px;
  height: 100%;
  width: 75%;
  border-right-width: 1px;
  @media (min-width: 640px) {
    max-width: 24rem;
  }
  &[data-state='open'] {
    animation-name: slide-in-from-left;
  }
  &[data-state='closed'] {
    animation-name: slide-out-to-left;
  }
`;

export const SheetContendRightStyle = css`
  @keyframes slide-in-from-right {
    0% {
      transform: translateX(calc(100vw + var(--dialog-width)));
    }
    100% {
      transform: translateX(100vw);
    }
  }

  @keyframes slide-out-to-right {
    0% {
      transform: translateX(100vw);
    }
    100% {
      transform: translateX(calc(100vw + var(--dialog-width)));
    }
  }

  border-left-width: 1px;
  border-left-style: solid;
  border-left-color: rgb(148 163 184);

  top: 0px;
  bottom: 0px;
  right: 0px;
  height: 100%;
  width: 75%;
  border-left-width: 1px;
  @media (min-width: 640px) {
    max-width: 24rem;
  }

  &[data-state='open'] {
    animation-name: slide-in-from-right;
  }
  &[data-state='closed'] {
    animation-name: slide-out-to-right;
  }
`;

export const SheetContendContainer = css`
  --dialog-width: 600px;
  display: flex;
  flex-direction: column;
  max-height: none;
  border-radius: 0px;
  position: fixed;
  z-index: 50;
  background-color: rgb(51 65 85);
  gap: 1rem;
  padding: 1.5rem;
  box-shadow:
    0 10px 15px -3px rgba(0, 0, 0, 0.1),
    0 4px 6px -2px rgba(0, 0, 0, 0.05);

  transition-property: all;

  &[data-state='open'] {
    transition-duration: 10s;
    animation-duration: 1s;
  }
  &[data-state='closed'] {
    transition-duration: 10s;
    animation-duration: 1s;
  }

  .dialog-close {
    cursor: pointer;
    position: absolute;
    left: 1rem;
    left: 1rem;
    border-radius: 0.125rem;
    opacity: 0.7;
    transition-property: opacity;
    &:hover {
      opacity: 1;
    }
    &:focus {
      outline: 0;
      box-shadow: var(--tw-ring-inset) 0 0 0
        calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
    }
    &:disabled {
      pointer-events: none;
    }
  }
  .delete-button {
    cursor: pointer;
  }

  .delete-icon {
    height: 1rem;
    width: 1rem;
    color: #fff;
  }

  .delete-button-text {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border-width: 0;
  }
  max-width: none !important;
  width: 600px;
  @media (min-width: 640px) {
    width: 540px;
  }
`;

export const DialogTitle = css`
  font-size: 1.25rem;
  font-weight: 600;
  text-align: right;
`;

export const DialogDescription = css`
  font-size: 0.875rem;
  text-align: right;
`;

export const SheetHeaderContainer = css`
  text-align: center;
  @media (min-width: 640px) {
    text-align: left;
  }

  & > * {
    margin-top: 0.5rem;
  }
`;

export const SheetFooterContainer = css`
  @media (min-width: 640px) {
    flex-direction: row;
    justify-content: end;
    & > * {
      margin-left: 0.5rem;
    }
  }
`;
