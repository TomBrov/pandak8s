export interface Option {
  value: string;
  label: string;
}

export interface MultiSelectProps {
  options: Option[];
  value: string[];
  onChange: (selectedValues: string[]) => void;
  placeholder?: string;
  startDecorator?: React.ReactNode;
}
