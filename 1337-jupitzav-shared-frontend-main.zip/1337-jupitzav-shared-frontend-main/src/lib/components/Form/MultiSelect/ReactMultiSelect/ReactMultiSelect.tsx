import styled from 'styled-components';
import * as styles from './styles.ts';
import React from 'react';
import Select, { components } from 'react-select';
import { MultiSelectProps } from './models';
import { styledOption, styledMenuPortal, styledMenu } from './styles.ts';

const StyledSelect = styled(Select)`
  ${styles.Container}
`;

export const ReactMultiSelect: React.FC<MultiSelectProps> = ({
  options,
  value,
  onChange,
  placeholder,
  startDecorator,
}) => {
  return (
    <StyledSelect
      className="react-select-container"
      classNamePrefix="react-select"
      isMulti
      options={options}
      placeholder={placeholder}
      menuPlacement="auto"
      menuPortalTarget={document.body}
      styles={{
        menuPortal: (baseStyles) => ({
          ...baseStyles,
          ...styledMenuPortal,
        }),
        menu: (baseStyles) => ({
          ...baseStyles,
          ...styledMenu,
        }),
        option: (baseStyles) => ({
          ...baseStyles,
          ...styledOption,
        }),
      }}
      onChange={(selectedOptions: any) => {
        const selectedValues = selectedOptions.map(
          (option: any) => option?.value,
        );
        onChange(selectedValues);
      }}
      value={options.filter((option) => value?.includes(option.value))}
      components={{
        Control: ({ children, ...rest }) => (
          <components.Control {...rest}>
            <span className="required-span">{startDecorator}</span>
            {children}
          </components.Control>
        ),
      }}
    />
  );
};
