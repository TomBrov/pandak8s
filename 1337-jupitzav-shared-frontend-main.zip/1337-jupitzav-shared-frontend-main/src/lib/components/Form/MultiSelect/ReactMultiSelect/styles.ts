import { css } from 'styled-components';

export const Container = css`
  .required-span {
    padding-left: 0.25rem;
  }

  > .react-select__control {
    width: 100%;
    background-color: rgb(15, 23, 42);
    color: #fff;
    border: 1px solid var(--gray-12);
    border-radius: max(var(--radius-3), var(--radius-full));

    &:hover {
      border-color: var(--gray-12);
    }

    > .react-select__value-container > .react-select__multi-value {
      background-color: rgb(15, 23, 42);

      > .react-select__multi-value__label {
        color: #fff;
      }
    }
  }
`;

export const styledOption = {
  color: '#fff',
  cursor: 'pointer',
  backgroundColor: 'rgb(15, 23, 42)',
  '&:hover': {
    backgroundColor: 'rgb(28, 46, 88)',
  },
};

export const styledMenuPortal: { zIndex: number; pointerEvents: 'auto' } = {
  zIndex: 100000,
  pointerEvents: 'auto',
};

export const styledMenu = {
  backgroundColor: 'rgb(15, 23, 42)',
  border: '1px solid var(--gray-12)',
  borderColor: 'var(--gray-12)',
};
