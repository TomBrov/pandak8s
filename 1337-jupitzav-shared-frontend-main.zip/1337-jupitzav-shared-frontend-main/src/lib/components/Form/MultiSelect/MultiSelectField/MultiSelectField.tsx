import styled from 'styled-components';
import * as styles from './styles.ts';
import { MultiSelectFieldProps } from './models';
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '../../Form/Form.tsx';
import { ReactMultiSelect } from '../ReactMultiSelect';

const Container = styled.div`
  ${styles.Container}
`;

export const MultiSelectField = ({
  options,
  control,
  name,
  label,
  placeholder,
  required,
}: MultiSelectFieldProps) => {
  return (
    <Container>
      <FormField
        control={control}
        name={name}
        render={({ field }) => (
          <FormItem>
            <FormLabel>
              {label} {required && <span className="requierd-span">*</span>}
            </FormLabel>
            <FormControl>
              <ReactMultiSelect
                options={options}
                placeholder={placeholder}
                value={field.value as string[]}
                onChange={(selectedValues) => {
                  field.onChange(selectedValues);
                }}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
    </Container>
  );
};
