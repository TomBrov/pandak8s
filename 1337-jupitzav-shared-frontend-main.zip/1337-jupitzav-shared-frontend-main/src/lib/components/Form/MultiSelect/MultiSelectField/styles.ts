import { css } from 'styled-components';

export const Container = css`
  .requierd-span {
    color: rgb(248 113 113);
  }
`;
