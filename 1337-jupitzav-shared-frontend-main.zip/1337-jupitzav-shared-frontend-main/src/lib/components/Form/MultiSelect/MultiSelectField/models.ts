type Option = {
  value: string;
  label: string;
};

export type MultiSelectFieldProps = {
  control: any;
  name: string;
  label: string;
  placeholder: string;
  options: Option[];
  required?: boolean;
};
