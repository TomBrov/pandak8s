import { css } from 'styled-components';
import type { FormMessageProps } from './types';

export const FormItem = css`
  position: relative;
  font-weight: 500;
  font-size: 0.875rem;
`;

export const FormMessage = css<FormMessageProps>`
  position: absolute;
  margin-right: 4px;
  font-size: 13px;
  line-height: 1.8;

  ${({ isTooltip, theme }) =>
    isTooltip &&
    `
    top: 0;
    left: 50%;
    padding: 5px;
    max-width: 100%;
    width: max-content;
    border-radius: 5px;
    transform: translate(-50%, -100%);
    background: ${theme.colors.redDark.red8};

    &:before {
      content: "";
      position: absolute;
      left: 50%;
      transform: translate(-50%, 5px) rotate(45deg);
      background-color: ${theme.colors.redDark.red8};
      width: 10px;
      height: 10px;
      bottom: 0;
    }
  `}
`;

export const FormDescription = css`
  font-size: 0.875rem;
`;

export const ItemContext = css`
  font-size: 0.875rem;
`;
