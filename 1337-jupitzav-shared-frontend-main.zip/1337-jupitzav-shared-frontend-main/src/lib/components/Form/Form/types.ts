import type {
  FieldPath,
  FieldValues,
  FormProviderProps,
} from 'react-hook-form';

export type FormItemContextValue = {
  id: string;
};

export type FormContextValue = {
  isValidationMessagesTooltip?: boolean;
};

export type FormWithContextProviderProps<T extends FieldValues> =
  FormProviderProps<T> & FormContextValue;

export type FormFieldContextValue<
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>,
> = {
  name: TName;
};

export type FormMessageProps = {
  isTooltip?: boolean;
};
