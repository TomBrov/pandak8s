import { Flex, Text, Grid, Separator } from '@radix-ui/themes';

export const FormSection = ({
  children,
  title,
  columns = '2',
}: {
  children: React.ReactNode;
  title: string;
  columns?: string;
}) => (
  <>
    <Flex direction="column" gap="3">
      <Text size="4" weight="bold">
        {title}
      </Text>
      <Grid columns={columns} gap="5" width="auto">
        {children}
      </Grid>
    </Flex>
    <Separator my="3" size="4" />
  </>
);
