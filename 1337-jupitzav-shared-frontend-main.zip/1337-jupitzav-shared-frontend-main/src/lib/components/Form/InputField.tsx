import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from './Form/Form';
import { TextField } from '@radix-ui/themes';

export type InputFieldProps = {
  control: any;
  name: string;
  label?: string;
  dir?: string;
  placeholder: string;
  required?: boolean;
  type?: React.HTMLInputTypeAttribute;
  autoFocus?: boolean;
  className?: string;
};

export const InputField = ({
  control,
  name,
  label,
  placeholder,
  required,
  dir,
  type = 'text',
  autoFocus = false,
  className,
}: InputFieldProps) => {
  const inputStyling = `block font-nato w-full py-2 border shadow-sm focus:ring-sky-100 border-sky-100 sm:text-md bg-slate-900 ${
    dir === 'ltr' ? 'text-right pr-2' : ' text-start'
  }`;

  // TODO: Radix UI TextField.Input throw warning with controller
  return (
    <FormField
      control={control}
      name={name}
      render={({ field }) => (
        <FormItem className={className}>
          {label && (
            <FormLabel>
              {label} {required && <span style={{ color: '#fc8181' }}>*</span>}
            </FormLabel>
          )}
          <FormControl>
            <TextField.Input
              size="3"
              dir={dir}
              placeholder={placeholder}
              className={inputStyling}
              type={type}
              autoFocus={autoFocus}
              {...field}
            />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};
