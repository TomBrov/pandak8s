import { FormControl, FormField, FormItem } from './Form';
import { Switch, Text, Flex } from '@radix-ui/themes';

export type SwitchFieldProps = {
  control: any;
  name: string;
  label: string;
};

export const SwitchField = ({ control, name, label }: SwitchFieldProps) => {
  return (
    <FormField
      control={control}
      name={name}
      render={({ field }) => (
        <FormItem>
          <Text as="label" size="2">
            <Flex gap="2">
              <FormControl>
                <Switch
                  dir="ltr"
                  checked={field.value}
                  onCheckedChange={field.onChange}
                  aria-readonly
                />
              </FormControl>
              {label}
            </Flex>
          </Text>
        </FormItem>
      )}
    />
  );
};
