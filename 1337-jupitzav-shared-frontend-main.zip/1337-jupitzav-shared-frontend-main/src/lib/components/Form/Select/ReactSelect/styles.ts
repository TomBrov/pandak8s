import { css } from 'styled-components';

export const optionWrapper = css`
  display: flex;
  justify-content: space-between;
`;
export const optionStyle = {
  color: '#fff',
  cursor: 'pointer',
  backgroundColor: 'rgb(15, 23, 42)',
  '&:hover': {
    backgroundColor: 'rgb(28, 46, 88)',
  },
};

export const menuStyle = {
  backgroundColor: 'rgb(15, 23, 42)',
  border: '1px solid var(--gray-12)',
  borderColor: 'var(--gray-12)',
};

export const singleValueStyle = {
  color: '#fff',
};

export const menuPortalStyle: { zIndex: number; pointerEvents: 'auto' } = {
  zIndex: 100000,
  pointerEvents: 'auto',
};

export const ControlSpan = css`
  padding-left: 0.125rem;
`;
