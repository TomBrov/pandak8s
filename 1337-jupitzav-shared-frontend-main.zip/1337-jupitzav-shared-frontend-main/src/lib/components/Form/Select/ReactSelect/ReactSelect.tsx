import React from 'react';
import Select, { components } from 'react-select';
import { ReactSelectProps } from './models';
import styled from 'styled-components';
import * as styles from './styles';

const OptionWrapper = styled.div`
  ${styles.optionWrapper}
`;

const ControlSpan = styled.span`
  ${styles.ControlSpan}
`;
export const ReactSelect: React.FC<ReactSelectProps> = ({
  options,
  value,
  onChange,
  placeholder,
  startDecorator,
  actionButton,
  isDisabled,
  isClearable,
  onClear,
}) => {
  return (
    <Select
      isDisabled={isDisabled ?? false}
      options={options}
      placeholder={placeholder}
      menuPlacement="auto"
      isClearable={isClearable}
      menuPortalTarget={document.body}
      styles={{
        menuPortal: (baseStyles) => ({
          ...baseStyles,
          ...styles.menuPortalStyle,
        }),
        control: (baseStyles) => ({
          ...baseStyles,
        }),
        singleValue: (baseStyles) => ({
          ...baseStyles,
          ...styles.singleValueStyle,
        }),
        menu: (baseStyles) => ({
          ...baseStyles,
          ...styles.menuStyle,
        }),
        option: (baseStyles) => ({
          ...baseStyles,
          ...styles.optionStyle,
        }),
      }}
      onChange={(selectedOption, actionMeta) => {
        if (actionMeta.action === 'clear') {
          onClear?.();
        } else {
          const selectedValue = selectedOption?.value || null;
          onChange(selectedValue);
        }
      }}
      value={options.find((option) => option.value === value) || null}
      components={{
        Control: ({ children, ...rest }) => (
          <components.Control {...rest}>
            <ControlSpan>{startDecorator}</ControlSpan> {children}
          </components.Control>
        ),
        Option: ({ children, ...rest }) => (
          <OptionWrapper>
            <components.Option {...rest}>{rest.data.label}</components.Option>
            {actionButton && actionButton(rest.data.value)}
          </OptionWrapper>
        ),
      }}
    />
  );
};
