interface Option {
  value: string;
  label: string;
}

export interface ReactSelectProps {
  options: Option[];
  value: string | null;
  onChange: (selectedValue: string | null) => void;
  placeholder?: string;
  startDecorator?: React.ReactNode;
  actionButton?: (value: any) => React.ReactNode;
  isDisabled?: boolean;
  isClearable?: boolean;
  onClear?: () => void;
}
