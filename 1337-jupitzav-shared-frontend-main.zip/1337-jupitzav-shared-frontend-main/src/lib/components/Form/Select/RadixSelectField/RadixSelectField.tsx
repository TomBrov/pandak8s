import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '../..';
import { Select } from '@radix-ui/themes';
import styled from 'styled-components';
import * as styles from './styles.ts';
import { FieldProps } from './models.ts';

const Container = styled(FormItem)`
  ${styles.Container}
`;

export const SELECT_CONTENT_ARIA_LABEL = 'select content';

export const SelectField = ({
  control,
  name,
  label,
  placeholder,
  options,
  required,
  disabled = false,
  sideOffset,
  position = 'item-aligned',
  className,
  onChange,
}: FieldProps) => {
  const allOptionsDisabled = options.every((option) => option.disabled);

  return (
    <FormField
      control={control}
      name={name}
      render={({ field }) => (
        <Container className={className}>
          {label && (
            <FormLabel>
              {label} {required && <span className="required">*</span>}
            </FormLabel>
          )}
          <Select.Root
            data-testid="select"
            disabled={disabled}
            size="3"
            onValueChange={(newVal: string) => {
              if (!allOptionsDisabled) {
                field.onChange(newVal);
                onChange?.(newVal);
              }
            }}
            defaultValue={field.value}
            value={field.value}
          >
            <FormControl>
              <Select.Trigger
                className="select-trigger"
                placeholder={placeholder}
              />
            </FormControl>
            <Select.Content
              style={{ height: 'auto' }}
              position={position}
              sideOffset={sideOffset}
              aria-label={SELECT_CONTENT_ARIA_LABEL}
            >
              {options.map((option) => (
                <Select.Item
                  key={option.value}
                  className="select-item"
                  value={option.value}
                  dir="rtl"
                  style={
                    option.disabled
                      ? { pointerEvents: 'none', color: 'var(--gray-8)' }
                      : undefined
                  }
                >
                  {option.renderItem ? option.renderItem() : option.label}
                </Select.Item>
              ))}
            </Select.Content>
          </Select.Root>
          <FormMessage />
        </Container>
      )}
    />
  );
};
