import { css } from 'styled-components';

export const Container = css`
  .required {
    color: rgb(248 113 113);
  }
  .select-trigger {
    flex-direction: row-reverse;
    width: 100%;
  }
  .select-item {
    flex-direction: row-reverse;
  }
`;
