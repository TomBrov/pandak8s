import React from 'react';
import { SelectContentProps } from '@radix-ui/react-select';

export interface Option {
  value: string;
  label: string;
  renderItem?: () => React.ReactNode;
  disabled?: boolean;
}

export type FieldProps = {
  control: any;
  options: Option[];
  name: string;
  label?: string;
  placeholder: string;
  required?: boolean;
  disabled?: boolean;
  sideOffset?: number;
  position?: SelectContentProps['position'];
  className?: string;
  onChange?: (value: string) => void;
};
