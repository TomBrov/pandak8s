import { css } from 'styled-components';

export const Container = css`
  margin-right: 6px;
  overflow: hidden;
  min-width: 0;
  flex-grow: 1;

  > .edit-text-field-root > .input {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    width: 100%;
  }

  > .title-group {
    overflow: hidden;
    min-width: 0;

    > .title {
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
      display: block;
      min-width: 0;
      color: white;
    }

    > .edit-name-btn {
      margin: 0;
      margin-right: auto;
      color: white;
    }
  }

  button {
    cursor: pointer;
  }
`;
