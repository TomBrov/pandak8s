import { useState } from 'react';
import { Flex, IconButton, Text, TextField, Tooltip } from '@radix-ui/themes';
import styled from 'styled-components';
import * as styles from './styles';
import { EditNameProps } from './models';
import {
  PencilSquareIcon,
  CheckIcon,
  XMarkIcon,
} from '@heroicons/react/24/outline';

const Container = styled(Flex)`
  ${styles.Container}
`;

export const EditName = ({
  isEditing: propIsEditing,
  setIsEditing: propSetEditing,
  placeholder,
  displayName,
  saveNewDisplayName,
  cancelFunction = () => {},
  canSeeManagement = true,
}: EditNameProps) => {
  const [newDisplayName, setNewDisplayName] = useState<string>(displayName);
  const [stateIsEditing, stateSetEditing] = useState(false);
  const isEditing = propIsEditing ?? stateIsEditing;
  const setIsEditing = propSetEditing ?? stateSetEditing;

  const handleSave = () => {
    saveNewDisplayName(newDisplayName);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setNewDisplayName(displayName);
    cancelFunction();
  };

  const handleKeyPress = (e: any) => {
    if (e.key === 'Enter') {
      handleSave();
    }
    if (e.key === 'Escape') {
      handleCancel();
    }
    return;
  };

  return (
    <Container direction="row" dir="rtl" align="center">
      {isEditing ? (
        <TextField.Root className="edit-text-field-root">
          <TextField.Input
            dir="rtl"
            className="input"
            onKeyDown={handleKeyPress}
            size="2"
            onChange={(e) => setNewDisplayName(e.target.value)}
            onClick={(e) => {
              e.stopPropagation();
            }}
            value={newDisplayName}
          />
          <TextField.Slot>
            <IconButton
              size="1"
              variant="soft"
              color="grass"
              onClick={(e) => {
                e.stopPropagation();
                handleSave();
              }}
            >
              <CheckIcon width={16} height={16} />
            </IconButton>
            <IconButton
              size="1"
              variant="soft"
              color="amber"
              onClick={(e) => {
                e.stopPropagation();
                handleCancel();
              }}
            >
              <XMarkIcon width={16} height={16} />
            </IconButton>
          </TextField.Slot>
        </TextField.Root>
      ) : (
        <Flex gap="1" align="center" className="title-group" grow="1">
          <Text size="2" className="title" weight="bold">
            {displayName ? displayName : placeholder}
          </Text>

          {canSeeManagement && (
            <Tooltip content="עריכת שם תצוגה">
              <IconButton
                size="2"
                variant="ghost"
                className="edit-name-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsEditing(true);
                }}
              >
                <PencilSquareIcon width={16} height={16} />
              </IconButton>
            </Tooltip>
          )}
        </Flex>
      )}
    </Container>
  );
};
