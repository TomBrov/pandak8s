export type EditNameProps = {
  isEditing?: boolean;
  setIsEditing?: React.Dispatch<React.SetStateAction<boolean>>;
  displayName: string;
  placeholder: string;
  saveNewDisplayName: (newDisplayName: string) => void;
  cancelFunction?: () => void;
  canSeeManagement?: boolean;
};
