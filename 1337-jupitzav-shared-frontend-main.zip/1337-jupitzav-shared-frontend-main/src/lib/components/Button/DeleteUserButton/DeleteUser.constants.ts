export const DIALOG_TITLE = 'מחיקת משתמש';
export const DIALOG_SUBTITLE = 'האם ברצונך למחוק את המשתמש?';
export const ON_ERROR_MSG_DELETE = 'מחיקת משתמש נכשלה';
export const ON_SUCCESS_MSG_DELETE = 'משתמש נמחק בהצלחה';
export const DIALOG_SUBMIT_BTN = 'מחיקת משתמש';
