import { TrashIcon } from '@radix-ui/react-icons';
import { Button, Flex, IconButton } from '@radix-ui/themes';
import { useEffect, useState } from 'react';
import { DraggableDialog } from '../../DraggableDialog';
import {
  DIALOG_SUBTITLE,
  DIALOG_TITLE,
  ON_ERROR_MSG_DELETE,
  ON_SUCCESS_MSG_DELETE,
} from './DeleteUser.constants';
import styled from 'styled-components';
import { useToastStore } from '../../../store/ToastStore';

export type DeleteUserButtonUiProps = {
  onSubmit: () => void;
  isOpen: boolean;
};
export type DeleteUserButtonProps = {
  userToDeleteId: string;
  deleteUser: (
    id: string,
    options: {
      onSuccess: () => void;
      onError: () => void;
    },
  ) => void;
};

const IconButtonContainer = styled(IconButton)`
  cursor: pointer;
`;

export const DeleteUserButtonUi = ({
  onSubmit,
  isOpen,
}: DeleteUserButtonUiProps) => {
  const [openDialog, setOpenDialog] = useState(false);

  useEffect(() => {
    setOpenDialog(isOpen);
  }, [isOpen]);

  return (
    <DraggableDialog
      title={DIALOG_TITLE}
      description={DIALOG_SUBTITLE}
      triggerButton={
        <IconButtonContainer variant="soft" color="red">
          <TrashIcon />
        </IconButtonContainer>
      }
      openDialog={openDialog}
      setOpenDialog={setOpenDialog}
    >
      <Flex justify="center" gap={'2'}>
        <Button onClick={onSubmit}>אישור</Button>
        <Button onClick={() => setOpenDialog((a) => !a)} variant="outline">
          ביטול
        </Button>
      </Flex>
    </DraggableDialog>
  );
};

export const DeleteUserButton = ({
  userToDeleteId,
  deleteUser,
}: DeleteUserButtonProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const { addCallout } = useToastStore();

  const handleDeleteUser = (id: string) => {
    deleteUser(id, { onSuccess, onError });
  };

  const onSuccess = () => {
    setIsOpen(false);
    addCallout({ message: ON_SUCCESS_MSG_DELETE, color: 'green' });
  };

  const onError = () => {
    setIsOpen(false);
    addCallout({ message: ON_ERROR_MSG_DELETE, color: 'red' });
  };
  return (
    userToDeleteId && (
      <DeleteUserButtonUi
        isOpen={isOpen}
        onSubmit={() => {
          handleDeleteUser(userToDeleteId);
        }}
      />
    )
  );
};
