import { Pencil2Icon } from '@radix-ui/react-icons';
import { IconButton, Separator } from '@radix-ui/themes';

import { useState, FC } from 'react';
import {
  EDIT_USER_PROPERTIES,
  FORM_TITLE_EDIT,
  ON_ERROR_MSG_EDIT,
  ON_SUCCESS_MSG,
} from './EditUser.constants';
import styled from 'styled-components';
import * as styles from './styles';
import { useToastStore } from '../../../store/ToastStore';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '../../Sheet';

type EditUserButtonProps = {
  userToEditId: string;
  EditUserForm: FC<{
    onSuccess: () => void;
    onError: () => void;
    userToEditId: string;
  }>;
};

const EditUserSheetContainer = styled.div`
  ${styles.EditUserSheetContainer}
`;

export const EditUserButton = ({
  userToEditId,
  EditUserForm,
}: EditUserButtonProps) => {
  const [sheetOpen, setSheetOpen] = useState(false);
  const { addCallout } = useToastStore();
  const onSuccess = () => {
    setSheetOpen(false);
    addCallout({ message: ON_SUCCESS_MSG, color: 'green' });
  };

  const onError = () => {
    setSheetOpen(false);
    addCallout({ message: ON_ERROR_MSG_EDIT, color: 'red' });
  };

  return (
    <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
      <EditUserSheetContainer>
        <SheetTrigger>
          <IconButton variant="soft" className="edit-user-icon">
            <Pencil2Icon />
          </IconButton>
        </SheetTrigger>
        <SheetContent side="left" className="sheet-content">
          <SheetHeader>
            <SheetTitle>{FORM_TITLE_EDIT}</SheetTitle>
            <SheetDescription>{EDIT_USER_PROPERTIES}</SheetDescription>
          </SheetHeader>
          <Separator my="5" size="4" />
          <EditUserForm
            onSuccess={onSuccess}
            onError={onError}
            userToEditId={userToEditId}
          />
        </SheetContent>
      </EditUserSheetContainer>
    </Sheet>
  );
};
