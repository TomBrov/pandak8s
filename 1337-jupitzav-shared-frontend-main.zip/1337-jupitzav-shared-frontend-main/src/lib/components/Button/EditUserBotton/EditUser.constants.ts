export const EDIT_USER_PROPERTIES = 'עריכת פרטי משתמש';
export const FORM_TITLE_EDIT = 'עריכת משתמש';
export const ON_ERROR_MSG_EDIT = 'עריכת משתמש נכשלה';
export const ON_SUCCESS_MSG = 'משתמש נערך בהצלחה';
export const FORM_SUBMIT_BTN_EDIT = 'עריכת משתמש';
