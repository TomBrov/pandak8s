import { css } from 'styled-components';

export const EditUserSheetContainer = css`
  .edit-user-icon {
    cursor: pointer;
  }

  .sheet-content {
    color: red;
    max-width: none;
    width: 600px;
    @media (min-width: 640px) {
      width: 540px;
    }
    border-width: 1px;
    border-style: solid;
    border-right-color: rgb(148 163 184);
  }
`;

export const EditUserFormContainer = css`
  & > * {
    margin-top: 1.5rem;
  }

  .clickable {
    cursor: pointer;
  }
`;
