import styled from 'styled-components';
import { AnimationStyle } from './AnimateContent.types';
import {
  fadeIn,
  fadeOut,
  flipIn,
  flipOut,
  rotateIn,
  rotateOut,
  scaleIn,
  scaleOut,
  slideIn,
  slideOut,
} from './AnimateContent.animations';

export const AnimatedContainer = styled('div').withConfig({
  shouldForwardProp: (prop) =>
    !['animationDuration', 'isEntering', 'animationStyle'].includes(prop),
})<{
  animationDuration: number;
  isEntering: boolean;
  animationStyle: AnimationStyle | undefined;
}>`
  animation: ${({ isEntering, animationStyle }) => {
      switch (animationStyle) {
        case AnimationStyle.Fade:
          return isEntering ? fadeIn : fadeOut;
        case AnimationStyle.Slide:
          return isEntering ? slideIn : slideOut;
        case AnimationStyle.Scale:
          return isEntering ? scaleIn : scaleOut;
        case AnimationStyle.Rotate:
          return isEntering ? rotateIn : rotateOut;
        case AnimationStyle.Flip:
          return isEntering ? flipIn : flipOut;
        default:
          return isEntering ? fadeIn : fadeOut;
      }
    }}
    ease-in-out;
  animation-duration: ${({ animationDuration }) => animationDuration}ms;
  transform-origin: top right;
`;
