export type AnimateContentProps = {
  isShowed: boolean;
  children: React.ReactNode;
  animationStyle?: AnimationStyle;
  animationDuration?: number;
};

export enum AnimationStyle {
  Fade = 'fade',
  Slide = 'slide',
  Scale = 'scale',
  Rotate = 'rotate',
  Flip = 'flip',
}
