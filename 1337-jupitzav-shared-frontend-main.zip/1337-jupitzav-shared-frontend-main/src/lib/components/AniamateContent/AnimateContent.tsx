import { useState, useEffect } from 'react';
import { AnimateContentProps } from './AnimateContent.types';
import { AnimatedContainer } from './AnimateContent.styles';

export const AnimateContent = ({
  isShowed,
  children,
  animationStyle,
  animationDuration = 300,
}: AnimateContentProps) => {
  const [isAnimating, setIsAnimating] = useState(false);
  const [isEntering, setIsEntering] = useState(true);

  useEffect(() => {
    if (isShowed) {
      setIsAnimating(true);
      setIsEntering(true);
    } else {
      setIsEntering(false);
    }
  }, [isShowed]);

  useEffect(() => {
    let timeoutId: any;
    if (isAnimating && !isShowed) {
      timeoutId = setTimeout(() => {
        setIsAnimating(false);
      }, animationDuration);
    }
    return () => {
      clearTimeout(timeoutId);
    };
  }, [animationDuration, isAnimating, isShowed]);

  return (
    <AnimatedContainer
      animationDuration={animationDuration}
      animationStyle={animationStyle}
      isEntering={isEntering}
    >
      {isAnimating && children}
    </AnimatedContainer>
  );
};
