import { keyframes } from 'styled-components';

export const fadeIn = keyframes`
  0% {
    opacity: 0;
    transform: scale(0.9) translateY(-100%);
  }
  100% {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
`;

export const fadeOut = keyframes`
  0% {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
  100% {
    opacity: 0;
    transform: scale(0.9) translateY(-100%);
  }
`;

export const slideIn = keyframes`
  0% {
    opacity: 0;
    transform: translateX(-100%);
  }
  100% {
    opacity: 1;
    transform: translateX(0);
  }
`;

export const slideOut = keyframes`
  0% {
    opacity: 1;
    transform: translateX(0);
  }
  100% {
    opacity: 0;
    transform: translateX(-100%);
  }
`;

export const scaleIn = keyframes`
  0% {
    opacity: 0;
    transform: scale(0.5);
  }
  100% {
    opacity: 1;
    transform: scale(1);
  }
`;

export const scaleOut = keyframes`
  0% {
    opacity: 1;
    transform: scale(1);
  }
  100% {
    opacity: 0;
    transform: scale(0.5);
  }
`;

export const rotateIn = keyframes`
  0% {
    opacity: 0;
    transform: rotate(-360deg);
  }
  100% {
    opacity: 1;
    transform: rotate(0deg);
  }
`;

export const rotateOut = keyframes`
  0% {
    opacity: 1;
    transform: rotate(0deg);
  }
  100% {
    opacity: 0;
    transform: rotate(360deg);
  }
`;

export const flipIn = keyframes`
  0% {
    opacity: 0;
    transform: perspective(400px) rotateY(90deg);
  }
  100% {
    opacity: 1;
    transform: perspective(400px) rotateY(0deg);
  }
`;

export const flipOut = keyframes`
  0% {
    opacity: 1;
    transform: perspective(400px) rotateY(0deg);
  }
  100% {
    opacity: 0;
    transform: perspective(400px) rotateY(-90deg);
  }
`;
