import { css } from 'styled-components';

export const Container = css`
  width: 100%;
  button {
    cursor: pointer;
  }
`;
