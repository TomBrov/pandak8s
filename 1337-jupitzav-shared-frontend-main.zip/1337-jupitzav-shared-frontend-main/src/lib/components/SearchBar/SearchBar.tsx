import { Cross1Icon, MagnifyingGlassIcon } from '@radix-ui/react-icons';
import { IconButton, TextField } from '@radix-ui/themes';
import styled from 'styled-components';
import * as styles from './styles';
import React from 'react';

const Container = styled(TextField.Root)`
  ${styles.Container}
`;

export type SearchItemBarProps<TData> = {
  placeholder: string;
  objects: TData[];
  filterField: 'name' | 'displayName';
  searchItem: string;
  setSearchItem: React.Dispatch<React.SetStateAction<string>>;
  setFilteredObjects?: React.Dispatch<React.SetStateAction<TData[]>>;
  textInputProps?: typeof TextField.Input;
};

export const SearchBar = <TData extends { [key: string]: any }>({
  placeholder,
  objects,
  setFilteredObjects,
  setSearchItem,
  filterField,
  searchItem,
  textInputProps,
}: SearchItemBarProps<TData>) => {
  // TODO: add debounce

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const searchTerm = e.target.value;
    setSearchItem(searchTerm);
    // filter the items using the apiUsers state
    const filteredItems = objects.filter((obj) => {
      const name = obj[filterField];
      return name.toLowerCase().includes(searchTerm.toLowerCase());
    });

    setFilteredObjects?.(filteredItems);
  };

  const clearFilters = () => {
    setSearchItem('');
    setFilteredObjects?.(objects);
  };

  return (
    <Container>
      <TextField.Slot>
        <MagnifyingGlassIcon height="16" width="16" />
      </TextField.Slot>
      <TextField.Input
        className="input"
        autoFocus
        size="2"
        placeholder={placeholder}
        value={searchItem}
        onChange={handleInputChange}
        {...textInputProps}
      />
      {searchItem && (
        <TextField.Slot>
          <IconButton size="1" variant="ghost" onClick={clearFilters}>
            <Cross1Icon height="16" width="16" />
          </IconButton>
        </TextField.Slot>
      )}
    </Container>
  );
};
