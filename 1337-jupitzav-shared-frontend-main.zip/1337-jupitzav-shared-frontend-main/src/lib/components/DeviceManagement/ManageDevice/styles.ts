import { css } from 'styled-components';

export const CreateButton = css`
  cursor: pointer;

  &:disabled {
    cursor: not-allowed;
    opacity: 0.5;
  }
`;

export const EditButton = css`
  &:disabled {
    cursor: not-allowed;
    opacity: 0.5;
  }
`;

export const SheetContentStyled = css`
  border-width: 1px;
  border-style: solid;
  width: 600px;
  max-width: none;

  @media (min-width: 640px) {
    width: 540px;
  }
`;
