export const CREATE_FORM_BUTTON = 'יצירת';
export const FORM_ALL_REQUIRE = 'כל השדות המסומנים בכוכבית הינם שדות חובה';
