import { Meta, StoryObj } from '@storybook/react';
import { ManageDevice } from './ManageDevice';
import { useState } from 'react';

const meta: Meta<typeof ManageDevice> = {
  title: 'Components/ManageDevice',
  component: ManageDevice,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof ManageDevice>;

const DefaultComponent = () => {
  const [sheet, setSheet] = useState<boolean>(false);

  return (
    <ManageDevice
      formDeviceType="מצלמה"
      formTitle=""
      isCreateMode={true}
      sheetOpen={sheet}
      setSheetOpen={setSheet}
    >
      :)
    </ManageDevice>
  );
};

export const Default: Story = {
  render: () => <DefaultComponent />,
};
