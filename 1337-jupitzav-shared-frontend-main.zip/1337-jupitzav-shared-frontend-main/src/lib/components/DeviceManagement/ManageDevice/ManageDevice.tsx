import { Button, IconButton, Separator } from '@radix-ui/themes';
import { Pencil2Icon } from '@radix-ui/react-icons';
import styled from 'styled-components';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '../../Sheet';
import { CREATE_FORM_BUTTON, FORM_ALL_REQUIRE } from './ManageDevice.constants';
import * as styles from './styles';

type ManageDeviceProps = {
  isCreateMode: boolean;
  disabled?: boolean;
  children: React.ReactNode;
  sheetOpen: boolean;
  setSheetOpen: (open: boolean) => void;
  formTitle: string;
  formDeviceType: string;
};

const CreateButton = styled(Button)`
  ${styles.CreateButton}
`;

const EditButton = styled(IconButton)`
  ${styles.EditButton}
`;

const SheetContentStyled = styled(SheetContent)`
  ${styles.SheetContentStyled}
`;

export const ManageDevice = ({
  isCreateMode,
  disabled,
  children,
  sheetOpen,
  setSheetOpen,
  formTitle,
  formDeviceType,
}: ManageDeviceProps) => {
  return (
    <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
      <SheetTrigger>
        {isCreateMode ? (
          <CreateButton disabled={disabled}>
            {CREATE_FORM_BUTTON} {formDeviceType}
          </CreateButton>
        ) : (
          <EditButton variant="soft" className="cursor-pointer">
            <Pencil2Icon />
          </EditButton>
        )}
      </SheetTrigger>
      <SheetContentStyled side="left">
        <SheetHeader>
          <SheetTitle>{formTitle}</SheetTitle>
          <SheetDescription>{FORM_ALL_REQUIRE}</SheetDescription>
        </SheetHeader>
        <Separator my="5" size="4" />
        {children}
      </SheetContentStyled>
    </Sheet>
  );
};
