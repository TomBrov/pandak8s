import { Card, Flex, IconButton, Text, Tooltip } from '@radix-ui/themes';
import { useCopyToClipboard } from '../../hooks/useCopyToClipboard.ts';
import { CopyIcon } from '@radix-ui/react-icons';
import { useToastStore } from '../../store/ToastStore';
import styled from 'styled-components';
import * as styles from './styles.ts';

const CardContainer = styled(Card)`
  ${styles.CardContainer}
`;

export interface NestedListItem {
  name: string;
  subItems?: string[];
}

export interface NestedListProps {
  items: NestedListItem[];
}

export type SummaryCardProps = {
  title: string;
  description: NestedListItem[];
};

export const SummaryCard = ({ title, description }: SummaryCardProps) => {
  const [_, copy] = useCopyToClipboard();
  const { addCallout } = useToastStore();

  const formatTitleAndDescription = () => {
    let formattedText = `${title}\n\n`;
    description.forEach((desc) => {
      formattedText += `${desc.name}\n`;
      if (desc.subItems && desc.subItems.length > 0) {
        desc.subItems.forEach((subItem) => {
          formattedText += `- ${subItem}\n`;
        });
      }
    });
    return formattedText;
  };

  const handleCopy = () => {
    const text = formatTitleAndDescription();
    copy(text);
    addCallout({ message: 'הועתק בהצלחה', color: 'green' });
  };

  return (
    <CardContainer variant="classic">
      <Flex direction="row" gap="2">
        <Flex direction="column" grow="1" gap="1">
          <Text as="div" className="title" size="3" weight="bold">
            {title}
          </Text>
          <ul>
            {description.map((desc, descIndex) => (
              <li key={`${descIndex}-${desc}`}>
                <Text
                  as="div"
                  size="2"
                  weight="medium"
                  className={`${desc.subItems && ''}`}
                >
                  {desc.name}
                </Text>
                {desc.subItems && (
                  <ul>
                    {desc.subItems.map((subItem, subIndex) => (
                      <li key={`${subIndex}-${subItem}`}>
                        <Text as="div" size="2">
                          {subItem}
                        </Text>
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            ))}
          </ul>
          {/* <ul>
            {description.map((desc, index) => (
              <li key={index}>
                <Text as="div" color="gray" size="2" a>
                  {desc}
                </Text>
              </li>
            ))}
          </ul> */}
        </Flex>
        <Tooltip content={'העתק'}>
          <IconButton
            className="icon-button"
            onClick={() => handleCopy()}
            variant="soft"
          >
            <CopyIcon />
          </IconButton>
        </Tooltip>
      </Flex>
    </CardContainer>
  );
};
