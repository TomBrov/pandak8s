import { css } from 'styled-components';
import { blueDark, gray } from '@radix-ui/colors';

export const CardContainer = css`
  flex-grow: 1;
  text-align: right;
  background-color: ${blueDark.blue2};
  direction: rtl;

  .title {
    margin-bottom: 0.25rem;
  }

  .icon-button {
    cursor: pointer;
  }

  ul {
    direction: rtl;
    color: ${gray.gray8};
    list-style-type: disc;
    margin-right: 1rem;

    li {
      margin-bottom: 0.25rem;
    }

    ul {
      padding-inline-start: 1.25rem;
      margin-top: 0.5rem;
      list-style-type: decimal;
      color: ${gray.gray8};
    }
  }
`;
