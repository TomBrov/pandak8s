import { Meta, StoryObj } from '@storybook/react';
import { DeleteDeviceButton } from './DeleteDeviceButton';

const meta: Meta<typeof DeleteDeviceButton> = {
  title: 'Components/DeleteDeviceButton',
  component: DeleteDeviceButton,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof DeleteDeviceButton>;

export const Default: Story = {};
