import { TrashIcon } from '@radix-ui/react-icons';
import { Button, Flex, IconButton } from '@radix-ui/themes';
import { useEffect, useState } from 'react';
import { DraggableDialog } from '../../DraggableDialog';
import styled from 'styled-components';
import { useToastStore } from '../../../store/ToastStore';

export type DeleteDeviceButtonUiProps = {
  onSubmit: () => void;
  isOpen: boolean;
  dialogTitle: string;
  dialogSubtitle: string;
};
export type DeleteDeviceButtonProps = {
  deviceToDeleteId: string;
  deleteDevice: (
    id: string,
    options: {
      onSuccess: () => void;
      onError: () => void;
    },
  ) => void;
  errorMsg: string;
  successMsg: string;
  dialogSubtitle: string;
  dialogTitle: string;
};

const IconButtonContainer = styled(IconButton)`
  cursor: pointer;
`;

export const DeleteDeviceButtonUi = ({
  onSubmit,
  isOpen,
  dialogSubtitle,
  dialogTitle,
}: DeleteDeviceButtonUiProps) => {
  const [openDialog, setOpenDialog] = useState(false);

  useEffect(() => {
    setOpenDialog(isOpen);
  }, [isOpen]);

  return (
    <DraggableDialog
      title={dialogTitle}
      description={dialogSubtitle}
      triggerButton={
        <IconButtonContainer variant="soft" color="red">
          <TrashIcon />
        </IconButtonContainer>
      }
      openDialog={openDialog}
      setOpenDialog={setOpenDialog}
    >
      <Flex justify="center" gap={'2'}>
        <Button onClick={onSubmit}>אישור</Button>
        <Button
          onClick={() => setOpenDialog((a: boolean) => !a)}
          variant="outline"
        >
          ביטול
        </Button>
      </Flex>
    </DraggableDialog>
  );
};

export const DeleteDeviceButton = ({
  deviceToDeleteId,
  deleteDevice,
  errorMsg,
  successMsg,
  dialogSubtitle,
  dialogTitle,
}: DeleteDeviceButtonProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const { addCallout } = useToastStore();

  const handleDeleteDevice = (id: string) => {
    deleteDevice(id, { onSuccess, onError });
  };

  const onSuccess = () => {
    setIsOpen(false);
    addCallout({ message: successMsg, color: 'green' });
  };

  const onError = () => {
    setIsOpen(false);
    addCallout({ message: errorMsg, color: 'red' });
  };

  return (
    <DeleteDeviceButtonUi
      isOpen={isOpen}
      onSubmit={() => {
        handleDeleteDevice(deviceToDeleteId);
      }}
      dialogSubtitle={dialogSubtitle}
      dialogTitle={dialogTitle}
    />
  );
};
