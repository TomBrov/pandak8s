import { Meta, StoryObj } from '@storybook/react';
import { DeviceTableToolbar } from './DeviceTableToolbar';
import { useSharedDeviceTableFilters } from '.';
import { DataTableColumnHeader } from '../..';
import {
  getCoreRowModel,
  getExpandedRowModel,
  getFacetedMinMaxValues,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from '@tanstack/react-table';
import { Button } from '@radix-ui/themes';

const meta: Meta<typeof DeviceTableToolbar> = {
  title: 'Components/DeviceTableToolbar',
  component: DeviceTableToolbar,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof DeviceTableToolbar>;

const DeviceTableToolbarStory = () => {
  const columns = [
    {
      accessorKey: 'displayName',
      header: ({ column }: { column: any }) => (
        <DataTableColumnHeader
          column={column}
          title={getColNameByAccessorKey('displayName')}
        />
      ),
      cell: ({ row }: { row: any }) => <div>{row.getValue('displayName')}</div>,
    },
    {
      accessorKey: 'color',
      header: ({ column }: { column: any }) => (
        <DataTableColumnHeader
          column={column}
          title={getColNameByAccessorKey('color')}
        />
      ),
      cell: ({ row }: { row: any }) => <div>{row.getValue('color')}</div>,
    },
  ];

  function getColNameByAccessorKey(accessorKey: string) {
    switch (accessorKey) {
      case 'displayName':
        return 'שם';
      case 'color':
        return 'צבע';
      default:
        return '';
    }
  }

  const table = useReactTable<unknown>({
    data: [
      {
        displayName: 'name',
        color: 'blue',
      },
    ],
    columns,
    enableRowSelection: false,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
    getFacetedMinMaxValues: getFacetedMinMaxValues(),
    getRowCanExpand: () => true,
    getExpandedRowModel: getExpandedRowModel(),
  });

  const filters = useSharedDeviceTableFilters({ table });

  return (
    <DeviceTableToolbar
      CreateDeviceButton={() => <Button>יצירת מצלמה</Button>}
      filters={filters}
      formDeviceType="מצלמות"
      getColNameByAccessorKey={getColNameByAccessorKey}
      table={table}
    />
  );
};

export const Default: Story = {
  render: () => <DeviceTableToolbarStory />,
};
