import { css } from 'styled-components';

export const ToolbarContainer = css`
  display: flex;
  justify-content: space-between;
  align-items: center;
  .TextFieldInput {
    height: 2rem;
    width: 150px;

    @media (min-width: 1024px) {
      width: 250px;
    }
  }

  .Cross2Icon {
    width: 1rem;
    height: 1rem;
  }

  .ToolbarFilters {
    display: flex;
    flex: 1 1 0%;
    gap: 0.75rem;
    align-items: center;
  }

  .ToolbarActions {
    display: flex;
    gap: 0.75rem;
    align-items: center;
  }
`;
