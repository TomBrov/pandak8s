import { Table } from '@tanstack/react-table';
import { DataTableFacetedFilter } from '../../DataTable/DataTableFacetedFilter';
import { TextField } from '@radix-ui/themes';

interface UseSharedDeviceTableFiltersProps<TData> {
  table: Table<TData>;
}

export const SEARCH_PLACEHOLDER = 'חיפוש לפי שם תצוגה';

export const getColNameByAccessorKey = (accessorKey: string) => {
  switch (accessorKey) {
    case 'type':
      return 'סוג';
    default:
      return '';
  }
};

// TODO: replace with backend call to get the unique values from the database
export function getOptionsFromColumn<TData>(
  table: Table<TData>,
  column: string,
) {
  const col = table.getColumn(column);
  const colMap = col ? col.getFacetedUniqueValues() : [];
  const options = Array.from(colMap.entries()).map(([key]) => {
    return { label: key, value: key };
  });
  return options;
}

export function useSharedDeviceTableFilters<TData>(
  props: UseSharedDeviceTableFiltersProps<TData>,
) {
  const table = props.table;

  const typeOptions = getOptionsFromColumn(table, 'type');

  return [
    <TextField.Input
      key={'displayName'}
      className="TextFieldInput"
      placeholder={SEARCH_PLACEHOLDER}
      value={(table.getColumn('displayName')?.getFilterValue() as string) ?? ''}
      onChange={(event) =>
        table.getColumn('displayName')?.setFilterValue(event.target.value)
      }
    />,

    table.getColumn('type') && (
      <DataTableFacetedFilter
        column={table.getColumn('type')}
        title={getColNameByAccessorKey('type')}
        options={[...typeOptions]}
      />
    ),
  ];
}
