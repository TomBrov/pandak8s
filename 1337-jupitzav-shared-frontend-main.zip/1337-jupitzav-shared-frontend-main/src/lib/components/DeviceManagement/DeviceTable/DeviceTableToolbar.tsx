import { Cross2Icon } from '@radix-ui/react-icons';
import { Table } from '@tanstack/react-table';
import { Button, Separator } from '@radix-ui/themes';
import { CLEAN_FILTERS } from '../../DataTable/DataTable.constants';
import { DataTableViewOptions } from '../../DataTable/DataTablViewOptions/DataTablViewOptions';
import { ExportCSVButton } from '../../DataTable/ExportCSVButton';
import styled from 'styled-components';
import * as styles from './styles';
import React from 'react';

interface DeviceTableToolbarProps<TData> {
  table: Table<TData>;
  CreateDeviceButton: React.ComponentType;
  filters: React.ReactNode[];
  getColNameByAccessorKey: (key: string) => string;
  formDeviceType: string;
}

const ToolbarContainer = styled.div`
  ${styles.ToolbarContainer}
`;

export function DeviceTableToolbar<TData>({
  table,
  CreateDeviceButton,
  filters,
  getColNameByAccessorKey,
  formDeviceType,
}: DeviceTableToolbarProps<TData>) {
  const isFiltered = table.getState().columnFilters.length > 0;

  return (
    <ToolbarContainer dir="rtl">
      <div className="ToolbarFilters">
        {filters.map((filter, index) => (
          <React.Fragment key={index}>{filter}</React.Fragment>
        ))}

        {isFiltered && (
          <Button
            variant="ghost"
            onClick={() => table.resetColumnFilters()}
            className="mr-2"
          >
            <Cross2Icon className="Cross2Icon" />
            {CLEAN_FILTERS}
          </Button>
        )}
      </div>
      <div className="ToolbarActions">
        <DataTableViewOptions
          table={table}
          getColNameByAccessorKey={getColNameByAccessorKey}
        />
        <Separator orientation="vertical" />
        <CreateDeviceButton />
        <ExportCSVButton
          table={table}
          getColNameByAccessorKey={getColNameByAccessorKey}
          filename={`דו״ח תקינות ${formDeviceType} ${new Date().toLocaleDateString()}`}
        />
      </div>
    </ToolbarContainer>
  );
}
