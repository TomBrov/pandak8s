import { Flex } from '@radix-ui/themes';
import styled from 'styled-components';

export const CalloutListContainer = styled(Flex).attrs(() => ({
  position: 'absolute',
  direction: 'column',
}))`
  z-index: 10;
  gap: 4px;
  top: 8px;
  transition: height 0.3s ease;
  & .callout-container {
    right: 8px;
    background-color: black;
    opacity: 1;
    border-radius: 12px;
  }
`;
