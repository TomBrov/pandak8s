import { useEffect } from 'react';
import { AnimateContent } from '../AniamateContent/AnimateContent';
import { CalloutListContainer } from './Callout.style';
import { CalloutComponent } from './Callout';
import { useToastStore } from '../../store/ToastStore';

export const ToastList = () => {
  const { callouts, showAlert, toggleAlert } = useToastStore();

  useEffect(() => {
    if (callouts.length > 0 && !showAlert) {
      toggleAlert();
    }
  }, [callouts, showAlert, toggleAlert]);

  useEffect(() => {
    const timeoutIds = callouts.reduce((acc, callout, index) => {
      if (callout.isShowed) {
        const timeoutId = setTimeout(() => {
          useToastStore.setState((state) => ({
            callouts: state.callouts.map((c, i) =>
              i === index ? { ...c, isShowed: false } : c,
            ),
          }));
        }, 3000);
        acc.push(timeoutId);
      }
      return acc;
    }, [] as NodeJS.Timeout[]);

    return () => {
      timeoutIds.forEach((timeoutId) => clearTimeout(timeoutId));
    };
  }, [callouts]);

  return (
    <AnimateContent isShowed={showAlert}>
      <CalloutListContainer>
        {callouts.map(
          ({ isShowed, message, variant, size, color, role }, index) => (
            <AnimateContent key={index} isShowed={isShowed}>
              <div className="callout-container">
                <CalloutComponent
                  message={message}
                  variant={variant}
                  size={size}
                  color={color}
                  role={role}
                />
              </div>
            </AnimateContent>
          ),
        )}
      </CalloutListContainer>
    </AnimateContent>
  );
};
