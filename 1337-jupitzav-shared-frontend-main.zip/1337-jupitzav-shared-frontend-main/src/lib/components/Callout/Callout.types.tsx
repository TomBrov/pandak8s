export interface CalloutProps {
  message: string;
  variant?: 'soft' | 'surface' | 'outline';
  size?: '1' | '2' | '3';
  color?: 'green' | 'red' | 'blue' | 'yellow' | 'purple' | 'orange';
  role?: 'info' | 'alert';
}
