import {
  ExclamationTriangleIcon,
  InfoCircledIcon,
} from '@radix-ui/react-icons';
import { Callout } from '@radix-ui/themes';
import styled from 'styled-components';

const Container = styled(Callout.Root)`
  text-align: right;
`;

export const CalloutComponent = ({
  message,
  role = 'alert',
  variant = 'soft',
  size = '2',
  color,
}: {
  message: string;
  role?: 'alert' | 'info';
  variant?: 'soft' | 'surface' | 'outline';
  size?: '1' | '2' | '3';
  color?: 'green' | 'red' | 'blue' | 'yellow' | 'purple' | 'orange';
}) => {
  const Icon = role === 'info' ? InfoCircledIcon : ExclamationTriangleIcon;

  return (
    <Container variant={variant} size={size} color={color}>
      <Callout.Icon>
        <Icon />
      </Callout.Icon>
      <Callout.Text>{message}</Callout.Text>
    </Container>
  );
};
