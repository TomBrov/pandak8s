import { css } from 'styled-components';
import { VideoPlayerProps } from './models.ts';

export const VideoPlayer = css<VideoPlayerProps>(
  ({ isFullSize }) => css`
    object-fit: fill;

    width: 100%;
    ${!isFullSize && 'height:100%;'};
  `,
);
