import { AxiosRequestConfig, AxiosResponse } from 'axios';

export type CameraServerFetch = (
  id: string,
) => Promise<{ name: string | null; port: string }>;
export type WebrtcFetch = (
  request: AxiosRequestConfig,
) => Promise<AxiosResponse>;

export type VideoPlayerProps = {
  isFullSize: boolean;
};

export type CameraStreamerProps = {
  className?: string;
  cameraId: string;
  isFullSize?: boolean;
  webrtcFetch: WebrtcFetch;
  cameraServerFetch: CameraServerFetch;
};
