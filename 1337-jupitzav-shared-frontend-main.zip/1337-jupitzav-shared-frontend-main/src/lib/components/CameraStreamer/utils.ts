export type OfferData = {
  iceUfrag: string;
  icePwd: string;
  medias: string[];
};

export const parseOffer = (offer: string | undefined = ''): OfferData => {
  const offerData: OfferData = {
    iceUfrag: '',
    icePwd: '',
    medias: [],
  };

  for (const line of offer.split('\r\n')) {
    if (line.startsWith('m=')) {
      offerData.medias.push(line.slice('m='.length));
    } else if (offerData.iceUfrag === '' && line.startsWith('a=ice-ufrag:')) {
      offerData.iceUfrag = line.slice('a=ice-ufrag:'.length);
    } else if (offerData.icePwd === '' && line.startsWith('a=ice-pwd:')) {
      offerData.icePwd = line.slice('a=ice-pwd:'.length);
    }
  }

  return offerData;
};

export const generateSdpFragment = (
  offerData: OfferData,
  candidates: RTCIceCandidate[],
) => {
  const candidatesByMedia: { [key: number]: RTCIceCandidate[] } = {};
  for (const candidate of candidates) {
    const mid = candidate.sdpMLineIndex;

    if (mid === null) continue;

    if (candidatesByMedia[mid] === undefined) {
      candidatesByMedia[mid] = [];
    }

    candidatesByMedia[mid]?.push(candidate);
  }

  let frag =
    'a=ice-ufrag:' +
    offerData.iceUfrag +
    '\r\n' +
    'a=ice-pwd:' +
    offerData.icePwd +
    '\r\n';

  let mid = 0;

  for (const media of offerData.medias) {
    if (candidatesByMedia[mid] !== undefined) {
      frag += 'm=' + media + '\r\n' + 'a=mid:' + mid + '\r\n';

      for (const candidate of candidatesByMedia[mid] || []) {
        frag += 'a=' + candidate.candidate + '\r\n';
      }
    }
    mid++;
  }

  return frag;
};
