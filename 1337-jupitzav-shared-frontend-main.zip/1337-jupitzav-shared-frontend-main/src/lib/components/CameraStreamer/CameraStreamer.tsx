import { useRef } from 'react';
import { useVideoStream } from './useVideoStream';
import { VideoPlayerProps, CameraStreamerProps } from './models';
import styled from 'styled-components';
import * as styles from './styles';

const VideoPlayer = styled.video<VideoPlayerProps>`
  ${styles.VideoPlayer}
`;

export const CameraStreamer = ({
  className,
  cameraId,
  isFullSize = false,
  webrtcFetch,
  cameraServerFetch,
}: CameraStreamerProps) => {
  const videoRef = useRef<HTMLVideoElement>(null);

  useVideoStream(videoRef, cameraId, webrtcFetch, cameraServerFetch);

  return (
    <VideoPlayer
      className={className}
      isFullSize={isFullSize}
      id="video"
      ref={videoRef}
      controls
      playsInline
      muted
      autoPlay
    />
  );
};
