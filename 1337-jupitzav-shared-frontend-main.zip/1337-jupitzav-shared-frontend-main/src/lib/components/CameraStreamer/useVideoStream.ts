import { RefObject, useEffect, useRef } from 'react';
import { generateSdpFragment, OfferData, parseOffer } from './utils.ts';
import { CameraServerFetch, WebrtcFetch } from './models';

let timeout: any;
export const useVideoStream = (
  videoRef: RefObject<HTMLVideoElement>,
  cameraId: string,
  webrtcFetch: WebrtcFetch,
  cameraServerFetch: CameraServerFetch,
  webrtcStreaming?: string,
) => {
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const restartTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const sessionUrlRef = useRef<string>('');
  const offerDataRef = useRef<OfferData | null>(null);
  const queuedCandidatesRef = useRef<RTCIceCandidate[]>([]);

  const onError = (error: string) => {
    if (restartTimeoutRef.current === null) {
      console.error(error + ', retrying in some seconds');
      videoRef.current!.controls = false;

      if (peerConnectionRef.current) {
        peerConnectionRef.current.close();
        peerConnectionRef.current = null;
      }

      restartTimeoutRef.current = setTimeout(() => {
        restartTimeoutRef.current = null;
        loadStream(webrtcStreaming);
      }, 500);

      if (sessionUrlRef.current) {
        webrtcFetch({
          url: sessionUrlRef.current,
          method: 'DELETE',
        });
      }

      sessionUrlRef.current = '';
      queuedCandidatesRef.current = [];
    }
  };

  const sendLocalCandidates = async (candidates: RTCIceCandidate[]) => {
    if (!offerDataRef.current) return;

    try {
      const response = await webrtcFetch({
        url: sessionUrlRef.current,
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/trickle-ice-sdpfrag',
          'If-Match': '*',
        },
        data: generateSdpFragment(offerDataRef.current, candidates),
      });

      switch (response.status) {
        case 204:
          break;
        case 404:
          throw 'stream not found';
        default:
          throw `bad status code ${response.status}`;
      }
    } catch (error) {
      if (typeof error === 'string') onError(error.toString());
    }
  };

  const onLocalCandidate = (event: RTCPeerConnectionIceEvent) => {
    if (restartTimeoutRef.current !== null) {
      return;
    }

    if (event.candidate !== null) {
      if (sessionUrlRef.current === '') {
        queuedCandidatesRef.current.push(event.candidate);
      } else {
        sendLocalCandidates([event.candidate]);
      }
    }
  };

  const onRemoteAnswer = async (sdp: string) => {
    if (restartTimeoutRef.current !== null) {
      return;
    }
    peerConnectionRef.current?.setRemoteDescription(
      new RTCSessionDescription({
        type: 'answer',
        sdp,
      }),
    );

    if (queuedCandidatesRef.current.length !== 0) {
      sendLocalCandidates(queuedCandidatesRef.current);
      queuedCandidatesRef.current = [];
    }
  };

  const sendOffer = async (
    offer: RTCSessionDescriptionInit,
    retryCount = 0,
    webrtcStreaming?: string,
  ) => {
    try {
      const url = `${cameraId}/whep`;
      const response = await webrtcFetch({
        method: 'POST',
        url,
        headers: {
          'Content-Type': 'application/sdp',
        },
        data: offer.sdp,
      });

      switch (response.status) {
        case 201:
          break;
        case 404:
          throw 'stream not found';
        default:
          throw `bad status code ${response.status}`;
      }

      sessionUrlRef.current = `${cameraId}/${response.headers['location']}`;

      const sdp: string = response.data;

      const server = await cameraServerFetch(cameraId.split('.')[0]!);

      const newSdp = sdp
        .split(/\r?\n/)
        .map((line) => {
          if (line.startsWith('a=candidate:')) {
            const sections = line.split(' ');
            sections[4] =
              webrtcStreaming || server.name || window.location.hostname;
            sections[5] = server.port;
            return sections.join(' ');
          }
          return line;
        })
        .join('\n');

      onRemoteAnswer(newSdp);
    } catch (error: any) {
      if (typeof error === 'string') onError(error.toString());
      else if (retryCount < 15) {
        timeout = setTimeout(
          () => sendOffer(offer, retryCount + 1),
          60 * 1000,
          webrtcStreaming,
        ); // Retry after 1 minute
      }
    }
  };

  const onConnectionState = () => {
    if (restartTimeoutRef.current !== null) {
      return;
    }

    if (peerConnectionRef.current?.iceConnectionState === 'disconnected') {
      onError('peer connection disconnected');
    }
  };

  const loadStream = async (webrtcStreaming?: string) => {
    peerConnectionRef.current = new RTCPeerConnection();

    const direction = 'sendrecv';
    peerConnectionRef.current.addTransceiver('video', { direction });

    peerConnectionRef.current.onicecandidate = onLocalCandidate;
    peerConnectionRef.current.oniceconnectionstatechange = onConnectionState;
    peerConnectionRef.current.ontrack = (event) => {
      videoRef.current!.srcObject = event.streams[0] || null;
    };

    // Create offer
    const offer = await peerConnectionRef.current.createOffer();
    offerDataRef.current = parseOffer(offer.sdp);
    peerConnectionRef.current.setLocalDescription(offer);
    await sendOffer(offer, 0, webrtcStreaming);

    videoRef.current!.play();
  };

  useEffect(() => {
    loadStream(webrtcStreaming);

    return () => {
      peerConnectionRef.current?.close();
      timeout && clearTimeout(timeout);
    };
    // TODO: there's a circular dependencies because onError also depends on loadStream
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cameraId]);
};
