export type ContextMenuItemType = {
  title: string;
  onClick: (e?: React.MouseEvent<HTMLSpanElement, MouseEvent>) => void;
  id: string;
  disabled: boolean;
  withSeparateLine?: boolean;
};

export type ContextMenuProps = {
  menuPosition: { x: number; y: number };
  isMenuOpen: boolean;
  setIsMenuOpen: (isOpen: boolean) => void;
  title?: string;
  menuItems: ContextMenuItemType[];
  closeAfterClick?: boolean;
};
