import { Container, MenuItem } from './styles';
import { Text } from '@radix-ui/themes';
import { Fragment, useRef } from 'react';
import type { ContextMenuProps } from './types.ts';
import { useOutsideClick } from '../../hooks/useOutsideClick';

export const PositionalContextMenu = ({
  menuPosition,
  isMenuOpen,
  setIsMenuOpen,
  menuItems,
  title,
  closeAfterClick = true,
}: ContextMenuProps) => {
  const contextMenuRef = useRef(null);
  useOutsideClick(contextMenuRef, () => {
    setIsMenuOpen(false);
  });

  return (
    <>
      {isMenuOpen && (
        <Container
          className="menu"
          x={menuPosition.x}
          y={menuPosition.y}
          ref={contextMenuRef}
        >
          {title && <Text className="menu-title">{title}</Text>}
          {menuItems?.map((item) => {
            return (
              <Fragment key={item.id}>
                <MenuItem
                  disabled={item.disabled}
                  onClick={(
                    e: React.MouseEvent<HTMLSpanElement, MouseEvent>,
                  ) => {
                    if (item.onClick && item.disabled !== true) {
                      item.onClick(e);
                      if (closeAfterClick) {
                        setIsMenuOpen(false);
                      }
                    }
                  }}
                >
                  {item.title}
                </MenuItem>
                {item.withSeparateLine && (
                  <div className="separator-line"></div>
                )}
              </Fragment>
            );
          })}
        </Container>
      )}
    </>
  );
};
