import styled, { css } from 'styled-components';
import { Text } from '@radix-ui/themes';

const _Container = css`
  padding: 5px;
  border-radius: 5px;
  background-color: #1f1f1f;
  width: 100px;
  justify-content: center;
  align-items: center;
  display: flex;
  z-index: 1000;
  text-align: center;
  flex-direction: column;
  position: absolute;
  box-shadow: ${({ theme }) => theme.shadows.shadow3};
  > .menu-title {
    font-weight: 600;
    color: white;
    border-bottom: 1px solid #5e5e5e;
    margin-bottom: 5px;
    width: 100%;
  }
  > .separator-line {
    border-top: 1px solid #5e5e5e;
    width: 100%;
    margin-top: 1px;
    margin-bottom: 1px;
  }
`;

const _MenuItem = css`
  width: 95%;
  margin-bottom: 1px;
  margin-top: 1px;
  color: white;
  &:hover {
    background-color: #363635;
  }
`;

export const Container = styled.div<{
  y: number;
  x: number;
}>`
  ${_Container}
  top: ${({ y }) => y}px;
  left: ${({ x }) => x}px;
`;
export const MenuItem = styled(Text)<{ disabled?: boolean }>`
  ${_MenuItem}
`;
