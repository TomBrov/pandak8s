export const FORM_NEW_USER = 'יצירת משתמש חדש';
export const FORM_TITLE = 'יצירת משתמש';
export const ON_ERROR_MSG_CREATE = 'יצירת משתמש נכשלה';
export const ON_SUCCESS_MSG_CREATE = 'משתמש נוצר בהצלחה';
export const BUTTON_TEXT = 'יצירת משתמש חדש';
export const FORM_SUBMIT_BTN_CREATE = 'יצירת משתמש';
