import { Button, Separator } from '@radix-ui/themes';

import { FC, useState } from 'react';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '../../../Sheet';
import {
  BUTTON_TEXT,
  FORM_NEW_USER,
  FORM_TITLE,
  ON_ERROR_MSG_CREATE,
  ON_SUCCESS_MSG_CREATE,
} from './CreateUser.constants';
import { useToastStore } from '../../../../store/ToastStore';
import * as styles from './styles';
import styled from 'styled-components';
import { CreateUserFormComponent } from '../../UserManagement';

type CreateUserButtonUIProps = {
  CreateUserForm: CreateUserFormComponent;
};

const SheetContainer = styled.div`
  ${styles.Container}
`;

const CreateUserButtonUI: FC<CreateUserButtonUIProps> = ({
  CreateUserForm,
}) => {
  const [sheetOpen, setSheetOpen] = useState(false);
  const { addCallout } = useToastStore();

  const onSuccess = () => {
    setSheetOpen(false);
    addCallout({ message: ON_SUCCESS_MSG_CREATE, color: 'green' });
  };

  const onError = () => {
    setSheetOpen(false);
    addCallout({ message: ON_ERROR_MSG_CREATE, color: 'red' });
  };
  return (
    <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
      <SheetContainer>
        <SheetTrigger>
          <Button variant="solid" className="create-user-button">
            {BUTTON_TEXT}
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="sheet-content">
          <SheetHeader>
            <SheetTitle>{FORM_TITLE}</SheetTitle>
            <SheetDescription>{FORM_NEW_USER}</SheetDescription>
          </SheetHeader>
          <Separator my="5" size="4" />
          <CreateUserForm onSuccess={onSuccess} onError={onError} />
        </SheetContent>
      </SheetContainer>
    </Sheet>
  );
};

interface CreateUserButtonProps {
  CreateUserForm: CreateUserFormComponent;
}

export const CreateUserButton: FC<CreateUserButtonProps> = ({
  CreateUserForm,
}) => {
  return <CreateUserButtonUI CreateUserForm={CreateUserForm} />;
};
