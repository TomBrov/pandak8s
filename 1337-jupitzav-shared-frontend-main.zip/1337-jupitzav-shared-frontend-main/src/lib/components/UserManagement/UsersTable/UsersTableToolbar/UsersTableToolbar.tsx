import { Cross2Icon } from '@radix-ui/react-icons';
import { Table } from '@tanstack/react-table';
import {
  Flex,
  Button as RadixButton,
  Separator,
  TextField,
} from '@radix-ui/themes';
import { DataTableViewOptions } from '../../../DataTable/DataTablViewOptions/DataTablViewOptions';
import { CLEAN_FILTERS } from '../../../DataTable/DataTable.constants';
import { CreateUserButton } from '../CreateUser/CreateUserButton';
import * as styles from './styles';
import styled from 'styled-components';
import { CreateUserFormComponent } from '../../UserManagement';
import { SEARCH_PLACEHOLDER } from '../../UsersMangement.constants';

interface UsersTableToolbarProps<TData> {
  table: Table<TData>;
  CreateUserForm: CreateUserFormComponent;
  getColNameByAccessorKey: (accessorKey: string) => string;
}

const InputContainer = styled.div`
  ${styles.InputContainer}
`;

const Input = styled(TextField.Input)`
  ${styles.Input}
`;

const Button = styled(RadixButton)`
  margin-right: 0.5rem;
`;

const Icon = styled(Cross2Icon)`
  height: 1rem;
  width: 1rem;
`;

const Container = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

export function UsersTableToolbar<TData>({
  table,
  CreateUserForm,
  getColNameByAccessorKey,
}: UsersTableToolbarProps<TData>) {
  const isFiltered = table.getState().columnFilters.length > 0;
  return (
    <Flex align={'center'} justify={'between'} dir="rtl">
      <InputContainer>
        <Input
          placeholder={SEARCH_PLACEHOLDER}
          value={(table.getColumn('name')?.getFilterValue() as string) ?? ''}
          onChange={(event) =>
            table.getColumn('name')?.setFilterValue(event.target.value)
          }
        />
        {isFiltered && (
          <Button variant="ghost" onClick={() => table.resetColumnFilters()}>
            <Icon />
            {CLEAN_FILTERS}
          </Button>
        )}
      </InputContainer>
      <Container>
        <DataTableViewOptions
          table={table}
          getColNameByAccessorKey={getColNameByAccessorKey}
        />
        <Separator orientation="vertical" />
        <CreateUserButton CreateUserForm={CreateUserForm} />
      </Container>
    </Flex>
  );
}
