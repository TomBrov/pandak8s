import { css } from 'styled-components';

export const InputContainer = css`
  display: flex;
  flex: 1;
  align-items: center;
  margin-left: 0.75rem;
`;

export const Input = css`
  height: 2rem;
  width: 150px;
  @media (min-width: 1024px) {
    width: 250px;
  }
`;
