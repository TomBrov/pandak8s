import * as React from 'react';
import {
  ColumnDef,
  ColumnFiltersState,
  ColumnOrderState,
  SortingState,
  VisibilityState,
  getCoreRowModel,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from '@tanstack/react-table';
import { DataTablePagination } from '../../DataTable/DataTablePagination';
import { UsersTableToolbar } from './UsersTableToolbar/UsersTableToolbar';
import { DataTable } from '../../DataTable/DataTable';
import styled from 'styled-components';
import { CreateUserFormComponent } from '../UserManagement';

interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
  CreateUserForm: CreateUserFormComponent;
  getColNameByAccessorKey: (accessorKey: string) => string;
  columnOrder: ColumnOrderState;
}

const Container = styled.div`
  > * {
    margin-top: 1rem;
  }
`;

export function UsersTable<TData, TValue>({
  columns,
  data,
  CreateUserForm,
  getColNameByAccessorKey,
  columnOrder,
}: DataTableProps<TData, TValue>) {
  const [rowSelection, setRowSelection] = React.useState({});
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({});
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
    [],
  );
  const [sorting, setSorting] = React.useState<SortingState>([]);

  const table = useReactTable({
    data,
    columns: columns,
    state: {
      sorting,
      columnVisibility,
      rowSelection,
      columnFilters,
      columnOrder,
    },
    enableRowSelection: false,
    onRowSelectionChange: setRowSelection,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onColumnVisibilityChange: setColumnVisibility,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
  });

  return (
    <Container>
      <UsersTableToolbar
        CreateUserForm={CreateUserForm}
        table={table}
        getColNameByAccessorKey={getColNameByAccessorKey}
      />
      <DataTable table={table} columnsLength={columns?.length} />
      <DataTablePagination table={table} />
    </Container>
  );
}
