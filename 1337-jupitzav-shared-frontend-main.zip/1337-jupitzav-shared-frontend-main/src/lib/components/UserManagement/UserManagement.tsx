import { Flex } from '@radix-ui/themes';
import { Loading } from '@geist-ui/core';
import { UsersTable } from './UsersTable/UsersTable';
import { ColumnDef, ColumnOrderState } from '@tanstack/react-table';

export type CreateUserFormComponent = React.ComponentType<{
  onError: () => void;
  onSuccess: () => void;
}>;

export type UserColumn<T> = ColumnDef<T> & {
  accessorKey: string;
};
interface UserManagementProps<T> {
  data: T[];
  isLoading: boolean;
  isError: boolean;
  CreateUserForm: CreateUserFormComponent;
  columns: UserColumn<T>[];
  getColNameByAccessorKey: (accessorKey: string) => string;
  columnOrder: ColumnOrderState;
}

const UserManagement = <T,>({
  data,
  isError,
  isLoading,
  CreateUserForm,
  columns,
  getColNameByAccessorKey,
  columnOrder,
}: UserManagementProps<T>) => {
  if (isLoading) {
    return <Loading type="success" />;
  }

  if (isError) {
    return <p>Error loading users</p>;
  }
  return (
    <Flex direction="column" gap="7">
      <Flex direction="column" dir="rtl" gap="3">
        <UsersTable
          data={data}
          columns={columns}
          CreateUserForm={CreateUserForm}
          getColNameByAccessorKey={getColNameByAccessorKey}
          columnOrder={columnOrder}
        />
      </Flex>
    </Flex>
  );
};

export default UserManagement;
