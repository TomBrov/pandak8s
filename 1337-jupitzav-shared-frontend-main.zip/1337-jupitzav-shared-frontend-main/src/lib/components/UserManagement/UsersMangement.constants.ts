export const SEARCH_PLACEHOLDER = 'חיפוש לפי שם';
