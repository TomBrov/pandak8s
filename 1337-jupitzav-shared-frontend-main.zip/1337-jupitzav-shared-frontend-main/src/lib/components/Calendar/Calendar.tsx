import DatePicker, {
  type DatePickerProps,
  registerLocale,
} from 'react-datepicker';

import 'react-datepicker/dist/react-datepicker.css';

import { Flex, IconButton } from '@radix-ui/themes';
import { ChevronLeftIcon, ChevronRightIcon } from '@radix-ui/react-icons';
import styled from 'styled-components';
import { he } from 'date-fns/locale/he';

registerLocale('he', he);

const StyledFlex = styled(Flex)`
  padding-inline: var(--space-3);
`;

const CalendarHeader: DatePickerProps['renderCustomHeader'] = ({
  date,
  decreaseMonth,
  increaseMonth,
}) => {
  return (
    <StyledFlex justify="between" align="center">
      <IconButton size="1" onClick={decreaseMonth} aria-label="חודש קודם">
        <ChevronRightIcon />
      </IconButton>
      <div>
        {date.toLocaleDateString('he-IL', {
          month: 'long',
          year: 'numeric',
        })}
      </div>
      <IconButton size="1" onClick={increaseMonth} aria-label="חודש הבא">
        <ChevronLeftIcon />
      </IconButton>
    </StyledFlex>
  );
};

export function Calendar({ date, ...rest }: DatePickerProps) {
  return (
    <DatePicker
      renderCustomHeader={CalendarHeader}
      locale="he"
      inline
      date={date}
      selected={date}
      minDate={new Date('2021-01-01')}
      maxDate={new Date()}
      {...rest}
    />
  );
}
