import styled from 'styled-components';
import { Flex } from '@radix-ui/themes';

export const StyledDatePicker = styled.div`
  display: grid;
  grid-template-columns: auto auto;
  grid-template-rows: 1fr auto;
  gap: 1rem;
`;

export const StyledShortcuts = styled(Flex)`
  grid-row: 1 / -1;
`;
