type ChangeHandler = (args: { fromDate?: number; toDate?: number }) => void;

export type PickerProps = {
  label?: string;
  placeholder?: string;
  fromDate?: number;
  toDate?: number;
  onChange?: ChangeHandler;
  Panel?: (props: { onPreset: ChangeHandler }) => JSX.Element;
};
