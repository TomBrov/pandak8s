import { Button, Flex } from '@radix-ui/themes';
import { Meta, StoryObj } from '@storybook/react';
import React from 'react';
import { DatesRangeSelect } from './DatesRangeSelect';

type DateRange = {
  fromDate?: number;
  toDate?: number;
};

const meta: Meta<typeof DatesRangeSelect> = {
  title: 'Components/DateRangeSelect',
  component: DatesRangeSelect,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof DatesRangeSelect>;

export const Default: Story = {
  args: {
    label: 'Select Date Range',
    placeholder: 'Choose dates',
  },
};

export const WithPresetDates: Story = {
  args: {
    label: 'Date Range',
    placeholder: 'Choose dates',
    fromDate: new Date('2023-05-10').getTime(),
    toDate: new Date('2023-05-20').getTime(),
  },
};

const CustomPanel = ({
  onPreset,
}: {
  onPreset: (dates: DateRange) => void;
}) => (
  <Flex direction="column" gap="2">
    <Button
      onClick={() =>
        onPreset({
          fromDate: new Date('2023-05-01').getTime(),
          toDate: new Date('2023-05-07').getTime(),
        })
      }
    >
      This Week
    </Button>
    <Button
      onClick={() =>
        onPreset({
          fromDate: new Date('2023-05-01').getTime(),
          toDate: new Date('2023-05-31').getTime(),
        })
      }
    >
      This Month
    </Button>
  </Flex>
);

export const WithCustomPanel: Story = {
  args: {
    label: 'Date Range with Shortcuts',
    placeholder: 'Choose dates',
    Panel: CustomPanel,
  },
};

export const Controlled: Story = {
  render: ControlledStory,
};

function ControlledStory() {
  const [dateRange, setDateRange] = React.useState<DateRange>({
    fromDate: new Date('2023-05-01').getTime(),
    toDate: new Date('2023-05-31').getTime(),
  });

  return (
    <DatesRangeSelect
      label="Controlled Date Range"
      placeholder="Choose dates"
      fromDate={dateRange.fromDate}
      toDate={dateRange.toDate}
      onChange={setDateRange}
    />
  );
}
