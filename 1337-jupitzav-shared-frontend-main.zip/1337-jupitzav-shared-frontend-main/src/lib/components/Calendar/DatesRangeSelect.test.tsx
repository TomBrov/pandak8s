import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { DatesRangeSelect } from './DatesRangeSelect';
import type { PickerProps } from './DatesRangeSelect.types';
import { useId } from 'react';

beforeEach(() => {
  const now = new Date('2022-01-01T00:00:00Z');
  jest.useFakeTimers({ advanceTimers: true, now });
});

afterEach(() => {
  jest.runAllTimers();
  jest.useRealTimers();
});

test('picking dates', async () => {
  const onChange = jest.fn();
  render(
    <DatesRangeSelect
      label="select"
      placeholder="select dates"
      onChange={onChange}
    />,
  );
  await userEvent.click(screen.getByText(/select dates/i));
  await userEvent.click(
    screen.getAllByRole('button', {
      name: 'חודש קודם',
    })[0] as HTMLButtonElement,
  );

  await userEvent.click(
    screen.getAllByRole('button', {
      name: 'חודש קודם',
    })[0] as HTMLButtonElement,
  );

  await userEvent.click(
    screen.getAllByRole('button', {
      name: 'חודש קודם',
    })[1] as HTMLButtonElement,
  );

  const [novemberOption, decemberOption] = screen.getAllByRole('option', {
    name: /23/,
  });
  await userEvent.click(novemberOption as HTMLButtonElement);
  await userEvent.click(decemberOption as HTMLButtonElement);
  await userEvent.click(screen.getByRole('button', { name: 'אישור' }));

  expect(onChange).toHaveBeenCalledTimes(1);
  const expectedFrom = new Date('2021-11-23T00:00:00Z');
  expectedFrom.setMinutes(expectedFrom.getTimezoneOffset());
  const expectedTo = new Date('2021-12-23T00:00:00Z');
  expectedTo.setMinutes(expectedTo.getTimezoneOffset());
  expect(onChange).toHaveBeenCalledWith({
    fromDate: expectedFrom.getTime(),
    toDate: expectedTo.getTime(),
  });
});

test(`showing selections on the opener`, async () => {
  const from = new Date('2022-01-03T11:00:00Z');
  const to = new Date('2022-01-04T11:00:00Z');
  render(
    <DatesRangeSelect
      fromDate={from.getTime()}
      toDate={to.getTime()}
      label="select"
      placeholder="select dates"
    />,
  );
  expect(
    screen.getByRole('button', { name: /03\.01\.2022/i }),
  ).toBeInTheDocument();
});

test(`allow rendering panel for quick selections`, async () => {
  const onChange = jest.fn();
  const expectedFrom = new Date('2020-01-02T11:00:00.000Z');
  const expectedTo = new Date('2020-01-03T11:00:00.000Z');

  const Panel: PickerProps['Panel'] = ({ onPreset }) => {
    const headingId = useId();

    return (
      <section aria-labelledby={headingId}>
        <h2 id={headingId}>the panel</h2>
        <button
          onClick={() =>
            onPreset({
              fromDate: expectedFrom.getTime(),
              toDate: expectedTo.getTime(),
            })
          }
        >
          Today
        </button>
      </section>
    );
  };

  render(
    <DatesRangeSelect
      label="select"
      placeholder="select dates"
      onChange={onChange}
      Panel={Panel}
    />,
  );

  await userEvent.click(screen.getByRole('button', { name: /select dates/i }));
  await userEvent.click(
    within(screen.getByRole('region', { name: /the panel/i })).getByRole(
      'button',
      { name: /today/i },
    ),
  );
  await userEvent.click(screen.getByRole('button', { name: /אישור/i }));

  expect(onChange).toHaveBeenCalledTimes(1);
  expect(onChange).toHaveBeenCalledWith({
    fromDate: expectedFrom.getTime(),
    toDate: expectedTo.getTime(),
  });
});
