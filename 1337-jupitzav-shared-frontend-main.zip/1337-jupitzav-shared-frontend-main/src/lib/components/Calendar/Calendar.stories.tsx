import { Meta, StoryObj } from '@storybook/react';
import { Calendar } from './Calendar';

const meta: Meta<typeof Calendar> = {
  title: 'Components/Calendar',
  component: Calendar,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Calendar>;

export const Default: Story = {
  args: {
    date: new Date(),
  },
};

export const WithSelectedDate: Story = {
  args: {
    date: new Date('2023-05-15'),
  },
};

export const WithDateRange: Story = {
  args: {
    selectsRange: true,
    startDate: new Date('2023-05-10'),
    endDate: new Date('2023-05-20'),
  },
};

export const WithCustomDateFormat: Story = {
  args: {
    date: new Date(),
    dateFormat: 'dd/MM/yyyy',
  },
};

export const Disabled: Story = {
  args: {
    date: new Date(),
    disabled: true,
  },
};
