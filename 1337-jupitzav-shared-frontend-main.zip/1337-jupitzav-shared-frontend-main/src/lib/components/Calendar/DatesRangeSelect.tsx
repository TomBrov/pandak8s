import { type ChangeEvent, useState } from 'react';
import { Button, Flex, TextField } from '@radix-ui/themes';
import { ChevronDownIcon } from '@radix-ui/react-icons';
import { Calendar } from './Calendar.tsx';
import { dateToTime, formatSelectedDates } from '../../utils/dates.ts';
import { StyledPopover } from '../StyledPopover.tsx';
import {
  StyledDatePicker,
  StyledShortcuts,
} from './DatesRangeSelect.style.tsx';
import type { PickerProps } from './DatesRangeSelect.types.ts';

const dateFields = ['fromDate', 'toDate'] as const;

export function DatesRangeSelect({
  label,
  placeholder = '',
  fromDate,
  toDate,
  onChange,
  Panel,
}: PickerProps) {
  const [dates, setDates] = useState<Pick<PickerProps, 'fromDate' | 'toDate'>>({
    fromDate,
    toDate,
  });

  return (
    <Flex gap="1" align="center">
      {label ? <label>{label}</label> : null}
      <StyledPopover.Root>
        <StyledPopover.Trigger dir="rtl">
          <Button variant="outline" className="button-dropdown">
            {formatSelectedDates({
              fromDate,
              toDate,
              fallback: placeholder,
            })}
            <ChevronDownIcon className="icon" />
          </Button>
        </StyledPopover.Trigger>
        <StyledPopover.Content width="auto">
          <StyledDatePicker>
            {Panel ? (
              <StyledShortcuts direction="column" gap="2">
                <Panel
                  onPreset={(dates) =>
                    'fromDate' in dates && 'toDate' in dates
                      ? setDates(dates)
                      : null
                  }
                />
              </StyledShortcuts>
            ) : null}
            <Flex gap="1">
              {dateFields.map((fieldName) => (
                <PickerItem
                  key={fieldName}
                  fieldName={fieldName}
                  {...dates}
                  onChange={(updates) => {
                    setDates((prev) => ({ ...prev, ...updates }));
                  }}
                />
              ))}
            </Flex>
            <Flex justify="end" gap="1">
              <StyledPopover.Close>
                <Button variant="soft">ביטול</Button>
              </StyledPopover.Close>
              <StyledPopover.Close>
                <Button onClick={() => onChange?.(dates)}>אישור</Button>
              </StyledPopover.Close>
            </Flex>
          </StyledDatePicker>
        </StyledPopover.Content>
      </StyledPopover.Root>
    </Flex>
  );
}

function PickerItem({
  fieldName,
  onChange,
  ...dates
}: Pick<PickerProps, 'fromDate' | 'toDate'> & {
  fieldName: (typeof dateFields)[number];
  onChange: (dates: Pick<PickerProps, 'fromDate' | 'toDate'>) => void;
}) {
  function handleTimeChange(
    event: ChangeEvent<HTMLInputElement>,
    fieldName: 'fromDate' | 'toDate',
  ) {
    const [hours, minutes] = event.target.value.split(':');
    const combineWithTime = new Date(dates[fieldName] || Date.now());
    combineWithTime.setHours(Number(hours), Number(minutes));
    onChange({
      [fieldName]: combineWithTime,
    });
  }

  const minMaxProps =
    fieldName === 'fromDate' && dates.toDate
      ? { maxDate: new Date(dates.toDate) }
      : dates.fromDate
        ? { minDate: new Date(dates.fromDate) }
        : {};

  return (
    <Flex direction="column" gap="2" key={fieldName}>
      <Calendar
        name={fieldName}
        date={dates[fieldName] ? new Date(dates[fieldName]) : undefined}
        onChange={(selection) =>
          onChange({
            [fieldName]: selection?.getTime(),
          })
        }
        {...minMaxProps}
      />
      <TextField.Input
        className="time-picker"
        type="time"
        value={dates[fieldName] ? dateToTime(new Date(dates[fieldName])) : ''}
        onChange={(event) => handleTimeChange(event, fieldName)}
      />
    </Flex>
  );
}
