import styled from 'styled-components';
import { Popover } from '@radix-ui/themes';

type StyledPopoverContentProps = {
  width?: string;
};

const StyledPopoverContent = styled(Popover.Content)<StyledPopoverContentProps>`
  // Note: the normal className not working, so I use StyledPopoverContent instead
  width: ${({ width }) => width || '360px'} !important;
  /* Note: we remove the animation to fix the ui jump in radix theme popover component */
  /* for more info you can see the source code here: https://github.com/radix-ui/themes/blob/eb8566b36f811e7e260c07340bfe6a49ea81054d/packages/radix-ui-themes/src/components/popover.tsx */
  animation-name: none;
  animation: none;
`;

export const StyledPopover = {
  Root: Popover.Root,
  Content: StyledPopoverContent,
  Trigger: Popover.Trigger,
  Close: Popover.Close,
};
