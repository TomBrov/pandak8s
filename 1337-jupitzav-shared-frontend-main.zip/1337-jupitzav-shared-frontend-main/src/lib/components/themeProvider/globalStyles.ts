import { createGlobalStyle } from 'styled-components';

export const GlobalStyles = createGlobalStyle`
  @font-face {
    font-family: 'SpaceMono';
    src: url('/fonts/SpaceMono-Regular.ttf') format('truetype');
    font-weight: normal;
    font-style: normal;
  }

  @font-face {
    font-family: 'NotoSansHebrew';
    src: url('/fonts/NotoSansHebrew-Regular.ttf') format('truetype');
    font-weight: normal;
    font-style: normal;
  }

  @font-face {
    font-family: 'OCR-A';
    src: url('/fonts/OCR-A Regular.ttf') format('truetype');
    font-weight: normal;
    font-style: normal;
  }

  *,
  *::before,
  *::after {
    box-sizing: border-box;
    font-family: var(--default-font-family);
  }

  html,
  body,
  #root {
    height: 100%;
    margin: 0;
    padding: 0;

    /* custom scrollbar */
    ::-webkit-scrollbar {
      background-color: transparent;
    }

    ::-webkit-scrollbar-thumb {
      border-radius: 20px;
      border: 6px solid transparent;
      background-clip: content-box;
      background-color: #a8bbbf;
    }

    ::-webkit-scrollbar-thumb:hover {
      background-color: #d6dee1;
    }

    ::-webkit-scrollbar-corner {
      background: transparent;
    }
  }

  body.cursor-move {
    cursor: move;
  }

  p, h1, h2, h3, h4, h5, h6 {
    margin: 0;
  }

  #root {
    background-image: url('/src/assets/background-light.svg');
    /* this color is pink3 with opacity: */
    background-color: #37172fab;
    overflow: hidden;
  }

  .radix-themes {
    height: 100%;
    width: 100%;
    display: flex;
    flex-direction: column;
  }

  .leaflet-editing-icon {
    border-radius: 50%;
  }

  .leaflet-tooltip {
    position: relative;
    &:before {
        content: none;
      }
    }

  .leaflet-draw-section {
  display: none;
  }
  /* Dropdown component: */
  .rt-DropdownMenuContent, .rt-ContextMenuItem {
    background-color: ${({ theme }) => theme.colors.sidebarBackground};
  }

  .rt-DropdownMenuItem, .rt-ContextMenuItem {
    direction: rtl;
    cursor: pointer;

    &:hover {
      background-color: ${({ theme }) => theme.colors.highlight};
    }
  }

  /* changing cursors for interactive elements */
  .radix-themes {
    --cursor-button: pointer;
    --cursor-checkbox: pointer;
    --cursor-disabled: default;
    --cursor-link: pointer;
    --cursor-menu-item: pointer;
    --cursor-radio: pointer;
    --cursor-slider-thumb: grab;
    --cursor-slider-thumb-active: grabbing;
    --cursor-switch: pointer;
    --color-panel-solid: ${({ theme }) => theme.colors.pinkDark.pink2};
  }
  /* fixing icon button ghost margin */

  .rt-IconButton:where(.rt-variant-ghost) {
    margin: 0;
  }

  .pink-title {
    color: ${({ theme }) => theme.colors.primary};
    font-size: 18px;
    font-weight: bold;
  }

  /* for transparent background in the radix dialogs */
  .rt-DialogOverlay::after {
    background-color: transparent;
  }

  input[type^="date"]::-webkit-calendar-picker-indicator {
      background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0id2hpdGUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0iTTQuNSAxQzQuNzc2MTQgMSA1IDEuMjIzODYgNSAxLjVWMkgxMFYxLjVDMTAgMS4yMjM4NiAxMC4yMjM5IDEgMTAuNSAxQzEwLjc3NjEgMSAxMSAxLjIyMzg2IDExIDEuNVYySDEyLjVDMTMuMzI4NCAyIDE0IDIuNjcxNTcgMTQgMy41VjEyLjVDMTQgMTMuMzI4NCAxMy4zMjg0IDE0IDEyLjUgMTRIMi41QzEuNjcxNTcgMTQgMSAxMy4zMjg0IDEgMTIuNVYzLjVDMSAyLjY3MTU3IDEuNjcxNTcgMiAyLjUgMkg0VjEuNUM0IDEuMjIzODYgNC4yMjM4NiAxIDQuNSAxWk0xMCAzVjMuNUMxMCAzLjc3NjE0IDEwLjIyMzkgNCAxMC41IDRDMTAuNzc2MSA0IDExIDMuNzc2MTQgMTEgMy41VjNIMTIuNUMxMi43NzYxIDMgMTMgMy4yMjM4NiAxMyAzLjVWNUgyVjMuNUMyIDMuMjIzODYgMi4yMjM4NiAzIDIuNSAzSDRWMy41QzQgMy43NzYxNCA0LjIyMzg2IDQgNC41IDRDNC43NzYxNCA0IDUgMy43NzYxNCA1IDMuNVYzSDEwWk0yIDZWMTIuNUMyIDEyLjc3NjEgMi4yMjM4NiAxMyAyLjUgMTNIMTIuNUMxMi43NzYxIDEzIDEzIDEyLjc3NjEgMTMgMTIuNVY2SDJaTTcgNy41QzcgNy4yMjM4NiA3LjIyMzg2IDcgNy41IDdDNy43NzYxNCA3IDggNy4yMjM4NiA4IDcuNUM4IDcuNzc2MTQgNy43NzYxNCA4IDcuNSA4QzcuMjIzODYgOCA3IDcuNzc2MTQgNyA3LjVaTTkuNSA3QzkuMjIzODYgNyA5IDcuMjIzODYgOSA3LjVDOSA3Ljc3NjE0IDkuMjIzODYgOCA5LjUgOEM5Ljc3NjE0IDggMTAgNy43NzYxNCAxMCA3LjVDMTAgNy4yMjM4NiA5Ljc3NjE0IDcgOS41IDdaTTExIDcuNUMxMSA3LjIyMzg2IDExLjIyMzkgNyAxMS41IDdDMTEuNzc2MSA3IDEyIDcuMjIzODYgMTIgNy41QzEyIDcuNzc2MTQgMTEuNzc2MSA4IDExLjUgOEMxMS4yMjM5IDggMTEgNy43NzYxNCAxMSA3LjVaTTExLjUgOUMxMS4yMjM5IDkgMTEgOS4yMjM4NiAxMSA5LjVDMTEgOS43NzYxNCAxMS4yMjM5IDEwIDExLjUgMTBDMTEuNzc2MSAxMCAxMiA5Ljc3NjE0IDEyIDkuNUMxMiA5LjIyMzg2IDExLjc3NjEgOSAxMS41IDlaTTkgOS41QzkgOS4yMjM4NiA5LjIyMzg2IDkgOS41IDlDOS43NzYxNCA5IDEwIDkuMjIzODYgMTAgOS41QzEwIDkuNzc2MTQgOS43NzYxNCAxMCA5LjUgMTBDOS4yMjM4NiAxMCA5IDkuNzc2MTQgOSA5LjVaTTcuNSA5QzcuMjIzODYgOSA3IDkuMjIzODYgNyA5LjVDNyA5Ljc3NjE0IDcuMjIzODYgMTAgNy41IDEwQzcuNzc2MTQgMTAgOCA5Ljc3NjE0IDggOS41QzggOS4yMjM4NiA3Ljc3NjE0IDkgNy41IDlaTTUgOS41QzUgOS4yMjM4NiA1LjIyMzg2IDkgNS41IDlDNS43NzYxNCA5IDYgOS4yMjM4NiA2IDkuNUM2IDkuNzc2MTQgNS43NzYxNCAxMCA1LjUgMTBDNS4yMjM4NiAxMCA1IDkuNzc2MTQgNSA5LjVaTTMuNSA5QzMuMjIzODYgOSAzIDkuMjIzODYgMyA5LjVDMyA5Ljc3NjE0IDMuMjIzODYgMTAgMy41IDEwQzMuNzc2MTQgMTAgNCA5Ljc3NjE0IDQgOS41QzQgOS4yMjM4NiAzLjc3NjE0IDkgMy41IDlaTTMgMTEuNUMzIDExLjIyMzkgMy4yMjM4NiAxMSAzLjUgMTFDMy43NzYxNCAxMSA0IDExLjIyMzkgNCAxMS41QzQgMTEuNzc2MSAzLjc3NjE0IDEyIDMuNSAxMkMzLjIyMzg2IDEyIDMgMTEuNzc2MSAzIDExLjVaTTUuNSAxMUM1LjIyMzg2IDExIDUgMTEuMjIzOSA1IDExLjVDNSAxMS43NzYxIDUuMjIzODYgMTIgNS41IDEyQzUuNzc2MTQgMTIgNiAxMS43NzYxIDYgMTEuNUM2IDExLjIyMzkgNS43NzYxNCAxMSA1LjUgMTFaTTcgMTEuNUM3IDExLjIyMzkgNy4yMjM4NiAxMSA3LjUgMTFDNy43NzYxNCAxMSA4IDExLjIyMzkgOCAxMS41QzggMTEuNzc2MSA3Ljc3NjE0IDEyIDcuNSAxMkM3LjIyMzg2IDEyIDcgMTEuNzc2MSA3IDExLjVaTTkuNSAxMUM5LjIyMzg2IDExIDkgMTEuMjIzOSA5IDExLjVDOSAxMS43NzYxIDkuMjIzODYgMTIgOS41IDEyQzkuNzc2MTQgMTIgMTAgMTEuNzc2MSAxMCAxMS41QzEwIDExLjIyMzkgOS43NzYxNCAxMSA5LjUgMTFaIiAvPjwvc3ZnPg==');
  }
  input[type^="time"]::-webkit-calendar-picker-indicator {
      background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0id2hpdGUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0iTTcuNTAwMDkgMC44NzcwMTRDMy44NDI0MSAwLjg3NzAxNCAwLjg3NzI1OCAzLjg0MjE2IDAuODc3MjU4IDcuNDk5ODRDMC44NzcyNTggMTEuMTU3NSAzLjg0MjQgMTQuMTIyNyA3LjUwMDA5IDE0LjEyMjdDMTEuMTU3OCAxNC4xMjI3IDE0LjEyMjkgMTEuMTU3NSAxNC4xMjI5IDcuNDk5ODRDMTQuMTIyOSAzLjg0MjE2IDExLjE1NzcgMC44NzcwMTQgNy41MDAwOSAwLjg3NzAxNFpNMS44MjcyNiA3LjQ5OTg0QzEuODI3MjYgNC4zNjY4MyA0LjM2NzA4IDEuODI3MDEgNy41MDAwOSAxLjgyNzAxQzEwLjYzMzEgMS44MjcwMSAxMy4xNzI5IDQuMzY2ODMgMTMuMTcyOSA3LjQ5OTg0QzEzLjE3MjkgMTAuNjMyOCAxMC42MzMxIDEzLjE3MjcgNy41MDAwOSAxMy4xNzI3QzQuMzY3MDggMTMuMTcyNyAxLjgyNzI2IDEwLjYzMjggMS44MjcyNiA3LjQ5OTg0Wk04IDQuNTAwMDFDOCA0LjIyMzg3IDcuNzc2MTQgNC4wMDAwMSA3LjUgNC4wMDAwMUM3LjIyMzg2IDQuMDAwMDEgNyA0LjIyMzg3IDcgNC41MDAwMVY3LjUwMDAxQzcgNy42MzI2MiA3LjA1MjY4IDcuNzU5OCA3LjE0NjQ1IDcuODUzNTdMOS4xNDY0NSA5Ljg1MzU3QzkuMzQxNzEgMTAuMDQ4OCA5LjY1ODI5IDEwLjA0ODggOS44NTM1NSA5Ljg1MzU3QzEwLjA0ODggOS42NTgzMSAxMC4wNDg4IDkuMzQxNzIgOS44NTM1NSA5LjE0NjQ2TDggNy4yOTI5MVY0LjUwMDAxWiIgLz48L3N2Zz4=');
  }

`;
