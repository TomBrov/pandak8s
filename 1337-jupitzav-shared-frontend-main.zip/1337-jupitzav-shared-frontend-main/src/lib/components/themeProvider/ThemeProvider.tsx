import { pinkDarkA } from '@radix-ui/colors';
import { Theme } from '@radix-ui/themes';
import merge from 'lodash.merge';
import { PropsWithChildren } from 'react';
import { ThemeProvider as StyledThemeProvider } from 'styled-components';
import { defaultTheme } from '../../theme';
import { GlobalStyles } from './globalStyles.ts';

type ThemeProviderProps = PropsWithChildren<{}>;
export function ThemeProvider({ children }: ThemeProviderProps) {
  const jupiterTheme = merge(defaultTheme, {
    table: {
      tableBg: '#4a0041',
      containerBg: pinkDarkA,
    },
  });

  return (
    <Theme
      accentColor="pink"
      grayColor="sand"
      radius="large"
      scaling="100%"
      appearance="inherit"
    >
      <StyledThemeProvider theme={jupiterTheme}>
        <GlobalStyles />
        {children}
      </StyledThemeProvider>
    </Theme>
  );
}
