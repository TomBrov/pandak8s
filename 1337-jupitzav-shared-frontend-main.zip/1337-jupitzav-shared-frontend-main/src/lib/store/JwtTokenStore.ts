const jwtTokenStorageKeyName = 'jwtToken';

export const getJwtToken = () => {
  return localStorage.getItem(jwtTokenStorageKeyName);
};

export const setJwtToken = (jwtToken: string) => {
  localStorage.setItem(jwtTokenStorageKeyName, jwtToken);
};
