import { create } from 'zustand';
import { devtools } from 'zustand/middleware';

type Callout = {
  message: string;
  isShowed: boolean;
  variant?: 'soft' | 'surface' | 'outline';
  size?: '1' | '2' | '3';
  color?: 'green' | 'red' | 'blue' | 'yellow' | 'purple' | 'orange';
  role?: 'info' | 'alert';
};
interface ToastState {
  callouts: Callout[];
  showAlert: boolean;
}

export interface CalloutProps {
  message: string;
  variant?: 'soft' | 'surface' | 'outline';
  size?: '1' | '2' | '3';
  color?: 'green' | 'red' | 'blue' | 'yellow' | 'purple' | 'orange';
  role?: 'info' | 'alert';
}

interface ToastStore extends ToastState {
  addCallout: (calloutProps: CalloutProps) => void;
  removeCallout: (index: number) => void;
  toggleAlert: () => void;
  clearCallouts: () => void;
}

export const useToastStore = create<ToastStore>()(
  devtools(
    (set) => ({
      callouts: [],
      showAlert: false,
      addCallout: (calloutProps: CalloutProps) =>
        set((state) => ({
          callouts: [
            ...state.callouts,
            {
              ...calloutProps,
              isShowed: true,
            },
          ],
        })),
      removeCallout: (index) =>
        set((state) => ({
          callouts: state.callouts.filter((_, i) => i !== index),
        })),
      toggleAlert: () => set((state) => ({ showAlert: !state.showAlert })),
      clearCallouts: () => set({ callouts: [], showAlert: false }),
    }),
    { name: 'CalloutStore' },
  ),
);
