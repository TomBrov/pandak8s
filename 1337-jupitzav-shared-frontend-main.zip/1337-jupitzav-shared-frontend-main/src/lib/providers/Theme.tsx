import { Theme as RadixTheme } from '@radix-ui/themes';
import type { ThemeProps } from 'node_modules/@radix-ui/themes/dist/esm/theme';

export const Theme = ({
  children,
  ...props
}: React.PropsWithChildren<ThemeProps>) => {
  return <RadixTheme {...props}>{children}</RadixTheme>;
};
