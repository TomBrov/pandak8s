import {
  pink,
  grayDark,
  grayDarkA,
  blueDark,
  blueDarkA,
  redDark,
  redDarkA,
  greenDark,
  greenDarkA,
  purpleDark,
  purpleDarkA,
  pinkDark,
  pinkDarkA,
  orangeDark,
  orangeDarkA,
  amberDark,
  amberDarkA,
} from '@radix-ui/colors';

export const defaultTheme = {
  table: {
    tableBg: purpleDark,
    containerBg: pinkDarkA,
  },
  screens: {
    sm: '640px',
    // => @media (min-width: 640px) { ... }
    md: '768px',
    desktop: '768px',
    // => @media (min-width: 768px) { ... }
    lg: '1024px',
    // => @media (min-width: 1024px) { ... }
    xl: '1280px',
    '2xl': '1400px',
  },
  container: {
    center: true,
    padding: '2rem',
  },
  fontFamily: 'spacemono, nato, ocr',
  colors: {
    grayDark: grayDark,
    grayDarkA: grayDarkA,
    blueDark: blueDark,
    blueDarkA: blueDarkA,
    redDark: redDark,
    redDarkA: redDarkA,
    greenDark: greenDark,
    greenDarkA: greenDarkA,
    purpleDark: purpleDark,
    purpleDarkA: purpleDarkA,
    pinkDark: pinkDark,
    pinkDarkA: pinkDarkA,
    orangeDark: orangeDark,
    orangeDarkA: orangeDarkA,
    amberDark: amberDark,
    amberDarkA: amberDarkA,
    // TODO: remove this and use the pink Dark
    pink: pink,
    primary: '#FFD2ECFD',
    secondary: '#14345E',
    background: '#1e293b',
    sidebarBackground: pinkDark.pink1,
    highlight: '#fe2fbd2d',
    text: '#E5E7EB',
    border: 'hsl(var(--border))',
    input: 'hsl(var(--input))',
    ring: 'hsl(var(--ring))',
    foreground: 'hsl(var(--foreground))',
    destructive: {
      DEFAULT: 'hsl(var(--destructive))',
      foreground: 'hsl(var(--destructive-foreground))',
    },
    success: {
      DEFAULT: 'hsl(var(--success))',
      foreground: 'hsl(var(--success-foreground))',
    },
    muted: {
      DEFAULT: 'hsl(var(--muted))',
      foreground: 'hsl(var(--muted-foreground))',
    },
    accent: {
      DEFAULT: 'hsl(var(--accent))',
      foreground: 'hsl(var(--accent-foreground))',
    },
    popover: {
      DEFAULT: 'hsl(var(--popover))',
      foreground: 'hsl(var(--popover-foreground))',
    },
    card: {
      DEFAULT: 'hsl(var(--card))',
      foreground: 'hsl(var(--card-foreground))',
    },
  },
  shadows: {
    // based on radix themes css variables:
    // https://www.radix-ui.com/themes/docs/theme/shadows
    /* Inset shadow */
    shadow1: 'var(--shadow-1)',
    /* Shadows for variant="classic" panels, like Card */
    shadow2: 'var(--shadow-2)',
    shadow3: 'var(--shadow-3)',
    /* Shadows for smaller overlay panels, like Hover Card and Popover */
    shadow4: 'var(--shadow-4)',
    shadow5: 'var(--shadow-5)',
    /* Shadows for larger overlay panels, like Dialog */
    shadow6: 'var(--shadow-6)',
  },
  spacing: {
    // based on radix themes css variables
    // https://www.radix-ui.com/themes/docs/theme/spacing
    // the base value is 4px -> 2 == 8px
    space1: 'var(--space-1)',
    space2: 'var(--space-2)',
    space3: 'var(--space-3)',
    space4: 'var(--space-4)',
    space5: 'var(--space-5)',
    space6: 'var(--space-6)',
    space7: 'var(--space-7)',
    space8: 'var(--space-8)',
    space9: 'var(--space-9)',
  },
  borderRadius: {
    lg: 'var(--radius)',
    md: 'calc(var(--radius) - 2px)',
    sm: 'calc(var(--radius) - 4px)',
  },
  transitionProperty: {
    width: 'width',
  },
};

export type DefaultThemeType = typeof defaultTheme;

declare module 'styled-components' {
  export interface DefaultTheme extends DefaultThemeType {}
}
