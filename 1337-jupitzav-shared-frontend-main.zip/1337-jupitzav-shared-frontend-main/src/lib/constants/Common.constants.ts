export const SAVE_BUTTON = 'שמור';
export const CANCEL_BUTTON = 'בטל';
export const DELETE_BUTTON = 'מחק';
export const ADD_BUTTON = 'הוסף';
