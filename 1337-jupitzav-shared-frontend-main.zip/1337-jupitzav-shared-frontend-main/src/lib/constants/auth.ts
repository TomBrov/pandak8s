export enum authError {
  SESSION_NOT_EXIST = 'No current user',
  GROUP_ID_NOT_EXIST = 'Group id env is missing',
  USER_DOESNT_EXIST_ON_DB = 'ERR_BAD_REQUEST',
}
