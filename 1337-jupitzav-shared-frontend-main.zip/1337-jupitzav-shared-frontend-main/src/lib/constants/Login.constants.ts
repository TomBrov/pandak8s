export const WELCOME_SUBTITLE = '.See Beyond. See Better';
export const WELCOME_BUTTON = 'התחברות';

export const LOGIN_TITLE = 'התחברות';

export const LOGIN_BUTTON = 'הבא';
export const LOGIN_ERROR = 'תקלת התחברות, יש ליצור קשר עם התמיכה';
export const OTP_BUTTON = 'הבא';
export const OTP_RESEND = 'לא קיבלתי את הקוד, שלחו לי שוב';
export const OTP_GO_BACK = 'חזרה להזנת תעודת זהות';

export const SHIFT_TITLE = 'תפקיד';
export const SHIFT_SUBTITLE = 'בחרי תא שטח ועמדה';
export const SELECT_CELL_LABEL = 'תא שטח';
export const SELECT_CELL_PLACEHOLDER = 'בחרי תא שטח';
export const SELECT_STATION_LABEL = 'עמדה';
export const SELECT_STATION_PLACEHOLDER = 'בחרי עמדה';
export const SHIFT_BUTTON = 'כניסה';
export const SHIFT_GO_BACK = 'חזרה להזנת תעודת זהות';

export const LOADING = 'טוען...';
