import { renderHook, fireEvent } from '@testing-library/react';

import { useDrag } from './useDrag';

const createElement = (rect: Partial<DOMRect>): HTMLDivElement =>
  Object.assign(document.createElement('div'), {
    getBoundingClientRect: () => ({
      bottom: rect.height || 0,
      right: rect.width || 0,
      height: 0,
      left: 0,
      top: 0,
      width: 0,
      x: 0,
      y: 0,
      toJSON: () => ({}),
      ...rect,
    }),
  });

const drag = (element: HTMLDivElement) => {
  return {
    to: (x: number, y: number) => {
      fireEvent.mouseDown(element, { clientX: 0, clientY: 0 });
      fireEvent.mouseMove(document, { clientX: x, clientY: y });
    },
  };
};

const init = ({
  elementRect = { x: 0, y: 0, width: 100, height: 100 },
} = {}) => {
  const container = createElement({ x: 0, y: 0, width: 200, height: 200 });
  const element = createElement(elementRect);

  const elementRef = createRef(element);
  const containerRef = createRef(container);
  document.body.appendChild(container);
  container.appendChild(elementRef.current!);

  renderHook(() =>
    useDrag({
      elementRef,
      containerRef,
      initialPosition: () => ({ x: 50, y: 50 }),
    }),
  );

  return { element, container };
};

const createRef = <T extends HTMLElement>(current: T): React.RefObject<T> => ({
  current,
});

describe('Hook: useDrag', () => {
  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('should initialize with the correct initial position', () => {
    const { element } = init();

    expect(element.style.left).toBe('50px');
    expect(element.style.top).toBe('50px');
  });

  it('should update position on mouse move', () => {
    const { element } = init();

    drag(element).to(50, 50);

    expect(element.style.left).toBe('50px');
    expect(element.style.top).toBe('50px');
  });

  it('should stop dragging on mouse up', () => {
    const { element } = init();

    drag(element).to(50, 50);

    fireEvent.mouseUp(document);
    fireEvent.mouseMove(document, { clientX: 100, clientY: 100 });

    expect(element.style.left).toBe('50px');
    expect(element.style.top).toBe('50px');
  });

  it('should respect container boundaries', () => {
    const { element, container } = init();

    drag(element).to(250, 250);

    const expectedLeft =
      container.getBoundingClientRect().width -
      element.getBoundingClientRect().width;
    const expectedTop =
      container.getBoundingClientRect().height -
      element.getBoundingClientRect().height;

    expect(parseInt(element.style.left)).toBe(expectedLeft);
    expect(parseInt(element.style.top)).toBe(expectedTop);
  });

  it('should respect container boundries expect left when the element is wider than the container', () => {
    const { element, container } = init({
      elementRect: { x: 0, y: 0, width: 300, height: 100 },
    });

    drag(element).to(250, 100);

    const expectedTop =
      container.getBoundingClientRect().height -
      element.getBoundingClientRect().height;

    expect(parseInt(element.style.left)).toBe(250);
    expect(parseInt(element.style.top)).toBe(expectedTop);
  });
});
