import { useEffect, useRef } from 'react';
import { Position, UseDragArguments } from './types';

const considerContainer = (
  elementRect: DOMRect,
  position: Position,
  containerRect?: DOMRect,
): Position => {
  if (!containerRect) {
    return position;
  }
  const isElementWiderThanContainer = elementRect.width > containerRect.width;
  const isElementHigherThanContainer =
    elementRect.height > containerRect.height;

  return {
    top: Math.min(
      Math.max(position.top, containerRect.top),
      // if the element is higher than the container, let it exceed the container's bottom
      isElementHigherThanContainer
        ? Number.MAX_SAFE_INTEGER
        : containerRect.bottom - elementRect.height,
    ),
    left: Math.min(
      Math.max(position.left, containerRect.left),
      // if the element is wider than the container, let it exceed the container's right
      isElementWiderThanContainer
        ? Number.MAX_SAFE_INTEGER
        : containerRect.right - elementRect.width,
    ),
  };
};

export const useDrag = ({
  elementRef,
  containerRef,
  initialPosition = () => ({ x: 0, y: 0 }),
}: UseDragArguments) => {
  const positionsRef = useRef(initialPosition());

  useEffect(() => {
    if (!elementRef.current) {
      return undefined;
    }

    const element = elementRef.current;

    const dragMouseDown = (e: MouseEvent) => {
      e.preventDefault();
      document.body.classList.add('cursor-move');

      // get the mouse cursor position at startup:
      positionsRef.current.x = e.clientX;
      positionsRef.current.y = e.clientY;

      document.addEventListener('mouseup', closeDragElement);
      document.addEventListener('mousemove', elementDrag);
    };

    const elementDrag = (e: MouseEvent) => {
      e.preventDefault();
      const { x: xPosition, y: yPosition } = positionsRef.current;
      const containerRect = containerRef?.current?.getBoundingClientRect();
      const elementRect = element!.getBoundingClientRect();

      // we can't use the clientX and clientY because the user can drag the element by grabbing any part of it
      // so we need to calculate how far the mouse and move the container based on that
      const mouseMovedX = xPosition - e.clientX;
      const mouseMovedY = yPosition - e.clientY;

      const requestedLeft = element!.offsetLeft - mouseMovedX;
      const requestedTop = element!.offsetTop - mouseMovedY;

      const nextPosition = considerContainer(
        elementRect,
        {
          left: requestedLeft,
          top: requestedTop,
        },
        containerRect,
      );

      positionsRef.current.x = e.clientX;
      positionsRef.current.y = e.clientY;

      // set the element's new position:
      if (element) {
        element.style.top = `${nextPosition.top}px`;
        element.style.left = `${nextPosition.left}px`;
      }
    };

    const closeDragElement = () => {
      /* stop moving when mouse button is released:*/
      document.body.classList.remove('cursor-move');
      document.removeEventListener('mouseup', closeDragElement);
      document.removeEventListener('mousemove', elementDrag);
    };

    if (element) {
      element.onmousedown = dragMouseDown;
      const { x, y } = initialPosition();
      element.style.top = y + 'px';
      element.style.left = x + 'px';
    }

    // Cleanup function
    return () => {
      if (element) element.onmousedown = null;
      document.removeEventListener('mouseup', closeDragElement);
      document.removeEventListener('mousemove', elementDrag);
    };
  }, [containerRef, elementRef, initialPosition]);
};
