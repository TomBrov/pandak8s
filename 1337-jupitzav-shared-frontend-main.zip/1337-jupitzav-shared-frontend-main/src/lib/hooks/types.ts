import type { RefObject } from 'react';

export type UseDragArguments = {
  elementRef: RefObject<HTMLDivElement>;
  containerRef?: RefObject<HTMLDivElement> | null;
  initialPosition?: () => { x: number; y: number };
};

export type Position = Pick<DOMRect, 'top' | 'left'>;
