import '@radix-ui/themes/styles.css'
import React from 'react'

import type { Preview } from '@storybook/react'

import { ThemeProvider } from '../src/lib/components/themeProvider/ThemeProvider'

const preview: Preview = {
  parameters: {
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
    },
  },

  decorators: [
    (Story) => (
      <ThemeProvider>
        <div dir="rtl">
          <Story />
        </div>
      </ThemeProvider>
    ),
  ],

  tags: ['autodocs'],
}

export default preview
