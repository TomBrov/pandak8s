import { defineConfig } from 'vite'
import path from 'path'
import react from '@vitejs/plugin-react'
import dts from 'vite-plugin-dts'

export default defineConfig({
  root: './',
  cacheDir: './node_modules/.vite/libs/jupitzav-shared-frontend',

  plugins: [react(), dts()],

  // Configuration for building your library.
  // See: https://vitejs.dev/guide/build.html#library-mode
  build: {
    outDir: './dist/',
    reportCompressedSize: true,
    commonjsOptions: {
      transformMixedEsModules: true,
    },
    sourcemap: true,
    lib: {
      // Could also be a dictionary or array of multiple entry points.
      entry: path.resolve(__dirname, 'src/index.ts'),
      name: 'jupitzav-shared-frontend',
      fileName: (format) => `index.${format}.js`,
      // Change this to the formats you want to support.
      // Don't forget to update your package.json as well.
      formats: ['es', 'umd'],
    },
    rollupOptions: {
      output: {
        globals: {
          react: 'React',
          'react-dom': 'ReactDOM',
        },
      },
      external: [
        'react',
        'react-dom',
        'react/jsx-runtime',
        '@radix-ui/themes',
        'styled-components',
        'react-hook-form',
      ],
    },
    emptyOutDir: true,
  },
  resolve: {
    alias: {
      '@': path.resolve('./', './src'),
    },
  },
})
