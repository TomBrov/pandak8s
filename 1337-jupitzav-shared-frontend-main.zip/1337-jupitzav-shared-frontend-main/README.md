# jupitzav-shared-frontend

`jupitzav-shared-frontend` is a shared frontend library used across Jupiter & Hatsav. It includes commonly used types, utilities, and constants.

## Installation

> ⚠️ **DEPRECATED** ⚠️ 

#### NOTE: this method is not recommended, you should use [Storybook](#storybook) instead

 ### Using `yalc` for Local Development

 1. **Install `yalc`**
   ```sh
      npm i yalc -g
   ```

## Storybook

Storybook is a tool for developing UI components in isolation. It allows you to develop and test your components without having to navigate through your entire application.

You can read more [here](https://storybook.js.org/docs/get-started/whats-a-story)

### How to use Storybook

1. **Start Storybook**

   To start Storybook, run the following command in your terminal:

   ```sh
   npm run storybook
   ```

   This will start the Storybook server and open it in your default web browser.

2. **Write Stories**

   A story is a function that returns a rendered component. To write a story, create a new file in the same directory as the component you wish to display with a `.stories.tsx` extension.

   For example, if you have a component called `Button.tsx`, you would create a story file called `Button.stories.tsx`.

   In the story file, import the component and write a story function that returns the rendered component.

   ```tsx
   import type { Meta, StoryObj } from '@storybook/react';
   import { Button } from './Button';

   const meta: Meta<typeof Button> = {
     component: Button,
   };

   export default meta;
   type Story = StoryObj<typeof Button>;

   export const Primary: Story = {
     args: {
       primary: true,
       label: 'Button',
     },
   };
   ```
   In this example, the story function `Primary` returns a rendered `Button` component with the text "Button".

   ![Storybook image](storybook.png)

3. **View Stories**

   Once you have written a story, you can view it in Storybook by navigating to the story's page.

   You can find the story's page by clicking on the story's title in the Storybook navigation menu.

4. **Test Stories**

   Storybook allows you to test your components in isolation. You can use the "Play" function to test your components with different props and state.

   To test a story, click on the "Play" button in the Storybook toolbar.

### Benefits of using Storybook

* Develop and test UI components in isolation
* Write stories to document your components
* Test your components with different props and state
* Improve collaboration between designers and developers



## Publish package

1. **Install dependencies**

   ```sh
   npm install
   ```

   This will publish `jupitzav-shared-frontend` to your global local sore
   located in `~/.yalc`

2. **Publish the package locally**

   ```sh
   yalc publish
   ```

   This will publish `jupitzav-shared-frontend` to your global local sore
   located in `~/.yalc`

## Usage

### Install the package in consumer repository

1. navigate to consumer project (e.g. jupiter-monorepo / hatzav-moborepo), and run the following command:

   ```sh
   yalc add jupitzav-shared-frontend
   ```

   This will add `.yalc` folder which contains the package ,in your project's root path.
   The package will also be added to the package.json automatically

2. install the new package (from root of the project)

   ```sh
   npm install
   ```

3. Now you can import the package files, Here is an example of how you might use the `Form` import in your code:

```js
import { Form } from '@ClickIDF/1337-jupitzav-shared-frontend'
```

# Project: Shared Library for ClickIDF

This repository contains a shared library for the ClickIDF organization. The repository follows modern best practices for continuous integration (CI), continuous delivery (CD), and versioning to ensure smooth development and release cycles.

## Repository Lifecycle

### Development Process

1. **Pull Request Workflow**

   - When a pull request (PR) is opened to the `main` branch, the `pr.yml` workflow runs.
   - This workflow validates the code by linting, running tests, and ensuring the quality of the code before merging.
   - No version bump happens at this stage; the workflow only checks the code's validity.
   - Developers should submit PRs to merge their changes into `main` after local development.

2. **Push to Main Workflow**
   - Upon merging a PR into the `main` branch, the `main.yml` workflow triggers.
   - This workflow runs a build, lints the code, and publishes an **alpha version** of the package to GitHub Packages. Alpha versions are useful for testing pre-releases without affecting the final release.
   - Alpha versions are tagged as `alpha` and follow the format: `version-alpha.x` (e.g., `4.1.0-alpha.1`).

### Tagging and Version Bumping

- **Tagging**

  - The tagging process is automated. When a release is created, GitHub automatically generates a tag for that release based on the `package.json` version.
  - The `npm version` command can be used manually to bump versions when necessary, but the workflow also handles version bumps and commits.

- **Version Bumping**

  - **Development Branch**: While developing new features, the version in `package.json` reflects the upcoming release (e.g., `4.2.0`), but alpha versions are used for pre-releases.
  - **Release Branch**: Upon creating a new release, the version in `package.json` is updated to the new release version (e.g., `4.2.0`), and the release workflow handles the tagging and publishing.
  - Developers do not need to manually bump versions unless they want to change the planned release version.

- **Minor and Major Bumps**
  - Minor and major version bumps (e.g., `4.x` to `5.x`) should be done manually by developers. Use the following command to bump the version:
    ```bash
    npm version minor  # For minor version bumps
    npm version major  # For major version bumps
    ```
  - This will update the `package.json` version and create a corresponding Git tag. The updated version will be included in the next release.

### Release Process

1. **Alpha Publishing**

   - Every time code is merged into the `main` branch, an alpha version of the package is published to GitHub Packages.
   - This is handled by the `publish-alpha.yml` workflow, which ensures pre-release versions are tagged as `alpha`.

2. **Release Workflow**
   - When a new release is created (e.g., via GitHub's "Create a release" interface), the `release.yml` workflow is triggered.
   - The `release.yml` workflow publishes the final, stable version of the package to GitHub Packages and updates the `package.json` version accordingly.
   - This workflow also handles tagging the release automatically based on the version in `package.json`.

## Workflows

### 1. **Pull Request Validation**

- File: [pr.yml](./.github/workflows/pr.yml)
- Trigger: `pull_request` on `main`
- Tasks:
  - Lint the code.
  - Run tests.

### 2. **Push to Main and Alpha Publish**

- File: [main.yml](./.github/workflows/main.yml)
- Trigger: `push` to `main`
- Tasks:
  - Run lint and tests using the reusable `build-lint-test.yml`.
  - Publish an alpha version to GitHub Packages.

### 3. **Alpha Publishing Workflow**

- File: [publish-alpha.yml](./.github/workflows/publish-alpha.yml)
- Trigger: `push` to `main`
- Tasks:
  - Build and publish an alpha version to GitHub Packages.

### 4. **Release Workflow**

- File: [release.yml](./.github/workflows/release.yml)
- Trigger: `release` creation
- Tasks:
  - Build the project.
  - Publish the package to GitHub Packages.
  - Tag the release automatically.

## Best Practices

- **Tagging**:  
  Tags are automatically created during the release process. No manual intervention is needed for tagging releases.

- **Version Bumping**:  
  The version in `package.json` is bumped based on Git tags or manually by developers when needed. During the release process, the version is finalized, and pre-releases use `alpha` or `beta` tags.
